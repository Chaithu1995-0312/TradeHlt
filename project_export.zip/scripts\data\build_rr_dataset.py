"""
build_rr_dataset.py
===================
Build and save RR dataset JSON from trades CSVs.

Usage:
  py build_rr_dataset.py --csv results/batch/AUDUSD_M15/AUDUSD_M15_trades.csv
  py build_rr_dataset.py --dir results/batch
  py build_rr_dataset.py --glob "results/**/*_trades.csv"
"""

from __future__ import annotations

import argparse
import csv
import glob
import os
from typing import List, Dict

from config_layer.rr.rr_dataset_builder import build_dataset, save_dataset


def _collect_paths(args) -> List[str]:
    if args.csv:
        return [args.csv]
    if args.dir:
        return glob.glob(os.path.join(args.dir, "**", "*_trades.csv"), recursive=True)
    if args.glob:
        return glob.glob(args.glob, recursive=True)
    # fallback: newest trades csv under results/
    paths = glob.glob("results/**/*_trades.csv", recursive=True)
    paths = sorted(paths, key=lambda p: os.path.getmtime(p), reverse=True)
    return paths[:1]


def _load_csv(path: str) -> List[Dict[str, str]]:
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        return list(reader)


def main() -> None:
    ap = argparse.ArgumentParser(description="Build RR dataset from trades CSVs")
    ap.add_argument("--csv", help="Path to a single *_trades.csv")
    ap.add_argument("--dir", help="Directory to scan for *_trades.csv (recursive)")
    ap.add_argument("--glob", help="Glob pattern for trades CSVs")
    ap.add_argument("--output", default="models/rr_dataset.json",
                    help="Output dataset path (default models/rr_dataset.json)")
    args = ap.parse_args()

    paths = _collect_paths(args)
    if not paths:
        raise SystemExit("No trades CSV found. Use --csv or --dir.")

    trades: List[Dict[str, str]] = []
    for p in paths:
        print("Loading:", p)
        trades.extend(_load_csv(p))

    print(f"Total trades loaded: {len(trades)}")
    X, y_rr, y_win = build_dataset(trades)
    save_dataset(X, y_rr, y_win, args.output)
    print(f"Saved RR dataset → {args.output}")


if __name__ == "__main__":
    main()

