﻿# IMPLEMENTATION_REALITY_MAP

Status System: ✅ 🟡 🔴 🧪

## Status Legend

Status System: ✅ 🟡 🔴 🧪
- ? Implemented
- ?? Partial or contradictory behavior
- ?? Missing from context / missing implementation
- ?? Mocked/test-only/implied

## Layer Reality Grid

Status System: ✅ 🟡 🔴 🧪

| Layer | Module | Key Class/Method | Status | Notes |
|---|---|---|---|---|
| Ingestion | `features/feature_pipeline.py` | `FeaturePipeline.run` | ? | End-to-end canonical feature build pipeline is present. |
| Ingestion | `core/feature_store.py` | `FeatureStore.process` | ? | Validates schema, computes derived fields, injects integrity sentinel. |
| Graph/Cognition | `core/engine_runner.py` | `EngineRunner.run` | ? | Strict staged pipeline with hard rejects and final decision call. |
| Graph/Cognition | `engines/adapter_engine.py` | `TrapValidatorEngine.compute` | ? | Hard-gate using ATR/session/integrity sentinel. |
| Graph/Cognition | `engines/crt_engine.py` | `compute` | ? | Wraps CRT scoring from `scoring_engine.compute_scores`. |
| Graph/Cognition | `engines/heuristic_gaussian_engine.py` | `HeuristicGaussianEngine.compute` | ? | Registry-backed heuristic Gaussian signal. |
| Graph/Cognition | `engines/ml_gaussian_engine.py` | `MLGaussianEngine.compute` | ? | Fail-open 0.5 fallback model inference path. |
| Graph/Cognition | `engines/rr_engine.py` | `RREngine.compute` | ? | Price-structure RR calculation. |
| Graph/Cognition | `engines/zone_gate_engine.py` | `run_zone_gate_engine` | ? | Canonical key validation + registry validation + score thresholding. |
| Cognition/Decision | `core/fusion_engine.py` | `FusionEngine.compute` | ? | Average across `crt/gaussian/zone_gate/rr`, missing-engine guard. |
| Service | `core/decision_engine.py` | `DecisionEngine.evaluate` | ? | Final execute/reject logic based on score/p_win/rr/weakness. |
| Service | `engines/live_engine.py` | `LiveEngine.process` | ? | End-to-end live decision + alert path with suppressors. |
| Governance | `config_validator.py` | `ConfigValidator.validate` | ? | Multi-instrument validation with hard reject criteria. |
| Governance | `promotion_manager.py` | `PromotionManager.promote_from_tuner_checkpoint` | ? | Validation-gated promotion workflow. |
| Governance | `production_config.py` | `load_prod_config_from_registry` | ? | Registry load + hash verification + build. |
| Runtime | `runtime/backtest_v2.py` | `BacktestRunner.run` | ? | Main backtest loop with slippage/spread/capital/multi output. |
| Runtime | `runtime/backtest_bitnet.py` | `run_backtest` | ?? | Commented BitNet inference path exists, but score assignment path hardcodes `score = 0.0` before EngineRunner result override. |
| Schema | `features/feature_schema.py` | canonical constants | ?? | Internal dimension consistency is self-consistent (35) but conflicts with legacy docs/comments (24/32). |
| Governance | `governance/shadow_promotion_gate.py` | `execute_shadow_test` | ?? | Contains acknowledged TODO comments and assumptions about runner config ingestion. |
| Governance | `governance/meta_governor_executor.py` | `extract_and_validate_config` | ?? | Minimal JSON extraction check only; no full policy validation. |

## Class ? Method Reality (Profiled)

Status System: ✅ 🟡 🔴 🧪

### `core.engine_runner.EngineRunner`

Status System: ✅ 🟡 🔴 🧪

| Method | Responsibility | Risk | Inputs/Outputs | Idempotent | State Impact | Validation/Invariants | Status |
|---|---|---|---|---|---|---|---|
| `_get_gaussian_engine` | Select heuristic vs ML Gaussian engine | LOW | `config -> engine instance` | ? | none | env/config enum fallback | ? |
| `__init__` | Wire adapter, engines, fusion, decision, collector, dual gate config | MED | `config -> initialized runner` | ? | mutates internal members | expected engine set preconfigured | ? |
| `_reject` | Emit normalized reject record and log through collector | MED | reject context -> reject dict | ? | collector append | reject record schema completeness | ? |
| `run` | Full pipeline execution from adapter to final decision | HIGH | `input_data/context -> decision dict` | ? (same input, deterministic aside from downstream stochastic sources) | collector append | engine completeness, fusion min score, ultron gate, DecisionEngine authority | ? |

Method Usage Graph:
- `EngineRunner.run` called by: `runtime/backtest_bitnet.run_backtest`, tests (`test_engine_runner_dual_gate.py`, `test_zone_gate.py`).
- Layer: Cognition/Service.
- Type: Transactional (writes logs), write-authoritative for decision records.

### `core.fusion_engine.FusionEngine`

Status System: ✅ 🟡 🔴 🧪

| Method | Responsibility | Risk | Inputs/Outputs | Idempotent | State Impact | Validation/Invariants | Status |
|---|---|---|---|---|---|---|---|
| `compute` | Aggregate engine outputs and detect missing engines | LOW | `engine_results -> fusion summary` | ? | none | expected keys fixed: `crt,gaussian,zone_gate,rr` | ? |
| `evaluate` | Optional layered scoring with gaussian/neural/LLM and risk tier map | MED | `features, signal -> FusionResult` | ? (given deterministic dependencies) | none | bounded scores and tier thresholds | ? |
| `_decide` | map score to action and risk multiplier | LOW | `score -> (action, risk)` | ? | none | tier ordering invariant | ? |

Method Usage Graph:
- `compute` called by `EngineRunner.run`.
- `evaluate` currently not on main `EngineRunner` path; used as alternate API.
- Layer: Cognition.
- Type: Pure computation.

### `core.decision_engine.DecisionEngine`

Status System: ✅ 🟡 🔴 🧪

| Method | Responsibility | Risk | Inputs/Outputs | Idempotent | State Impact | Validation/Invariants | Status |
|---|---|---|---|---|---|---|---|
| `evaluate` | Final execute/reject decision | LOW | scalar context -> decision dict | ? | none | zone gate valid, score>=threshold, p_win>=0.4, rr>=1.2, weak component <= threshold | ? |
| `reject` | Standardized reject payload | LOW | reason -> dict | ? | none | confidence fixed 0 for rejects | ? |
| `_get_cfg` | Config value getter for dict/object | LOW | config + key -> float | ? | none | float coercion | ? |

Method Usage Graph:
- `evaluate` called by `EngineRunner.run`.
- Layer: Service / governance boundary.
- Type: Write-authoritative decision boundary (logical authority, no disk writes).

### `runtime.backtest_v2.BacktestRunner`

Status System: ✅ 🟡 🔴 🧪

| Method | Responsibility | Risk | Inputs/Outputs | Idempotent | State Impact | Validation/Invariants | Status |
|---|---|---|---|---|---|---|---|
| `__init__` | Build runtime context and optional feature vectors | MED | config/csv path -> runner state | ? | stores vectors and config | pipeline run needed if csv path provided | ? |
| `run` | Candle replay, trade lifecycle, metrics, reports | HIGH | candle iterator -> `BacktestMetrics` | ? for fixed seed/data/config | writes files, journal, event streams | warmup/init enforced, forced close at end, gap reset logic | ? |
| `_session` | map timestamp to configured session window | LOW | ts -> session str | ? | none | session window mapping completeness | ? |
| `_print_summary` | final summary logging | LOW | metrics -> log lines | ? | log output | none | ? |

Method Usage Graph:
- Called by CLI `main` and `MultiInstrumentRunner.run_all`.
- Layer: Runtime service.
- Type: Transactional/write-authoritative.

### `engines.live_engine.LiveEngine`

Status System: ✅ 🟡 🔴 🧪

| Method | Responsibility | Risk | Inputs/Outputs | Idempotent | State Impact | Validation/Invariants | Status |
|---|---|---|---|---|---|---|---|
| `__init__` | Initialize config + cooldown/dedup state | MED | config -> engine state | ? | mutates in-memory alert state | config validation warnings only | ? |
| `process` | Live scoring + decision + optional alert dispatch | HIGH | trade data + models -> result dict | ? (time/cooldown/network dependent) | alert state update, log writes, optional network send | kill switch, feature validation, confidence/rr ladder, cooldown dedup | ? |
| `dry_run` | Execute pipeline without real Telegram send | MED | same as process -> result | ? | temporarily mutates config flags | restores config after run | ? |

Method Usage Graph:
- Called by runtime/live integrations and potential external bot wrapper.
- Layer: Service.
- Type: Transactional and external I/O.

## Cross-Class Interaction & Boundaries

Status System: ✅ 🟡 🔴 🧪
- Safety Rails / Invariant Enforcers:
  - `TrapValidatorEngine.compute`
  - `FeatureStore._validate_schema`
  - `zone_gate_engine.filter_canonical_inputs`
  - `schema_validator.validate_*`
- Lifecycle Gatekeepers / Write Boundaries:
  - `EngineRunner._reject` + `Collector.log`
  - `BacktestRunner.run` (trade open/close/write)
  - `PromotionManager._write_to_registry`
- Security / Governance Boundaries:
  - `DecisionEngine.evaluate` (execution authority)
  - `production_config._verify_config_hash`
  - `GaussianModelRegistry.promote_gaussian` schema-version guard

## Missing / Implied Methods

Status System: ✅ 🟡 🔴 🧪
- ?? `governance/shadow_promotion_gate.py` implies backtest config injection method that is not implemented robustly.
- ?? `crt_engine_v2` internal classes/methods are referenced but not audited here; behavior boundary remains external to this map.

