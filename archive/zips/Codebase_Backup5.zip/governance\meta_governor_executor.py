import subprocess
import json
import re

class MetaGovernorExecutor:
    def __init__(self, bitnet_bin="./bitnet/bin/main", model_path="./models/bitnet_b1_58_70b.gguf"):
        self.bitnet_bin = bitnet_bin
        self.model_path = model_path

    def run_inference(self, prompt_path="logs/meta_prompt.txt") -> str:
        with open(prompt_path, 'r') as f:
            prompt = f.read()

        cmd = [
            self.bitnet_bin,
            "-m", self.model_path,
            "-p", prompt,
            "-n", "256",
            "--temp", "0.1",
            "-c", "2048"
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.stdout

    def extract_and_validate_config(self, raw_output: str) -> dict:
        match = re.search(r'\{.*\}', raw_output, re.DOTALL)

        if not match:
            raise ValueError("No JSON found.")

        json_str = match.group(0)
        candidate_config = json.loads(json_str)

        if "fusion_min_score" not in candidate_config:
            raise KeyError("Missing keys")

        return candidate_config
