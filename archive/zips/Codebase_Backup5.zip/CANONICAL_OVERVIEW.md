﻿# CANONICAL_OVERVIEW

Status System: ✅ 🟡 🔴 🧪

## Status Legend

Status System: ✅ 🟡 🔴 🧪
- ? Implemented and verified in source
- ?? Partially implemented or behavior diverges from contract comments
- ?? Missing from context / not implemented / contradictory runtime contract
- ?? Mocked, test-only, or implied behavior

## System Canonical Shape

Status System: ✅ 🟡 🔴 🧪
The repository is a trading decision stack with these layers:
1. Ingestion: CSV readers, resamplers, feature builders (`prepare_data.py`, `unified_data_builder.py`, `features/feature_pipeline.py`)
2. Cognition: multi-engine scoring (`engines/*.py`, `core/engine_runner.py`, `core/fusion_engine.py`)
3. Governance: config validation/promotion (`config_validator.py`, `promotion_manager.py`, `production_config.py`)
4. Runtime: backtest/live orchestration (`runtime/backtest_v2.py`, `runtime/backtest_bitnet.py`, `engines/live_engine.py`)
5. Observability: collector/logging/report writers (`collector.py`, `trade_logger.py`, `insight_reporter.py`)

## Canonical Data & State Modeling

Status System: ✅ 🟡 🔴 🧪

### Primary Data Schemas

Status System: ✅ 🟡 🔴 🧪
- ? `CANONICAL_FEATURES` (`features/feature_schema.py`): ordered feature contract used by feature pipeline, feature store, zone gate, and RR fusion.
- ? `FeatureFrame` (`core/feature_store.py`): `{candle_idx, timestamp, features, integrity}`.
- ? `DecisionResult` (`core/decision_engine.py`): `{decision, reason, confidence}`.
- ? `FusionResult` (`core/fusion_engine.py`): `{final_score, gaussian, neural, llm, llm_fired, action, risk_mult}`.
- ? Backtest records (`runtime/backtest_v2.py`): `TradeRecord`, `RejectionRecord`, `BacktestMetrics`.
- ? Governance records: `ValidationReport` and production registry entries with `config_hash` (`config_validator.py`, `promotion_manager.py`, `production_config.py`).
- ?? Schema dimension comments conflict: source comments refer to 24/32 vectors while `CANONICAL_FEATURE_DIM` is set to 35.

### State Transition Logic (Confirmed)

Status System: ✅ 🟡 🔴 🧪
- ? Engine gating path (`core/engine_runner.py`):
  - `AdapterPass -> EnginesComputed -> FusionComputed -> DualGatePass -> DecisionEngine.execute|reject`
  - Fail transitions: `AdapterFail -> REJECT`, `IncompleteEngineSet -> REJECT`, `FusionBelowMin -> REJECT`, `DualGateBlock -> REJECT`.
- ? Backtest lifecycle (`runtime/backtest_v2.py`):
  - `Warmup -> InitRange -> CandleProcessLoop -> (TradeOpen -> TradeClose)* -> Metrics -> Reports`.
- ? Live alert lifecycle (`engines/live_engine.py`):
  - `KillSwitchCheck -> FeatureBuild -> Scale -> GaussianInfer -> OptionalRRFusion -> Decision -> CooldownDedup -> AlertSend|Suppress -> AuditLog`.
- ? Promotion lifecycle (`promotion_manager.py`):
  - `CandidateSource -> ValidationReport(APPROVE/REJECT) -> RegistryWrite -> PromotionLog`.

## Entry Point Map (Canonical)

Status System: ✅ 🟡 🔴 🧪
- ? CLI-heavy modules: `runtime/backtest_v2.py`, `runtime/backtest_bitnet.py`, `config_validator.py`, `promotion_manager.py`, `production_config.py`, `auto_tuner*.py`, `prepare_data.py`, `zone_schema_migrator.py`.
- ? Service-style callable entry points:
  - `EngineRunner.run(...)`
  - `LiveEngine.process(...)`
  - `ConfigValidator.validate(...)`
  - `PromotionManager.promote_*`
- ?? Governance helpers (`governance/*`) are script-like and partly scaffolding-level.

## External Surface Map (Dependencies, APIs, Failure Modes)

Status System: ✅ 🟡 🔴 🧪
- ? `pandas` / `numpy`: core feature and backtest data processing.
  - Failure modes: NaN propagation, schema width drift, type coercion errors.
- ? `torch` (lazy in `training/trainer.py`): TradeNet training/inference.
  - Failure modes: missing runtime dependency, model file mismatch.
- ? Telegram Bot API usage (`engines/live_engine.py` sender path).
  - Failure modes: missing token/chat ID, network errors, rate limiting.
- ? Subprocess inference (`governance/meta_governor_executor.py` for external bitnet binary).
  - Failure modes: missing binary/model, malformed JSON extraction.
- ? File-backed registries/logs (`models/*.json`, `production_configs/*.json`, `logs/*.jsonl`).
  - Failure modes: corruption, stale schema versions, hash mismatch, missing active entries.

## Confirmed Architectural Boundaries

Status System: ✅ 🟡 🔴 🧪
- ? Decision write boundary: `DecisionEngine.evaluate()` is final execute/reject authority for engine runner output.
- ? Feature integrity boundary: `FeatureStore.process()` injects `_data_integrity=real` sentinel used by adapter gate.
- ? Config write boundary: only promotion manager writes production versioned config artifacts.
- ? Schema enforcement boundary: `schema_validator.py` and feature schema checks in training/runtime.

## Explicit Conflicts Preserved

Status System: ✅ 🟡 🔴 🧪
- ?? Vector width conflict across modules:
  - `features/feature_schema.py` declares 35 canonical features.
  - Multiple comments and docs in runtime/bitnet/trainer still describe 24 or 32 features.
- ?? Decision label conflict:
  - `DecisionEngine` emits `execute/reject` lowercase.
  - Some legacy codepaths and logs still reference `ACCEPT/BLOCK/EXECUTE` uppercase semantics.
- ?? Runtime import conflict:
  - `runtime/backtest_v2.py` imports `archive.crt_engine_v2` while other modules import `crt_engine_v2` directly.

## Uncertainty Register

Status System: ✅ 🟡 🔴 🧪
- ?? MISSING_FROM_CONTEXT: complete behavior of `crt_engine_v2` implementation used by backtests.
- ?? MISSING_FROM_CONTEXT: full runtime behavior of many utility scripts not inspected line-by-line.
- ?? Implied but not strongly wired: meta-governor autonomous config tuning loop in `governance/*`.

