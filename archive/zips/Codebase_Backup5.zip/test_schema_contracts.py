"""
test_schema_contracts.py
═══════════════════════════════════════════════════════════════════════════════
CI schema contract test suite — v5 (canonical-only).

Tests the single canonical schema defined in feature_schema.py.

Tests:
  1. CANONICAL_FEATURES is a tuple (immutable)
  2. CANONICAL_FEATURES has no duplicates
  3. CANONICAL_FEATURES has exactly 32 features
  4. FEATURE_INDEX_MAP is consistent with CANONICAL_FEATURES
  5. SCHEMA_HASH is deterministic
  6. Session encoding returns canonical 0-indexed values
  7. validate_features: exact match passes
  8. validate_features: missing key raises ValueError
  9. validate_features: extra key raises ValueError
 10. validate_features: schema violation has structured error dict

Run:
    python test_schema_contracts.py
    # or via pytest: pytest test_schema_contracts.py -v

Exit 0 = all tests pass. Non-zero = contract violation found.
═══════════════════════════════════════════════════════════════════════════════
"""
from __future__ import annotations

import sys
import traceback
from typing import Callable

# ─────────────────────────────────────────────────────────────────────────────
# Minimal test harness (no pytest dependency for CI portability)
# ─────────────────────────────────────────────────────────────────────────────

_PASS = 0
_FAIL = 0
_RESULTS: list[tuple[str, bool, str]] = []


def test(name: str, fn: Callable) -> None:
    global _PASS, _FAIL
    try:
        fn()
        _PASS += 1
        _RESULTS.append((name, True, ""))
        print(f"  ✓  {name}")
    except Exception as e:
        _FAIL += 1
        tb = traceback.format_exc().strip().split("\n")[-1]
        _RESULTS.append((name, False, tb))
        print(f"  ✗  {name}")
        print(f"       {tb}")


def assert_raises(exc_type, fn, msg_contains: str = ""):
    try:
        fn()
        raise AssertionError(f"Expected {exc_type.__name__} but no exception was raised")
    except exc_type as e:
        if msg_contains and msg_contains not in str(e):
            raise AssertionError(
                f"Expected error containing '{msg_contains}', got: {e}"
            )


# ─────────────────────────────────────────────────────────────────────────────
# Tests
# ─────────────────────────────────────────────────────────────────────────────

print("\n╔══════════════════════════════════════════════════════════╗")
print("║  CRT Schema Contract Test Suite — v5 (canonical-only)  ║")
print("╚══════════════════════════════════════════════════════════╝\n")


# ── 1. CANONICAL_FEATURES is a tuple ─────────────────────────────────────────
def test_canonical_features_is_tuple():
    from features.feature_schema import CANONICAL_FEATURES
    assert isinstance(CANONICAL_FEATURES, tuple), (
        f"CANONICAL_FEATURES must be tuple (immutable), got {type(CANONICAL_FEATURES).__name__}"
    )

test("1. CANONICAL_FEATURES is a tuple (immutable)", test_canonical_features_is_tuple)


# ── 2. No duplicates ──────────────────────────────────────────────────────────
def test_no_duplicates():
    from features.feature_schema import CANONICAL_FEATURES
    seen = set()
    for f in CANONICAL_FEATURES:
        assert f not in seen, f"Duplicate feature name: '{f}'"
        seen.add(f)

test("2. CANONICAL_FEATURES has no duplicates", test_no_duplicates)


# ── 3. Exactly 32 features ────────────────────────────────────────────────────
def test_feature_count():
    from features.feature_schema import CANONICAL_FEATURES
    assert len(CANONICAL_FEATURES) == 32, (
        f"Expected 32 canonical features, got {len(CANONICAL_FEATURES)}"
    )

test("3. CANONICAL_FEATURES has exactly 32 features", test_feature_count)


# ── 4. FEATURE_INDEX_MAP consistency ─────────────────────────────────────────
def test_feature_index_map():
    from features.feature_schema import CANONICAL_FEATURES, FEATURE_INDEX_MAP
    assert len(FEATURE_INDEX_MAP) == len(CANONICAL_FEATURES), (
        f"FEATURE_INDEX_MAP has {len(FEATURE_INDEX_MAP)} entries, "
        f"expected {len(CANONICAL_FEATURES)}"
    )
    for i, name in enumerate(CANONICAL_FEATURES):
        assert name in FEATURE_INDEX_MAP, f"'{name}' missing from FEATURE_INDEX_MAP"
        assert FEATURE_INDEX_MAP[name] == i, (
            f"FEATURE_INDEX_MAP['{name}'] = {FEATURE_INDEX_MAP[name]}, expected {i}"
        )

test("4. FEATURE_INDEX_MAP is consistent with CANONICAL_FEATURES", test_feature_index_map)


# ── 5. SCHEMA_HASH is deterministic ──────────────────────────────────────────
def test_schema_hash_stable():
    import hashlib
    from features.feature_schema import CANONICAL_FEATURES, SCHEMA_HASH
    expected = hashlib.md5("".join(CANONICAL_FEATURES).encode()).hexdigest()
    assert SCHEMA_HASH == expected, (
        f"SCHEMA_HASH mismatch: expected {expected}, got {SCHEMA_HASH}. "
        "Schema may have been modified without updating the hash."
    )

test("5. SCHEMA_HASH is deterministic and matches current schema", test_schema_hash_stable)


# ── 6. Session encoding — canonical 0-indexed ────────────────────────────────
def test_session_encoding():
    from features.feature_schema import encode_session_ordinal, SESSION_ORDINAL
    assert encode_session_ordinal("ASIA")    == 0
    assert encode_session_ordinal("LONDON")  == 1
    assert encode_session_ordinal("NEWYORK") == 2
    assert encode_session_ordinal("UNKNOWN") == -1
    assert encode_session_ordinal(None)      == -1
    # Case insensitive
    assert encode_session_ordinal("london")  == 1
    assert encode_session_ordinal("asia")    == 0

test("6. encode_session_ordinal returns canonical 0-indexed values", test_session_encoding)


# ── 7. validate_features: exact match passes ─────────────────────────────────
def test_validate_features_exact_match():
    from features.feature_schema import CANONICAL_FEATURES, validate_features
    features = {f: 0.0 for f in CANONICAL_FEATURES}
    # Must not raise
    validate_features(features)

test("7. validate_features: exact match passes without error", test_validate_features_exact_match)


# ── 8. validate_features: missing key raises ValueError ──────────────────────
def test_validate_features_missing_key():
    from features.feature_schema import CANONICAL_FEATURES, validate_features
    features = {f: 0.0 for f in CANONICAL_FEATURES}
    del features["atr"]
    assert_raises(ValueError, lambda: validate_features(features))

test("8. validate_features: missing key raises ValueError", test_validate_features_missing_key)


# ── 9. validate_features: extra key raises ValueError ────────────────────────
def test_validate_features_extra_key():
    from features.feature_schema import CANONICAL_FEATURES, validate_features
    features = {f: 0.0 for f in CANONICAL_FEATURES}
    features["non_canonical_rsi"] = 50.0
    assert_raises(ValueError, lambda: validate_features(features))

test("9. validate_features: extra key raises ValueError", test_validate_features_extra_key)


# ── 10. validate_features: error has structured dict payload ─────────────────
def test_validate_features_error_structure():
    from features.feature_schema import CANONICAL_FEATURES, validate_features
    features = {f: 0.0 for f in CANONICAL_FEATURES}
    del features["close"]
    features["rsi"] = 50.0  # extra

    try:
        validate_features(features)
        raise AssertionError("Expected ValueError was not raised")
    except ValueError as e:
        err = e.args[0]
        assert isinstance(err, dict), f"Error payload must be dict, got {type(err)}"
        assert err["error"] == "FEATURE_SCHEMA_VIOLATION", f"Wrong error code: {err['error']}"
        assert "close" in err["missing"], f"'close' not in missing: {err['missing']}"
        assert "rsi" in err["extra"], f"'rsi' not in extra: {err['extra']}"

test("10. validate_features: error carries structured dict payload", test_validate_features_error_structure)


# ── 11. schema_validator.validate_features consistent with feature_schema ────
def test_schema_validator_consistent():
    from features.feature_schema import CANONICAL_FEATURES
    from features.schema_validator import validate_features as sv_validate

    # Exact match — must pass
    features = {f: 0.0 for f in CANONICAL_FEATURES}
    sv_validate(features, CANONICAL_FEATURES)

    # Missing — must raise
    bad = dict(features)
    del bad["body_ratio"]
    try:
        sv_validate(bad, CANONICAL_FEATURES)
        raise AssertionError("Expected ValueError for missing feature")
    except ValueError:
        pass

test("11. schema_validator.validate_features is consistent with feature_schema", test_schema_validator_consistent)


# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────

print(f"\n{'─'*58}")
print(f"  Results: {_PASS} passed, {_FAIL} failed out of {_PASS + _FAIL} tests")
print(f"{'─'*58}")

if _FAIL > 0:
    print("\n  FAILED TESTS:")
    for name, ok, err in _RESULTS:
        if not ok:
            print(f"    ✗  {name}")
            print(f"       {err}")
    print()
    sys.exit(1)
else:
    print("\n  All schema contracts verified. ✓")
    print("  Canonical feature schema is production-ready.\n")
    sys.exit(0)