import json
import os
import logging
from dataset_builder import build_dataset, extract_feature_vector

logger = logging.getLogger(__name__)


def validate_training_record(record: dict) -> bool:
    """Validate a training record has all required features and a valid label."""
    if "features" not in record:
        raise ValueError("Training record missing 'features' key")
    if "label" not in record:
        raise ValueError("Training record missing 'label' key")
    if record["label"] not in (0, 1):
        raise ValueError(f"Invalid label: {record['label']}. Must be 0 or 1.")
    return True


def load_training_data(path: str) -> list:
    """Load training records from a JSON file."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Training data not found: {path}")
    with open(path, "r") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError("Training data must be a list of records")
    return data


def prepare_training_vectors(records: list) -> tuple:
    """
    Convert training records to (X, y) arrays.
    Each record must have 'features' (dict) and 'label' (0 or 1).
    Returns (feature_matrix, label_vector).

    Raises:
        ValueError: If any record is missing required keys, or features are invalid.
        TypeError: If any feature value has the wrong type.
        AssertionError: If any extracted vector dimension does not match CANONICAL_FEATURE_DIM.
    """
    X = []
    y = []
    for i, record in enumerate(records):
        validate_training_record(record)
        features = record["features"]
        label = record["label"]
        vector = extract_feature_vector(features)
        X.append(vector)
        y.append(label)
    return X, y


def run_training_pipeline(
    data_path: str,
    model_fn: callable,
    output_path: str = None,
    threshold: float = 0.5,
) -> dict:
    """
    Full training pipeline:
    1. Load data
    2. Prepare vectors using canonical extract_feature_vector
    3. Run model training
    4. Optionally save results
    """
    records = load_training_data(data_path)
    X, y = prepare_training_vectors(records)

    logger.info(f"Training on {len(X)} samples with {len(X[0]) if X else 0} features each")

    results = model_fn(X, y)

    if output_path:
        os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(results, f, indent=2)
        logger.info(f"Training results saved to {output_path}")

    return results