﻿# APPENDIX

Status System: ✅ 🟡 🔴 🧪

## Status Legend

Status System: ✅ 🟡 🔴 🧪
- ? Implemented
- ?? Partial/Drift
- ?? Missing from context
- ?? Implied/Mocked

## Consolidated Class -> Method -> Responsibility -> Risk -> Used By

Status System: ✅ 🟡 🔴 🧪

| Class | Method | Responsibility | Risk | Used By | Layer | Type |
|---|---|---|---|---|---|---|
| `EngineRunner` | `run` | Full multi-engine decision orchestration | HIGH | `runtime/backtest_bitnet.py`, tests | Service/Cognition | Transactional |
| `EngineRunner` | `_reject` | Canonical reject envelope + collector log | MED | internal | Service | Write-authoritative |
| `DecisionEngine` | `evaluate` | Final execute/reject authority | LOW | `EngineRunner.run` | Service | Pure decision |
| `FusionEngine` | `compute` | Aggregate engine scores and missing checks | LOW | `EngineRunner.run` | Cognition | Pure |
| `FeatureStore` | `process` | Canonical feature frame production with integrity sentinel | MED | `runtime/backtest_bitnet.py` | Ingestion | Stateful |
| `FeaturePipeline` | `run` | Canonical dataframe enrichment and vector generation | MED | runtime modules, tests | Ingestion | Stateful transform |
| `FeaturePipeline` | `build_feature_vector` | NxD float32 matrix assembly | LOW | `FeaturePipeline.run` | Ingestion | Pure |
| `TrapValidatorEngine` | `compute` | Adapter gating (integrity/ATR/session) | MED | `EngineRunner.run` | Cognition | Pure gate |
| `RREngine` | `compute` | Price-structure RR score derivation | LOW | `EngineRunner.run` | Cognition | Pure |
| `HeuristicGaussianEngine` | `compute` | Heuristic Gaussian score from EMA/momentum | MED | `EngineRunner.run` | Cognition | Pure |
| `MLGaussianEngine` | `compute` | ML Gaussian inference with fail-open fallback | MED | `EngineRunner.run` | Cognition | Read-mostly |
| `BacktestRunner` | `run` | Candle replay and trade/report lifecycle | HIGH | CLI + multi-runner | Runtime | Transactional |
| `CapitalCurve` | `apply_trade` | Capital/equity update | HIGH | `TradeJournal`, `BacktestRunner` | Runtime | Stateful |
| `SlippageModel` | `compute_fill_prices` | Adverse fill + spread adjustment | MED | `TradeJournal` | Runtime | Stateful (RNG) |
| `MetricsEngine` | `compute` | Aggregate KPI metrics | MED | `BacktestRunner.run` | Runtime | Read-only compute |
| `ReportWriter` | `write_all` | Emit summary/trade/event/report files | HIGH | `BacktestRunner.run` | Runtime | Write-authoritative |
| `LiveEngine` | `process` | Live inference, gating, cooldown, alerts | HIGH | live integrations | Service | Transactional |
| `BitNetZoneGate` | `check` | Zone-based allow/reject gate | MED | `EngineRunner` helper and live engine | Cognition | Read-only with fail-open |
| `ConfigValidator` | `validate` | Candidate config backtest validation | HIGH | promotion workflow, CLI | Governance | Transactional |
| `PromotionManager` | `promote_from_tuner_checkpoint` | Candidate->validation->promotion workflow | HIGH | CLI/manual ops | Governance | Transactional |
| `PromotionManager` | `_write_to_registry` | Versioned production write + archive + log | HIGH | internal promotion flow | Governance | Write-authoritative |
| `GaussianModelRegistry` | `promote_gaussian` | Model promotion with schema-version guard | HIGH | training/model ops | Governance | Write-authoritative |
| `RRFusionLayer` | `score` | Advisory fusion with canonical feature checks | MED | `LiveEngine.process` | Cognition | Read-mostly |
| `ReflectionBuffer` | `load_and_merge` | Merge decision logs with trade outcomes | MED | governance scripts | Governance | Read/transform |
| `ShadowPromotionGate` | `execute_shadow_test` | Run candidate shadow backtest and compare PnL | ?? | governance scripts | Governance | Transactional scaffold |

## Class -> Method Map Snapshot (Non-trivial)

Status System: ✅ 🟡 🔴 🧪

- `EngineRunner`: `_get_gaussian_engine`, `__init__`, `_reject`, `run`
- `FeaturePipeline`: `_validate_input`, `compute_*`, `compute_canonical_*`, `finalize`, `build_feature_vector`, `run`
- `BacktestRunner`: `__init__`, `run`, `_session`, `_print_summary`
- `LiveEngine`: `__init__`, `process`, `dry_run`
- `ConfigValidator`: `validate`, `_apply_rejection_rules`, `_apply_warnings`, `_save_report`, `_print_decision`
- `PromotionManager`: `promote_from_report`, `promote_from_tuner_checkpoint`, `promote_direct`, `list_versions`, `load_version`, `_execute_promotion`, `_write_to_registry`

## Missing / Implied Appendix Entries

Status System: ✅ 🟡 🔴 🧪
- ?? `CRTEngine` family (`crt_engine_v2`) method table not included due missing audited context.
- ?? `MetaGovernorExecutor` and shadow governance classes are minimal and not production-hardened.

## Method Boundary Labels (Consolidated)

Status System: ✅ 🟡 🔴 🧪
- Safety Rails: `TrapValidatorEngine.compute`, `schema_validator.validate_*`, `FeatureStore._validate_schema`.
- Lifecycle Gatekeepers: `EngineRunner.run`, `BacktestRunner.run`, `ConfigValidator.validate`.
- Security/Governance Boundaries: `DecisionEngine.evaluate`, `production_config._verify_config_hash`, `PromotionManager._write_to_registry`.

