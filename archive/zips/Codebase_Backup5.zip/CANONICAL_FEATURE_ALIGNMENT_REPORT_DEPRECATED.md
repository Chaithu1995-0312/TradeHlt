# SELF-REVIEW REPORT — Canonical Feature Alignment Refactor

**Date:** 2026-04-02  
**Refactor Type:** Production-critical, strict canonical alignment  
**Files Modified:** `feature_schema.py`, `dataset_builder.py`, `zone_gate.py`, `zone_gate_engine.py`, `train_pipeline.py`, `bitnet/search_engine.py`

---

## 1. ASSUMPTIONS

- `CANONICAL_FEATURE_DIM = 27` is derived from the exact count of float positions produced by `extract_feature_vector()`. The `candle` dict (one FEATURE_SCHEMA key) expands into 4 floats (open, high, low, close), giving 23 FEATURE_SCHEMA keys + 3 extra from candle expansion = 27.
- `session` values are always lowercased before lookup. The accepted set is `{"london", "newyork", "asian", "overlap"}`.
- `trend_bias` values are always lowercased before lookup. The accepted set is `{"bullish", "bearish", "neutral"}`.
- `rejection_wick`, `volatility_flag`, `is_inside_bar` are always Python `bool` (not int 0/1). Explicit `isinstance(value, bool)` check enforces this.
- All numeric features accept both `int` and `float` in `validate_features()`, but are always cast to `float` in the vector.
- The index files loaded by `BitNetSearchEngine` were built with the same (or compatible) schema. Mismatches are caught on `_load_index()` startup.

---

## 2. INVARIANTS ENFORCED

| Invariant | Where Enforced |
|-----------|----------------|
| All FEATURE_SCHEMA keys present | `validate_features()` in `dataset_builder.py` |
| candle has open, high, low, close | `extract_feature_vector()` explicit check |
| session is in SESSION_MAP | `extract_feature_vector()` explicit `if session_raw not in SESSION_MAP` |
| trend_bias is in TREND_MAP | `extract_feature_vector()` explicit `if trend_raw not in TREND_MAP` |
| rejection_wick/volatility_flag/is_inside_bar are bool | `extract_feature_vector()` explicit isinstance check |
| vector length == CANONICAL_FEATURE_DIM | `assert len(vector) == CANONICAL_FEATURE_DIM` at end of `extract_feature_vector()` |
| CANONICAL_FEATURE_ORDER length matches CANONICAL_FEATURE_DIM | Module-level `assert` in `feature_schema.py` (fails at import time if violated) |
| Index entries have correct vector length | `BitNetSearchEngine._load_index()` checks each entry |
| Query vector has correct length | `BitNetSearchEngine.search()` assertion + `search_by_vector()` explicit check |

---

## 3. EDGE CASES HANDLED

- **Mixed-case session/trend_bias**: Both are `.lower()`'d before lookup. `"London"`, `"LONDON"`, `"loNdon"` all map correctly to `"london"`.
- **Unknown session/trend_bias**: Raises `ValueError` with the invalid value and the list of valid choices. No silent `-1.0` or `0.0` fallback.
- **Candle dict with extra keys**: Only `open`, `high`, `low`, `close` are extracted. Extra keys (e.g. `"volume"`) are silently ignored during candle expansion.
- **Empty index**: `BitNetSearchEngine` with an empty `[]` index is valid — `search()` returns `[]`.
- **Index with wrong vector length**: Caught in `_load_index()` at construction time, not at search time.
- **int values for float features**: Accepted by `validate_features()` (`isinstance(value, (int, float))`), then explicitly cast to `float` in vector construction.
- **Schema drift between index and codebase**: The `_load_index()` check prevents silent dimension mismatch from old index files.
- **Non-canonical keys in raw input to ZoneGateEngine**: `filter_canonical_inputs()` strips non-canonical keys before passing to `extract_feature_vector()`.

---

## 4. FAILURE MODES

| Failure Scenario | Behavior |
|------------------|----------|
| Missing FEATURE_SCHEMA key in input | `ValueError: Missing feature: <key>` from `validate_features()` |
| Wrong type for a feature | `TypeError: Feature '<key>' expected <type>, got <actual_type>` from `validate_features()` |
| Unknown session string | `ValueError: Unknown session value: '<val>'. Must be one of: [...]` |
| Unknown trend_bias string | `ValueError: Unknown trend_bias value: '<val>'. Must be one of: [...]` |
| Missing candle sub-key | `ValueError: Missing candle sub-keys: [<keys>]` |
| bool feature passed as int 0/1 | `TypeError: Feature '<key>' must be bool, got int` |
| Schema drift in extraction logic | `AssertionError` in `extract_feature_vector()` (catches dev-time bugs only) |
| Index file missing | `FileNotFoundError` from `BitNetSearchEngine._load_index()` |
| Index file not a list | `ValueError` from `BitNetSearchEngine._load_index()` |
| Index entry missing `features` | `ValueError` from `BitNetSearchEngine._load_index()` |
| Index entry has wrong dimension | `ValueError` from `BitNetSearchEngine._load_index()` |
| `search_by_vector()` called with wrong dimension | `ValueError` with clear message |
| Batch with invalid entry | Error propagates immediately (no swallowed exceptions) |
| CANONICAL_FEATURE_ORDER length != CANONICAL_FEATURE_DIM | `AssertionError` at `feature_schema.py` import time |

---

## 5. REMOVED BEHAVIORS (BREAKING CHANGES)

| Old Behavior | New Behavior |
|--------------|--------------|
| `session_map.get(session, -1.0)` — unknown session → `-1.0` | `ValueError` raised immediately |
| `trend_map.get(trend, 0.0)` — unknown trend_bias → `0.0` | `ValueError` raised immediately |
| `batch_zone_gate` swallows exceptions, logs warning, continues | Errors propagate immediately |
| `batch_zone_gate_engine` swallows exceptions, logs warning, continues | Errors propagate immediately |
| `extract_bitnet_features()` as primary function | Deprecated; delegates to `extract_feature_vector()` |

---

## 6. TEST CASES

### A. Happy Path

```python
features = {
    "atr": 0.0012,
    "rsi": 55.3,
    "macd": 0.0003,
    "macd_signal": 0.0001,
    "bb_upper": 1.2345,
    "bb_lower": 1.2100,
    "ema_fast": 1.2200,
    "ema_slow": 1.2150,
    "volume_ratio": 1.1,
    "session": "london",
    "candle": {"open": 1.2200, "high": 1.2250, "low": 1.2180, "close": 1.2230},
    "zone_strength": 0.85,
    "trend_bias": "bullish",
    "rejection_wick": True,
    "body_ratio": 0.6,
    "volatility_flag": False,
    "is_inside_bar": False,
    "momentum_score": 0.72,
    "spread_pct": 0.0002,
    "hour_of_day": 9.0,
    "day_of_week": 2.0,
    "pattern_score": 0.88,
    "sl_distance": 0.0030,
    "tp_ratio": 2.0,
}
vec = extract_feature_vector(features)
assert len(vec) == 27
assert vec[9] == 0.0   # session: london
assert vec[15] == 1.0  # trend_bias: bullish
assert vec[16] == 1.0  # rejection_wick: True
assert vec[18] == 0.0  # volatility_flag: False
```

### B. Missing Feature Key

```python
bad = dict(features)
del bad["rsi"]
# Must raise: ValueError: Missing feature: rsi
```

### C. Unknown Session

```python
bad = dict(features)
bad["session"] = "sydney"
# Must raise: ValueError: Unknown session value: 'sydney'. Must be one of: ['asian', 'london', 'newyork', 'overlap']
```

### D. Unknown Trend Bias

```python
bad = dict(features)
bad["trend_bias"] = "sideways"
# Must raise: ValueError: Unknown trend_bias value: 'sideways'. Must be one of: ['bearish', 'bullish', 'neutral']
```

### E. Bool Feature as Integer

```python
bad = dict(features)
bad["rejection_wick"] = 1  # int, not bool
# Must raise: TypeError: Feature 'rejection_wick' must be bool, got int
```

### F. Missing Candle Sub-Key

```python
bad = dict(features)
bad["candle"] = {"open": 1.22, "high": 1.225}  # missing low, close
# Must raise: ValueError: Missing candle sub-keys: ['low', 'close']
```

### G. Session Case-Insensitivity

```python
features_upper = dict(features)
features_upper["session"] = "LONDON"
vec = extract_feature_vector(features_upper)
assert vec[9] == 0.0  # london = 0.0
```

### H. Deprecated extract_bitnet_features

```python
import warnings
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter("always")
    vec = extract_bitnet_features(features)
    assert len(w) == 1
    assert issubclass(w[0].category, DeprecationWarning)
    assert "extract_feature_vector" in str(w[0].message)
```

### I. BitNetSearchEngine Dimension Assertion

```python
# Index file with wrong vector length should fail at construction
# (entry has 10 floats instead of 27)
import json, tempfile, os
bad_index = [{"features": [0.0] * 10, "label": 1}]
with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
    json.dump(bad_index, f)
    path = f.name
try:
    BitNetSearchEngine(path)  # Must raise ValueError
except ValueError as e:
    assert "10 features" in str(e) and "27" in str(e)
finally:
    os.unlink(path)
```

---

## 7. INTEGRATION NOTES

### Import Chain
```
feature_schema.py
    └── CANONICAL_FEATURE_ORDER, CANONICAL_FEATURE_DIM, SESSION_MAP, TREND_MAP
        └── dataset_builder.py (imports CANONICAL_FEATURE_DIM, SESSION_MAP, TREND_MAP)
            └── extract_feature_vector()
                ├── zone_gate.py          (imports extract_feature_vector)
                ├── zone_gate_engine.py   (imports extract_feature_vector)
                ├── train_pipeline.py     (imports extract_feature_vector)
                └── bitnet/search_engine.py (imports extract_feature_vector + CANONICAL_FEATURE_DIM)
```

### Existing Tests That May Need Updates

- `test_zone_gate.py` — if it relied on `batch_zone_gate` swallowing errors, tests must be updated to expect errors to propagate.
- `test_bitnet_inference.py` — if it uses `extract_bitnet_features` directly, it will now receive a `DeprecationWarning`.
- `test_schema_contracts.py` — should now also assert `len(extract_feature_vector(valid_features)) == 27`.
- Any test constructing a `BitNetSearchEngine` with a pre-existing index file must ensure those index files have 27-dim vectors.

### Rebuilding Index Files

If `models/bitnet/` contains pre-built index files with vectors of length ≠ 27, they must be rebuilt using `build_dataset()` (which now calls `extract_feature_vector()`) before `BitNetSearchEngine` can load them.

### Deprecation Timeline

`extract_bitnet_features()` is marked `DeprecationWarning`. It will produce the same output as `extract_feature_vector()` and should be removed in the next major refactor cycle. All internal callers have already been updated to use `extract_feature_vector()` directly.