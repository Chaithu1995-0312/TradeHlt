"""
EngineRunner — orchestrates the full pipeline.

PIPELINE ORDER (strict):
  1. Adapter gating (TrapValidatorEngine) — MUST pass; score <= 0.0 → hard reject
  2. All four engines run unconditionally (CRT, Gaussian, BitNet, RR)
  3. Engine completeness check — if ANY expected engine is absent → hard reject
  4. Fusion — combines all engine outputs into final_score
  5. Decision — threshold applied to final_score
  6. Collector — structured logging of every decision path

ENGINE COMPLETENESS POLICY:
  Fusion silently re-normalizes if engines are missing. To prevent a partial
  engine set from producing an ACCEPT, engine_runner enforces that ALL four
  engines must be present in engine_results before fusion is called.
"""

import logging
import os
from engines.adapter_engine import TrapValidatorEngine
from engines.crt_engine import compute as crt_compute
from engines.heuristic_gaussian_engine import HeuristicGaussianEngine
from engines.ml_gaussian_engine import MLGaussianEngine
from engines.zone_gate_engine import run_zone_gate_engine
from engines.rr_engine import RREngine
from core.fusion_engine import FusionEngine, GaussianAdapter
from core.decision_engine import DecisionEngine
from collector import Collector
from engines.live_engine import get_zone_gate
from utils.logging_config import get_flow_logger

logger = get_flow_logger("ENGINE_RUNNER")

EXPECTED_ENGINES = {"crt", "gaussian", "zone_gate", "rr"}

DUAL_ENGINE_DEFAULTS = {
    "trend_strength_threshold": 0.15,
    "momentum_threshold": 0.30,
    "range_volatility_threshold": 0.80,
    "breakout_min_score": 0.30,
    "trap_min_score": 0.40,
    "neutral_min_score": 0.45,
    "fusion_min_score": 0.25,
}


def _safe_float(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _signed_direction(value: float) -> int:
    if value > 0:
        return 1
    if value < 0:
        return -1
    return 0


def detect_regime(features: dict, cfg: dict) -> str:
    trend_strength = abs(_safe_float(features.get("ema_spread"), 0.0))
    momentum = abs(_safe_float(features.get("momentum_score"), 0.0))
    volatility = _safe_float(features.get("volatility_ratio"), 1.0)

    if (
        trend_strength >= _safe_float(cfg.get("trend_strength_threshold"), DUAL_ENGINE_DEFAULTS["trend_strength_threshold"])
        and momentum >= _safe_float(cfg.get("momentum_threshold"), DUAL_ENGINE_DEFAULTS["momentum_threshold"])
    ):
        return "trend"
    if volatility <= _safe_float(cfg.get("range_volatility_threshold"), DUAL_ENGINE_DEFAULTS["range_volatility_threshold"]):
        return "range"
    return "neutral"


def breakout_engine(features: dict, cfg: dict) -> dict:
    trend = _safe_float(features.get("trend_bias"), 0.0)
    momentum = abs(_safe_float(features.get("momentum_score"), 0.0))
    spread = abs(_safe_float(features.get("ema_spread"), 0.0))
    min_score = _safe_float(cfg.get("breakout_min_score"), DUAL_ENGINE_DEFAULTS["breakout_min_score"])

    score = min(1.0, max(0.0, (spread + momentum) / 2.0))
    direction = _signed_direction(trend)
    if score < min_score:
        direction = 0

    return {
        "engine": "breakout",
        "score": float(score),
        "direction": int(direction),
        "reason": "trend_follow" if direction != 0 else "weak_breakout",
        "meta": {
            "trend_bias": float(trend),
            "momentum": float(momentum),
            "ema_spread": float(spread),
        },
    }


def trap_engine(features: dict, cfg: dict) -> dict:
    sweep = _safe_float(features.get("sweep_detected"), 0.0)
    disp = max(0.0, _safe_float(features.get("disp_strength"), 0.0))
    trend = _safe_float(features.get("trend_bias"), 0.0)
    min_score = _safe_float(cfg.get("trap_min_score"), DUAL_ENGINE_DEFAULTS["trap_min_score"])

    if sweep <= 0:
        return {
            "engine": "trap",
            "score": 0.0,
            "direction": 0,
            "reason": "no_sweep",
            "meta": {"trend_bias": float(trend)},
        }

    score = min(1.0, disp)
    direction = -_signed_direction(trend)
    if score < min_score:
        direction = 0

    return {
        "engine": "trap",
        "score": float(score),
        "direction": int(direction),
        "reason": "liquidity_trap" if direction != 0 else "weak_trap",
        "meta": {
            "sweep_detected": int(sweep),
            "disp_strength": float(disp),
            "trend_bias": float(trend),
        },
    }


def ultron_governor(regime: str, dual_results: dict, cfg: dict) -> dict:
    breakout = dual_results.get("breakout", {})
    trap = dual_results.get("trap", {})
    neutral_min = _safe_float(cfg.get("neutral_min_score"), DUAL_ENGINE_DEFAULTS["neutral_min_score"])

    if regime == "trend":
        selected = breakout
        gate_reason = "regime_trend"
    elif regime == "range":
        selected = trap
        gate_reason = "regime_range"
    else:
        b_score = _safe_float(breakout.get("score"), 0.0)
        t_score = _safe_float(trap.get("score"), 0.0)
        b_dir = int(breakout.get("direction", 0))
        t_dir = int(trap.get("direction", 0))

        if b_score < neutral_min and t_score < neutral_min:
            return {"allow": False, "reason": "neutral_low_confidence", "selected": None}
        if b_score >= neutral_min and t_score >= neutral_min and b_dir != 0 and t_dir != 0 and b_dir != t_dir:
            return {"allow": False, "reason": "neutral_conflict", "selected": None}
        selected = breakout if b_score >= t_score else trap
        gate_reason = "regime_neutral_high_confidence"

    direction = int(selected.get("direction", 0))
    if direction == 0:
        return {"allow": False, "reason": f"{gate_reason}_no_direction", "selected": selected}

    return {
        "allow": True,
        "reason": gate_reason,
        "selected": selected,
    }


class EngineRunner:

    @staticmethod
    def _get_gaussian_engine(config: dict):
        """
        Instantiate the correct Gaussian engine based on GAUSSIAN_IMPL env var.

        Priority: env var GAUSSIAN_IMPL > config["gaussian_impl"] > default "heuristic"

        Values:
          "heuristic" → HeuristicGaussianEngine (EMA/momentum kernel)
          "ml"        → MLGaussianEngine (GaussianNBModel, 32-dim)
        """
        impl = os.getenv(
            "GAUSSIAN_IMPL",
            config.get("gaussian_impl", "heuristic") if isinstance(config, dict) else "heuristic"
        ).lower()

        if impl == "ml":
            logger.info("EngineRunner: using MLGaussianEngine (GAUSSIAN_IMPL=ml)")
            return MLGaussianEngine(config)
        else:
            logger.info("EngineRunner: using HeuristicGaussianEngine (GAUSSIAN_IMPL=%s)", impl)
            return HeuristicGaussianEngine(config)

    def __init__(self, config: dict):
        self.config = config
        self.adapter = TrapValidatorEngine(config)
        #self.crt = CRTEngine(config)
        self.gaussian = self._get_gaussian_engine(config)
        self.rr = RREngine(config)
        # Wrap GaussianEngine in GaussianAdapter so FusionEngine.evaluate()
        # uses a real scorer instead of a neutral 0.5 stub.
        # GaussianAdapter.score() delegates to GaussianEngine.compute().
        self._gaussian_adapter = GaussianAdapter(self.gaussian)
        self.fusion = FusionEngine(gaussian_adapter=self._gaussian_adapter)
        self.decision = DecisionEngine(config)
        self.collector = Collector()
        dual_cfg = config.get("dual_engine", {}) if isinstance(config, dict) else {}
        self.dual_cfg = {**DUAL_ENGINE_DEFAULTS, **(dual_cfg or {})}
        # BitNet zone gate — lazy-loaded singleton; fail-open if registry missing
        zone_registry_path = (
            config.get("zone_registry_path", "models/zone_registry.json")
            if isinstance(config, dict) else "models/zone_registry.json"
        )
        self._zone_gate = get_zone_gate(zone_registry_path)

    def _reject(
        self,
        reason: str,
        input_data: dict = None,
        actual_pnl: float | None = None,
        adapter_result: dict = None,
        engine_results: dict = None,
        fusion_result: dict | None = None,
        dual_results: dict | None = None,
        gate_result: dict | None = None,
    ) -> dict:
        """Build a standardised REJECT record and log it."""
        def _infer_stage(reject_reason: str) -> str:
            r = str(reject_reason or "")
            if r.startswith("adapter_") or r.startswith("data_integrity") or r.startswith("missing_fields") \
               or r.startswith("invalid_session") or r.startswith("low_atr") or r.startswith("non_positive_atr"):
                return "adapter"
            if r.startswith("zone_gate"):
                return "zone_gate"
            if r.startswith("ultron_gate"):
                return "ultron"
            if r.startswith("incomplete_engine_execution") or r.startswith("fusion_missing_engines") \
               or r.startswith("low_fusion_score"):
                return "fusion"
            if r in {"low_score", "low_probability", "low_rr", "weak_setup"}:
                return "decision"
            return "unknown"

        reject_stage = _infer_stage(reason)
        record = {
            "adapter": adapter_result or {},
            "engines": engine_results or {},
            "fusion": fusion_result or {},
            "dual_engines": dual_results or {},
            "gate": gate_result or {},
            "final_score": _safe_float((fusion_result or {}).get("final_score"), 0.0),
            "decision": "REJECT",
            "reason": reason,
            "reject_stage": reject_stage,
            "features": input_data or {},
            "pnl": actual_pnl,
        }
        self.collector.log(record)
        return {
            "decision": "REJECT",
            "reason": reason,
            "score": _safe_float((fusion_result or {}).get("final_score"), 0.0),
            "regime": (gate_result or {}).get("regime"),
            "selected_engine": ((gate_result or {}).get("selected") or {}).get("engine"),
            "reject_stage": reject_stage,
        }

    def run(self, input_data: dict, context: dict, actual_pnl: float | None = None) -> dict:
        # ------------------------------------------------------------------ #
        # Step 1: Adapter gating                                              #
        # ------------------------------------------------------------------ #
        merged = {**input_data, **(context or {})}
        adapter_result = self.adapter.compute(merged)
        

        # Use <= 0.0 to guard against floating-point values like -0.0 or tiny
        # negatives from future adapter extensions, without relying on == 0.0.
        if adapter_result.get("score", 1.0) <= 0.0:
            reason = adapter_result.get("reason", "adapter_rejected")
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
            )

        # ------------------------------------------------------------------ #
        # Step 2: Run ALL engines unconditionally                             #
        # ------------------------------------------------------------------ #
        
        zonegate_input = {**input_data, **(context or {})}

        _zone_threshold = float(
            self.config.get("bitnet_zone_threshold", 0.5)
            if isinstance(self.config, dict) else 0.5
        )

        def _zone_model_fn(vector: list) -> float:
            """Score via BitNetZoneGate. Returns 0.5 on any error (neutral, non-blocking)."""
            try:
                result = self._zone_gate.check(vector)
                return float(result.get("score", 0.5))
            except Exception as _e:
                logger.debug(f"ZoneGate scoring fallback (0.5): {_e}")
                return 0.5

        zone_raw = run_zone_gate_engine(
            raw_features=zonegate_input,
            model_fn=_zone_model_fn,
            threshold=_zone_threshold
        )

        zone_result = {
            "engine": "zone_gate",
            "score": float(zone_raw.get("score", 0.0)),
            "direction": 1 if zone_raw.get("passed") else 0,
            "meta": zone_raw,
        }
        engine_results = {
            "crt": crt_compute(trade_id="Test:",features=input_data,context={}),
            "gaussian": self.gaussian.compute(input_data),
            "zone_gate": zone_result,
            "rr": self.rr.compute(input_data),
        }

        # ------------------------------------------------------------------ #
        # Step 3: Engine completeness check                                   #
        # ------------------------------------------------------------------ #
        missing_engines = EXPECTED_ENGINES - engine_results.keys()
        if missing_engines:
            reason = f"incomplete_engine_execution:{sorted(missing_engines)}"
            logger.error(f"EngineRunner: {reason}")
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
                engine_results=engine_results,
            )

        # ------------------------------------------------------------------ #
        # Step 4: Fusion                                                      #
        # ------------------------------------------------------------------ #
        fusion_result = self.fusion.compute(engine_results)

        # Also reject if fusion itself detected missing engines (defensive)
        if fusion_result.get("missing_engines"):
            reason = f"fusion_missing_engines:{fusion_result['missing_engines']}"
            logger.error(f"EngineRunner: {reason}")
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
                engine_results=engine_results,
            )

        # ------------------------------------------------------------------ #
        # Step 5: Fusion baseline decision                                    #
        # ------------------------------------------------------------------ #
        final_score = _safe_float(fusion_result.get("final_score"), 0.0)
        if final_score < _safe_float(self.dual_cfg.get("fusion_min_score"), DUAL_ENGINE_DEFAULTS["fusion_min_score"]):
            reason = "low_fusion_score"
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
                engine_results=engine_results,
                fusion_result=fusion_result,
            )

        # ------------------------------------------------------------------ #
        # Step 6: Dual-engine regime gate (Ultron)                            #
        # ------------------------------------------------------------------ #
        regime = detect_regime(input_data, self.dual_cfg)
        dual_results = {
            "breakout": breakout_engine(input_data, self.dual_cfg),
            "trap": trap_engine(input_data, self.dual_cfg),
        }
        gate_result = ultron_governor(regime, dual_results, self.dual_cfg)
        gate_result["regime"] = regime

        if not gate_result.get("allow", False):
            reason = f"ultron_gate:{gate_result.get('reason', 'blocked')}"
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
                engine_results=engine_results,
                fusion_result=fusion_result,
                dual_results=dual_results,
                gate_result=gate_result,
            )

        # ------------------------------------------------------------------ #
        # Step 7: DecisionEngine — FINAL authority (Issue 5 fix)             #
        # DecisionEngine.evaluate() is the ONLY place that emits             #
        # "execute" or "reject". EngineRunner NEVER returns "Approved".      #
        # ------------------------------------------------------------------ #
        selected = gate_result.get("selected", {})
        p_win = _safe_float(
            engine_results.get("gaussian", {}).get("score"), 0.5
        )
        zone_gate_ctx = {
            "valid": bool(zone_result.get("passed", False)),
            "score": _safe_float(zone_result.get("score"), 0.0),
        }
        fusion_ctx = {
            # DecisionEngine expects a true RR ratio (e.g. >= 1.2),
            # not the normalized RR score used by fusion averaging.
            "rr": _safe_float(
                engine_results.get("rr", {}).get("rr_ratio"),
                _safe_float(engine_results.get("rr", {}).get("score"), 0.0),
            ),
            "weak_component": max(
                0.0,
                1.0 - _safe_float(fusion_result.get("final_score"), 0.0),
            ),
        }

        decision_result = self.decision.evaluate(
            score=final_score,
            p_win=p_win,
            zone_gate=zone_gate_ctx,
            fusion=fusion_ctx,
            config=self.config,
        )
        # Attach routing metadata (read-only — does NOT change the decision)
        decision_result["regime"] = regime
        decision_result["selected_engine"] = selected.get("engine")
        decision_result["selected_direction"] = selected.get("direction", 0)
        decision_result["dual_score"] = _safe_float(selected.get("score"), 0.0)
        decision_result["gate_reason"] = gate_result.get("reason", "")
        decision_result["final_score"] = final_score
        decision_result["reject_stage"] = (
            "decision" if str(decision_result.get("decision", "")).lower() == "reject" else "none"
        )

        # ------------------------------------------------------------------ #
        # Step 8: Log full record                                             #
        # ------------------------------------------------------------------ #
        self.collector.log({
            "adapter": adapter_result,
            "engines": engine_results,
            "fusion": fusion_result,
            "dual_engines": dual_results,
            "gate": gate_result,
            "final_score": final_score,
            "decision": decision_result.get("decision", "UNKNOWN"),
            "reason": decision_result.get("reason", ""),
            "reject_stage": decision_result.get("reject_stage", "none"),
            "missing_engines": [],
            "features": input_data,
            "pnl": actual_pnl,
        })

        return decision_result
