"""
zone_gate_engine.py – BitNet Zone Gate with strict schema validation but fail‑open on registry errors.
"""

from __future__ import annotations

import logging
from typing import Callable, List

from features.feature_schema import CANONICAL_FEATURE_ORDER, CANONICAL_FEATURE_DIM
from zone_schema_migrator import validate_zone_schema, ZoneSchemaError

logger = logging.getLogger(__name__)

CANONICAL_KEYS: List[str] = list(CANONICAL_FEATURE_ORDER)


def filter_canonical_inputs(raw: dict) -> dict:
    missing = [k for k in CANONICAL_KEYS if k not in raw]
    if missing:
        raise ValueError(f"Missing canonical keys: {missing}")
    return {k: raw[k] for k in CANONICAL_KEYS}


def _extract_vector(features: dict) -> list:
    try:
        vector = [float(features[k]) for k in CANONICAL_KEYS]
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Feature value coercion failed: {exc}") from exc
    assert len(vector) == CANONICAL_FEATURE_DIM, (
        f"Vector length mismatch: expected {CANONICAL_FEATURE_DIM}, got {len(vector)}"
    )
    return vector


def run_zone_gate_engine(
    raw_features: dict,
    model_fn: Callable,
    threshold: float = 0.5,
    zone_registry: dict | None = None,
) -> dict:
    # Step 1: Canonical input validation – fail closed
    try:
        features = filter_canonical_inputs(raw_features)
    except (ValueError, TypeError, AssertionError) as e:
        logger.error("ZoneGate: canonical input error – %s. Blocking.", e)
        return {"score": 0.0, "passed": False, "vector": [], "valid": False}

    # Step 2: Registry validation – fail‑open (neutral) on any error
    if zone_registry is not None:
        try:
            validate_zone_schema(zone_registry)
        except (ZoneSchemaError, FileNotFoundError, TypeError, ValueError) as e:
            logger.warning("ZoneGate: zone registry error – %s. Returning neutral 0.5, passed=True.", e)
            return {
                "score": 0.5,
                "passed": True,
                "vector": [],
                "valid": True,
            }

    # Step 3: Extract vector and score – fail closed on extraction errors
    try:
        vector = _extract_vector(features)
        score = float(model_fn(vector))
        passed = score >= threshold
        return {
            "score": score,
            "passed": passed,
            "vector": vector,
            "valid": passed,
        }
    except (ValueError, TypeError, AssertionError) as e:
        logger.error("ZoneGate: vector extraction or scoring error – %s. Blocking.", e)
        return {"score": 0.0, "passed": False, "vector": [], "valid": False}