﻿# RULES_AND_INVARIANTS

Status System: ✅ 🟡 🔴 🧪

## Status Legend

Status System: ✅ 🟡 🔴 🧪
- ? Enforced
- ?? Enforced inconsistently
- ?? Missing from context/not enforced
- ?? Implied/test-only

## Global Invariants

Status System: ✅ 🟡 🔴 🧪
- ? Canonical feature keys must match schema exactly (`schema_validator.validate_features`).
- ? Decision authority for engine runner path is centralized (`DecisionEngine.evaluate`).
- ? Adapter gate rejects non-real/incomplete feature frames (`_data_integrity`, ATR/session checks).
- ? Promotion pipeline writes versioned JSON with config hash.
- ?? Canonical feature dimension docs drift (24/32 in comments, 35 in schema constants).

## Agent Safety Rails (Mandatory)

Status System: ✅ 🟡 🔴 🧪

### Do Not Touch Zones

Status System: ✅ 🟡 🔴 🧪
- `features/feature_schema.py`
  - Do not reorder/remove canonical fields without coordinated migration across pipeline, training, zone gate, and tests.
- `core/decision_engine.py`
  - Do not bypass `evaluate` with alternate decision emitters in runtime paths.
- `promotion_manager.py` and `production_config.py`
  - Do not bypass hash generation/verification for production configs.
- `core/engine_runner.py`
  - Do not remove engine completeness check before fusion.

### Mandatory Verification Hooks

Status System: ✅ 🟡 🔴 🧪
- Before inference:
  - `validate_features(...)`
  - `validate_feature_values(...)`
  - `validate_vector(...)`
- Before production config use:
  - `_assert_registry_exists`
  - `_verify_config_hash`
- Before promotion:
  - `ConfigValidator.validate(...).decision == APPROVE`
- Before live alerts:
  - `LiveEngineConfig.validate`
  - kill-switch check (`LIVE_ENGINE_ENABLED`)

## Lifecycle Gatekeepers / Write Boundaries

Status System: ✅ 🟡 🔴 🧪
- ? `EngineRunner._reject` and final collector log boundary.
- ? `BacktestRunner.run` (trade journal + report writes).
- ? `PromotionManager._write_to_registry` (production writes).
- ? `Collector.log` / `collect` (audit trail append).

## Security / Governance Boundaries

Status System: ✅ 🟡 🔴 🧪
- ? Hash-based tamper detection in production config loading.
- ?? Hardcoded default Telegram token/chat in env loader are sensitive defaults and should be treated as security debt.
- ?? `MetaGovernorExecutor.run_inference` runs subprocess with file prompt and no sandbox policy in module itself.

## State Invariants by Transition

Status System: ✅ 🟡 🔴 🧪
- ? Feature state:
  - `RawOHLCV -> EnrichedFrame -> CanonicalFeatureFrame -> Vector`
  - invariant: no missing canonical keys at final stage.
- ? Decision state:
  - `Gated -> Fused -> UltronChecked -> DecisionIssued`
  - invariant: if any gate fails, decision must be reject.
- ? Promotion state:
  - `ValidatedReport(APPROVE) -> RegistryEntry(versioned,hashed) -> RuntimeLoad(verified)`
  - invariant: runtime load refuses absent registry or hash mismatch.

## Rule Violations / Drift Signals

Status System: ✅ 🟡 🔴 🧪
- ?? Terminology drift (`execute/reject` vs `ACCEPT/BLOCK`) across modules/logs.
- ?? Feature-dimension drift between comments and effective schema.
- ?? Shadow promotion file contains explicit comments describing missing production wiring.

## Operational Guardrails for Autonomous Refactoring

Status System: ✅ 🟡 🔴 🧪
- Keep these checks green after any refactor:
  - `test_engine_runner_dual_gate.py`
  - `test_zone_gate.py`
  - `test_feature_pipeline.py`
  - `test_schema_contracts.py`
  - `test_fusion_and_validator_regression.py`
- Never merge refactors that alter canonical ordering without schema checksum/version bump and migration plan.
- Preserve append-only behavior for promotion logs and collector logs.

