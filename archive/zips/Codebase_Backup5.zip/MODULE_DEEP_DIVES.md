﻿# MODULE_DEEP_DIVES

Status System: ✅ 🟡 🔴 🧪

## Status Legend

Status System: ✅ 🟡 🔴 🧪
- ? Implemented
- ?? Partial/Drift
- ?? Missing from context
- ?? Mocked/Implied

## Deep Dive 1: `core/engine_runner.py`

Status System: ✅ 🟡 🔴 🧪

### Control Flow

Status System: ✅ 🟡 🔴 🧪
1. Adapter gate (`TrapValidatorEngine.compute`) hard-blocks invalid frames.
2. All engines run unconditionally (`crt`, `gaussian`, `zone_gate`, `rr`).
3. Completeness check rejects missing engine outputs.
4. `FusionEngine.compute` produces aggregate score.
5. Baseline fusion minimum threshold checked.
6. Dual-engine regime gate (`breakout`, `trap`, `ultron_governor`).
7. Final authority: `DecisionEngine.evaluate`.
8. Collector persists final structured record.

### Method Intelligence Table: `EngineRunner`

Status System: ✅ 🟡 🔴 🧪

| Method Name | Responsibility | Risk Profile | Inputs/Outputs | Idempotency | State Impact | Validation/Invariants |
|---|---|---|---|---|---|---|
| `_get_gaussian_engine` | Runtime implementation selection (`heuristic` vs `ml`) | LOW | `config -> engine` | ? | none | env override precedence |
| `__init__` | Construct full dependency graph | MED | `config -> runner` | ? | object member init | expected engines initialized |
| `_reject` | Canonical reject payload + collector write | MED | reject context -> reject response | ? | collector append | normalized reject shape |
| `run` | End-to-end decision orchestration | HIGH | `input_data, context -> decision` | ?* | collector/log writes | adapter pass, completeness, fusion, gate, final decision constraints |
| `_zone_model_fn` (nested) | Score helper for zone gate | LOW | `vector -> score` | ? | none | fail-safe fallback 0.5 |

`*` deterministic for same inputs/config; impacted by external model behavior if model path changes.

### Method Usage Graph

Status System: ✅ 🟡 🔴 🧪
- `run` callers: `runtime/backtest_bitnet.run_backtest`, test modules.
- Layer: Service/Cognition boundary.
- Type: Transactional + write-authoritative logging.

### Boundary Labels

Status System: ✅ 🟡 🔴 🧪
- Safety Rails: adapter gate and engine completeness checks.
- Lifecycle Gatekeeper: `_reject` standardizes all failure exits.
- Governance Boundary: handoff to `DecisionEngine.evaluate` as final authority.

```mermaid
sequenceDiagram
  participant BT as Backtest/Caller
  participant ER as EngineRunner.run
  participant AD as TrapValidatorEngine
  participant EG as Engines(crt/gaussian/zone/rr)
  participant FU as FusionEngine
  participant UG as Ultron Gate
  participant DE as DecisionEngine
  participant CO as Collector

  BT->>ER: run(input_data, context)
  ER->>AD: compute(merged)
  AD-->>ER: pass/reject
  alt adapter reject
    ER->>CO: log(reject)
    ER-->>BT: REJECT
  else pass
    ER->>EG: compute all engines
    ER->>FU: compute(engine_results)
    FU-->>ER: final_score
    ER->>UG: detect_regime + governor
    UG-->>ER: allow/block
    alt gate block
      ER->>CO: log(reject)
      ER-->>BT: REJECT
    else allow
      ER->>DE: evaluate(score,p_win,zone,fusion,config)
      DE-->>ER: execute/reject
      ER->>CO: log(final)
      ER-->>BT: decision
    end
  end
```

## Deep Dive 2: `features/feature_pipeline.py`

Status System: ✅ 🟡 🔴 🧪

### Control Flow

Status System: ✅ 🟡 🔴 🧪
- Input validation -> base feature computation -> canonical feature computation -> cleanup -> vector extraction.
- Canonical feature list is consumed directly from `CANONICAL_FEATURES`; no local ordering authority.

### Method Intelligence Table: `FeaturePipeline`

Status System: ✅ 🟡 🔴 🧪

| Method Name | Responsibility | Risk Profile | Inputs/Outputs | Idempotency | State Impact | Validation/Invariants |
|---|---|---|---|---|---|---|
| `_validate_input` | Ensure required OHLC columns and numeric conversion | MED | `df -> validated df` | ? | mutates internal `df` | required columns, volume fallback |
| `compute_*` family | Build price/volume/indicator/context/structure features | MED | `df -> enriched df` | ? | mutates `df` in place | sequential dependency across stages |
| `compute_canonical_*` family | Map intermediates into canonical fields | MED | `df -> canonical cols` | ? | mutates `df` | canonical columns must be finite and aligned |
| `finalize` | Replace inf, drop NaN canonical rows | MED | `df -> clean df` | ? | row removal | canonical subset enforced |
| `build_feature_vector` | Build float32 matrix in canonical order | LOW | `df -> np.ndarray` | ? | none | width, NaN, dtype checks |
| `run` | Execute full pipeline in strict order | MED | `raw df -> (df,vectors)` | ? | cumulative internal mutation | full canonical availability at end |

### Method Usage Graph

Status System: ✅ 🟡 🔴 🧪
- `FeaturePipeline.run` callers: `runtime/backtest_bitnet.py`, `runtime/backtest_v2.py` initializer path, tests.
- Layer: Ingestion.
- Type: Stateful transform.

### Boundary Labels

Status System: ✅ 🟡 🔴 🧪
- Safety Rails: `_validate_input`, `build_feature_vector` assertions.
- Lifecycle Gatekeeper: `run` orchestrates stage ordering.
- Security/Governance: schema consistency impacts all downstream model decisions.

## Deep Dive 3: `runtime/backtest_v2.py`

Status System: ✅ 🟡 🔴 🧪

### Control Flow Highlights

Status System: ✅ 🟡 🔴 🧪
- CLI composes `BacktestConfig`.
- `BacktestRunner.run` loops candles with warmup, HTF aggregation, gap detection, spread/slippage modeling, trade open/close journaling.
- Metrics + report writers serialize summary/trades/events/report files.

### Method Intelligence Table (Core Classes)

Status System: ✅ 🟡 🔴 🧪

| Class.Method | Responsibility | Risk | Inputs/Outputs | Idempotency | State Impact | Validation/Invariants |
|---|---|---|---|---|---|---|
| `BacktestRunner.run` | full replay and trade lifecycle | HIGH | candle stream -> `BacktestMetrics` | ?* | writes files, journal, capital state | warmup/init/gap logic, action routing |
| `CapitalCurve.apply_trade` | update equity and drawdown trajectory | HIGH | pnl per unit + size -> capital | ? | mutates equity curve | peak/drawdown tracking invariants |
| `SlippageModel.compute_fill_prices` | compute adverse fills and costs | MED | raw prices/direction/atr -> fill tuple | ? (randomized) | RNG state advances | adverse slippage rule |
| `TradeJournal.on_trade_opened/closed` | persist trade event lifecycle | HIGH | trade + candle context | ? | open/closed/rejection collections | trade closure reason normalization |
| `MetricsEngine.compute` | aggregate performance metrics | MED | journal/capital -> metrics | ? | none | sample counts, dd and pnl derivation |
| `ReportWriter.write_all` | emit output artifacts | HIGH | metrics/journal/events -> file paths | ? | disk writes | consistent report schema |

`*` deterministic when seed/config/data fixed.

### State Diagram

Status System: ✅ 🟡 🔴 🧪

```mermaid
stateDiagram-v2
  [*] --> Warmup
  Warmup --> Initialize : warmup_candles reached
  Initialize --> Running : HTF seed ready
  Running --> TradeOpen : action contains TRADE_OPENED
  TradeOpen --> TradeClosed : STOPPED/TP2/RESET/GAP/BACKTEST_END
  Running --> Rejected : action starts RISK_REJECTED
  Rejected --> Running
  TradeClosed --> Running
  Running --> Finalize : end of candles
  Finalize --> [*]
```

## Deep Dive 4: Governance Write Boundary (`config_validator.py`, `promotion_manager.py`, `production_config.py`)

Status System: ✅ 🟡 🔴 🧪

### Method Intelligence (Key)

Status System: ✅ 🟡 🔴 🧪

| Class.Method | Responsibility | Risk | Inputs/Outputs | Idempotency | State Impact | Validation/Invariants |
|---|---|---|---|---|---|---|
| `ConfigValidator.validate` | validate candidate params over instruments | HIGH | params+csv map -> report dict | ? | writes approved/rejected report JSON | hard reject criteria enforced |
| `ConfigValidator._apply_rejection_rules` | convert metrics to rejection reasons | MED | scores/metrics -> report flags | ? | mutates report | score/trade/dd thresholds |
| `PromotionManager._execute_promotion` | build normalized promotion payload | HIGH | approved report -> registry entry | ? | prepares write event | requires params + validation summary |
| `PromotionManager._write_to_registry` | write production config and log promotion | HIGH | entry -> filesystem update | ? | archive+write+log | versioned file and hash embed |
| `production_config.load_prod_config_from_registry` | load and hash-verify production params | HIGH | version+instrument -> `CRTConfig` | ? | none | registry existence + hash integrity |

### Cross-Class Interaction

Status System: ✅ 🟡 🔴 🧪
- `PromotionManager` consumes `ConfigValidator` reports.
- `production_config` consumes promotion output files and verifies integrity prior to runtime.
- This trio forms governance lifecycle gate and write authority.

## Missing / Implied Methods

Status System: ✅ 🟡 🔴 🧪
- ?? `governance.shadow_promotion_gate.execute_shadow_test` describes required config wiring not fully implemented.
- ?? Missing audited method map for `crt_engine_v2` internals; behavior referenced but not included in current context.

