﻿# FILE_INDEX

Status System: ✅ 🟡 🔴 🧪

## Status Legend

Status System: ✅ 🟡 🔴 🧪
- ? Implemented (class/function present in source)
- ?? Partial/contract drift risk
- ?? MISSING_FROM_CONTEXT (file not deep-audited behavior)
- ?? Test/mock/scaffold-heavy

## File Index (Classes -> Methods, Entry Points, Risk)

Status System: ✅ 🟡 🔴 🧪

| File | Entry Points | Classes -> Methods Summary (Risk Profile) | Status |
|---|---|---|---|
| _compute_hash.py | Library/API | No class/function inventory | ? |
| auto_tuner.py | CLI __main__, argparse | TunerResult[to_dict](LOW); ResultStore[__init__, add, is_duplicate, mark_seen, valid, top_n, best, score_distribution, top_20pct_configs, save, load](MED); AutoTuner[__init__, run, resume, _run_phase, _run_cross_validation, _checkpoint, _save_final_report, _params_str](HIGH); MultiInstrumentTuner[__init__, run](HIGH) | ? |
| auto_tuner_gemin_pro.py | CLI __main__, argparse | TunerResult[to_dict](LOW); ResultStore[__init__, add, is_duplicate, mark_seen, valid, top_n, best, top_20pct_configs, save, load](MED); AutoTuner[__init__, run, _run_phase, _run_oos_validation, _run_cross_validation, _print_progress, _checkpoint, _save_final_report, _params_str](HIGH) | ? |
| auto_tuner_multi.py | CLI __main__, argparse | TunerResult[to_dict](LOW); ResultStore[__init__, add, is_duplicate, mark_seen, valid, top_n, best, top_20pct_configs, save, load](MED); AutoTuner[__init__, run, _run_phase, _run_oos_validation, _extract_display_metrics, _print_progress, _checkpoint, _save_final_report, _params_str](HIGH) | ? |
| bitnet\__init__.py | Library/API | No class/function inventory | ? |
| bitnet\_smoke_test.py | CLI __main__ | No class; functions=7 | ?? |
| bitnet\forward_tester.py | Library/API | ForwardTester[__init__, split, validate, filter_passed](LOW) | ? |
| bitnet\search_engine.py | Library/API | ZoneCandidate[__init__, to_dict, from_dict, __repr__](LOW); ZoneResult[__init__, to_registry_dict, __repr__](LOW); BitNetSearchEngine[__init__, _load_index, search, search_by_vector](MED) | ? |
| bitnet\stability_checker.py | Library/API | StabilityChecker[check, stability_score_only](LOW) | ? |
| bitnet\zone_validator.py | Library/API | ZoneValidator[check, is_valid, with_thresholds](LOW) | ? |
| bitnet_inference.py | Library/API | BitNetModel[__init__, predict, _forward_export, _linear, _activation, _sigmoid, forward](LOW) | ? |
| build_m15_unified.py | CLI __main__ | No class; functions=6 | ? |
| build_rr_dataset.py | CLI __main__, argparse | No class; functions=3 | ? |
| collector.py | Library/API | Collector[__init__, log](MED) | ? |
| compare.py | Library/API | No class; functions=1 | ? |
| config_builder.py | CLI __main__ | ConfigBuilder[build, from_existing, market_type, validate_divergence](LOW) | ? |
| config_validator.py | CLI __main__, argparse | InstrumentResult[to_dict](LOW); ValidationReport[to_dict](LOW); ConfigValidator[validate, _apply_rejection_rules, _apply_warnings, _save_report, _print_decision](HIGH) | ? |
| convert_binance_m1_to_m15.py | Library/API | No class/function inventory | ? |
| core\decision_engine.py | Library/API | DecisionResult[to_dict](LOW); DecisionEngine[__init__, evaluate, reject, _get_cfg](LOW) | ? |
| core\engine_runner.py | Library/API | EngineRunner[_get_gaussian_engine, __init__, _reject, run, _zone_model_fn](HIGH) | ? |
| core\feature_store.py | Library/API | FeatureFrame[to_dict](LOW); FeatureStore[__init__, process, get_history, _merge_inputs, _ensure_required, _compute_derived, _validate_schema](HIGH) | ? |
| core\fusion_engine.py | Library/API | FusionConfig(no methods;LOW); FusionResult[to_dict](LOW); GaussianAdapter[__init__, score](LOW); FusionEngine[__init__, compute, _extract_score, evaluate, _decide](LOW) | ? |
| crt_gaussian_scorer.py | Library/API | CRTGaussianScorer[__init__, _gaussian, _p_win, compute, _reject, extract_features](LOW) | ? |
| dataset_builder.py | Library/API | No class; functions=7 | ? |
| dataset_validator.py | Library/API | ValidationReport[is_trainable, print](LOW) | ? |
| engines\adapter_engine.py | Library/API | TrapValidatorEngine[__init__, compute](LOW) | ? |
| engines\crt_engine.py | Library/API | No class; functions=2 | ? |
| engines\gaussian_engine.py | Library/API | No class/function inventory | ? |
| engines\heuristic_gaussian_engine.py | Library/API | GaussianRegistry[__init__, load, _artifact_exists, _resolve_with_fallback, active_version, active_entry, mu, sigma](MED); HeuristicGaussianEngine[__init__, _load_registry, mu, sigma, compute](MED) | ? |
| engines\live_engine.py | CLI __main__ | BitNetZoneGate[__init__, from_path, disabled, _load_registry, is_loaded, check, reload](MED); LiveEngineConfig[from_env, validate](LOW); _AlertState[__init__, _setup_hash, should_alert, record](LOW); LiveEngine[__init__, process, dry_run](HIGH) | ? |
| engines\llm_engine.py | Library/API | No class; functions=1 | ? |
| engines\ml_gaussian_engine.py | Library/API | MLGaussianEngine[__init__, _load_model, compute](MED) | ? |
| engines\rr_engine.py | Library/API | RREngine[__init__, compute](LOW) | ? |
| engines\scoring_engine.py | Library/API | ScoringEngine[__init__, _should_trigger_llm, attach_reporter, compute, score, _maybe_report](LOW) | ? |
| engines\zone_gate_engine.py | Library/API | No class; functions=3 | ? |
| execution_planner.py | CLI __main__ | ExecutionPlannerV1_2[__init__, plan, _validate_features, _validate_prices, _derive_intent, _compute_entry, _compute_sl, _compute_tp](LOW) | ? |
| export_model.py | CLI __main__ | No class; functions=1 | ? |
| features\feature_builder.py | Library/API | FeatureBuilder[__init__, build](LOW) | ? |
| features\feature_monitor.py | CLI __main__ | FeatureMonitor[__init__, update, _compute_stats, detect_drift, detect_drift_severity, stats, summary, reset, __len__, __repr__](LOW) | ? |
| features\feature_pipeline.py | Library/API | FeaturePipeline[__init__, _validate_input, compute_price_features, compute_volume_features, compute_indicators, compute_trend_features, compute_volatility_regime, compute_context, compute_structure_liquidity, compute_normalization, compute_canonical_price_features, compute_canonical_volatility_features, compute_canonical_ema_features, compute_canonical_trend_features, compute_canonical_structure_features, compute_canonical_temporal_features, compute_canonical_session, finalize, log_critical_feature_health, build_feature_vector, run](HIGH) | ? |
| features\feature_schema.py | Library/API | SchemaObject[__init__, __getitem__, get, __contains__, keys, values, items, __repr__](LOW); SchemaVersionError(no methods;LOW) | ?? |
| features\schema_validator.py | Library/API | No class; functions=3 | ? |
| gen_dummy_trades.py | CLI __main__ | No class; functions=1 | ? |
| generate_vectors.py | CLI __main__ | No class; functions=2 | ? |
| governance\exectue_governance_scripts.py | Library/API | No class/function inventory | ?? |
| governance\meta_governor_executor.py | Library/API | MetaGovernorExecutor[__init__, run_inference, extract_and_validate_config](HIGH) | ?? |
| governance\meta_governor_runner.py | Library/API | No class; functions=2 | ?? |
| governance\reflection_buffer_advanced.py | Library/API | ReflectionBuffer[__init__, load_and_merge, generate_prompt_payload](MED) | ?? |
| governance\reflection_buffer_basic.py | Library/API | ReflectionBuffer[__init__, generate_reflection_set](LOW) | ?? |
| governance\shadow_promotion_gate.py | Library/API | ShadowPromotionGate[__init__, stage_candidate, execute_shadow_test, promote_if_superior](HIGH) | ?? |
| insight_reporter.py | CLI __main__ | InsightReporter[__init__, trade_decision, session_summary, eval_report, _get, backtest_summary, regime_alert, save, clear, _generate, _record](MED) | ? |
| llama_gate.py | Library/API | LLMEndpointUnavailableError(no methods;LOW) | ? |
| manual_backtest.py | CLI __main__, argparse | DynamicThreshold[__init__, update, threshold](LOW) | ? |
| market_router.py | Library/API | No class; functions=2 | ? |
| model_registry.py | Library/API | ModelEntry(no methods;LOW); ModelRegistry[__init__, _load, _save, register, try_promote, get_active, get_best, list_all, print_leaderboard](HIGH); GaussianModelRegistry[__init__, _load, _save, register_gaussian, promote_gaussian, get_active_gaussian, list_gaussian, print_gaussian_leaderboard](HIGH) | ? |
| phase5_calibration.py | CLI __main__, argparse | TradeDataset[from_backtest_results, from_trade_records, _build, export, load_cached](MED); CalibrationResult[print_summary](LOW) | ? |
| portfolio_validation.py | CLI __main__, argparse | InstrumentConfig(no methods;LOW); PortfolioAnalytics[__init__, aggregate, instrument_breakdown, score_distribution, gaussian_correlation, score_outcome_rr_correlation, rejection_breakdown, session_breakdown, universality_verdict](LOW) | ? |
| prepare_data.py | CLI __main__, argparse | No class; functions=9 | ? |
| production_config.py | CLI __main__ | No class; functions=8 | ? |
| promotion_manager.py | CLI __main__, argparse | PromotionManager[promote_from_report, promote_from_tuner_checkpoint, promote_direct, list_versions, load_version, _execute_promotion, _compute_config_hash, _build_registry_entry, _write_to_registry, _fail, _log_event](HIGH) | ? |
| python_runner.py | CLI __main__ | No class; functions=5 | ? |
| regen_bit.py | CLI __main__, argparse | No class; functions=4 | ? |
| rr_dataset_builder.py | Library/API | No class; functions=9 | ? |
| rr_fusion.py | Library/API | RRFusionLayer[__init__, _try_load, _get, _extract_gaussian_fields, _extract_canonical_features, score, score_dict, is_loaded, load_error, reload](MED) | ? |
| rr_pattern_miner.py | Library/API | RRPatternTrainer[__init__, train, save, loocv_report](MED); NanoInferenceEngine[__init__, load, predict](MED) | ? |
| run_debug.py | Library/API | No class/function inventory | ? |
| run_historical_data.py | Library/API | No class/function inventory | ? |
| run_parity.py | Library/API | No class/function inventory | ? |
| runtime\backtest_bitnet.py | CLI __main__, argparse | No class; functions=3 | ? |
| runtime\backtest_v2.py | CLI __main__, argparse | BacktestConfig(no methods;LOW); TradeRecord[is_winner, duration_candles](LOW); RejectionRecord(no methods;LOW); CapitalCurve[__init__, current_risk_amount, position_size, apply_trade, drawdown_pct, max_drawdown_pct, total_return_pct, to_dict](HIGH); SlippageModel[__init__, entry_slip, exit_slip, compute_fill_prices](LOW); GapDetector[__init__, check](LOW); DistributionAnalyser[analyse, _rolling_win_rate, _clustering_score, _score_outcome_correlation](LOW); CandleLoader[__init__, _detect_column, _parse_timestamp, stream, count](LOW); HTFBuilder[__init__, current_htf_id, completed_window, push, seed_candles](LOW); TradeJournal[__init__, on_trade_opened, on_trade_closed, on_rejected, to_csv_rows](LOW); BacktestMetrics[win_rate, avg_rr_net, approval_rate, to_dict](LOW); MetricsEngine[__init__, compute, _max_dd_rr, _streaks](LOW); ReportWriter[__init__, write_all, _write_summary, _write_trades, _write_events, _write_report](HIGH); BacktestRunner[__init__, run, _session, _print_summary](HIGH); MultiInstrumentRunner[__init__, run_all, _infer, _write_aggregate](HIGH) | ? |
| runtime\live_engine_hook.py | Library/API | HookedLiveEngine[process](HIGH) | ? |
| schema_audit.py | CLI __main__, argparse | No class; functions=3 | ? |
| test_auto_tuner_multi.py | Library/API | _StubCRTConfig(no methods;LOW); _StubConfigBuilder[build](LOW); _StubBacktestConfig(no methods;LOW); _StubMetrics(no methods;LOW); _StubCandleLoader[__init__, count, stream](LOW); _StubBacktestRunner[__init__, run](HIGH) | ?? |
| test_backtest_payload_integrity.py | Library/API | No class; functions=4 | ?? |
| test_bitnet_inference.py | CLI __main__ | No class; functions=24 | ?? |
| test_engine_runner_dual_gate.py | Library/API | No class; functions=5 | ?? |
| test_feature_pipeline.py | CLI __main__ | No class; functions=32 | ?? |
| test_fusion_and_validator_regression.py | Library/API | No class; functions=2 | ?? |
| test_gaussian_impl_switch.py | Library/API | No class; functions=17 | ?? |
| test_schema_contracts.py | Library/API | No class; functions=13 | ?? |
| test_trap_validator.py | Library/API | No class/function inventory | ?? |
| test_zone_gate.py | Library/API | No class; functions=10 | ?? |
| trade_logger.py | Library/API | TradeLogger[__init__, log_entry, log_exit, log_rejection, _write](MED) | ? |
| trade_replay_validator.py | Library/API | No class; functions=3 | ? |
| train_pipeline.py | Library/API | No class; functions=4 | ? |
| training\evaluator.py | Library/API | GaussianEvalResult[print](LOW); EvalResult[print](LOW) | ? |
| training\trainer.py | Library/API | StandardScaler[__init__, fit, transform, transform_one, to_dict, from_dict](LOW); GaussianNBModel[__init__, fit, predict_proba, predict_expected_rr, to_dict, from_dict](LOW) | ? |
| ultron_risk_gate.py | CLI __main__ | UltronRiskGate[__init__, evaluate, _reject](LOW) | ? |
| unified_data_builder.py | CLI __main__, argparse | No class; functions=6 | ? |
| utils\logging_config.py | CLI __main__ | FlowLogFilter[__init__, filter](LOW); ColoredFlowFormatter[__init__, format](LOW) | ? |
| zone_registry_builder.py | CLI __main__ | No class; functions=9 | ? |
| zone_schema_migrator.py | CLI __main__, argparse | ZoneSchemaError(no methods;LOW) | ? |

## Class Method Intelligence Addendum (Non-trivial Core Classes)

Status System: ✅ 🟡 🔴 🧪

| Class | Method | Responsibility | Risk | Idempotency | State Impact | Validation/Invariants |
|---|---|---|---|---|---|---|
| EngineRunner | run | Full gate->engine->fusion->decision orchestration | HIGH | ? | collector write | expected engine completeness + gate invariants |
| FeaturePipeline | run | Build canonical features + vectors | MED | ? | mutates internal dataframe | drops NaN rows, canonical columns required |
| BacktestRunner | run | Candle replay, trade journal, report writes | HIGH | ? for fixed seed/data | writes reports/logs | warmup/init/gap reset/forced close |
| LiveEngine | process | Live decision and alert dispatch | HIGH | ? | network + audit writes + in-memory cooldown | kill switch, schema checks, decision ladder |
| ConfigValidator | validate | Multi-instrument config validation | HIGH | ? | writes validation reports | hard reject rules enforced |
| PromotionManager | _write_to_registry | Promotion write boundary | HIGH | ? | writes production config + promotion log | versioned file + hash embed |

## Method Usage Graph (Core)

Status System: ✅ 🟡 🔴 🧪
- `EngineRunner.run` <- `runtime/backtest_bitnet.run_backtest`, tests; Layer=Service; Type=Transactional.
- `FeatureStore.process` <- `runtime/backtest_bitnet.run_backtest`; Layer=Ingestion; Type=Stateful.
- `FusionEngine.compute` <- `EngineRunner.run`; Layer=Cognition; Type=Pure.
- `DecisionEngine.evaluate` <- `EngineRunner.run`; Layer=Service; Type=Write-authoritative (logical).
- `PromotionManager.promote_from_tuner_checkpoint` <- CLI/manual ops; Layer=Governance; Type=Write-authoritative.

