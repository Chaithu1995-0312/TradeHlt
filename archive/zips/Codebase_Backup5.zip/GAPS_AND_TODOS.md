﻿# GAPS_AND_TODOS

Status System: ✅ 🟡 🔴 🧪

## Status Legend

Status System: ✅ 🟡 🔴 🧪
- ? Closed
- ?? Open with workaround
- ?? Open critical
- ?? Experimental/implied

## Critical Gaps

Status System: ✅ 🟡 🔴 🧪

1. ?? `crt_engine_v2` audit gap
- Referenced by runtime and config builders, but full source behavior was not part of this context pass.
- Impact: end-to-end correctness and state machine guarantees cannot be fully verified.
- TODO:
  - Add method-level audit for `CRTEngine`, `CRTConfig`, state machine transitions.
  - Add invariants table mapped to backtest and live callsites.

2. ?? Feature dimension contract drift
- `features/feature_schema.py` uses 35 canonical features, while multiple module comments/docs still assert 24 or 32.
- Impact: high risk of model/vector mismatch and stale assumptions.
- TODO:
  - Normalize all docs/comments/constants to one dimension contract.
  - Add CI check to fail on inconsistent hardcoded dimensions.

3. ?? Decision label inconsistency
- Lowercase `execute/reject` in decision engine vs uppercase/status variants in legacy paths.
- Impact: downstream reporting and governance logic can misclassify outcomes.
- TODO:
  - Introduce canonical enum constants and adapter translators.
  - Add compatibility conversion at ingestion boundaries.

4. ?? Runtime import path inconsistency
- `runtime/backtest_v2.py` imports `archive.crt_engine_v2`; others import `crt_engine_v2`.
- Impact: code path divergence by environment.
- TODO:
  - Consolidate to one import path and deprecate shadow copy.

## Governance Gaps

Status System: ✅ 🟡 🔴 🧪

5. ?? `governance/shadow_promotion_gate.py` is scaffold-level
- Contains embedded comments that expected config plumbing is incomplete.
- TODO:
  - Replace subprocess call assumptions with explicit config handoff API.
  - Add result schema validation for shadow run output.

6. ?? `governance/meta_governor_executor.py` validation is minimal
- Only checks presence of `fusion_min_score` key from extracted JSON.
- TODO:
  - Add full schema validation and allowed-range enforcement.
  - Add deterministic reject reasons per invalid field.

## Observability Gaps

Status System: ✅ 🟡 🔴 🧪

7. ?? Collector schema variability
- `Collector.log` derives `trade_id` from nested `features.id` which may be absent.
- TODO:
  - Introduce strict collector record schema version and required IDs.

8. ?? Mixed logging channels
- Some modules use print/debug and others structured JSON logs.
- TODO:
  - Standardize to structured logger wrappers for decision-critical paths.

## Security/Operations Gaps

Status System: ✅ 🟡 🔴 🧪

9. ?? Hardcoded Telegram defaults in `LiveEngineConfig.from_env`
- Default token/chat values embedded in source.
- TODO:
  - Remove hardcoded secrets, require explicit env configuration.
  - Add startup hard-fail in production mode when missing.

10. ?? Subprocess execution hardening
- `MetaGovernorExecutor` invokes external binary without timeout/exit policy checks.
- TODO:
  - Add timeout, return-code guard, stderr capture classification.

## Testing Gaps

Status System: ✅ 🟡 🔴 🧪

11. ?? Integration coverage for governance path
- Existing tests focus primarily engine/schema behavior.
- TODO:
  - Add tests for promotion hash verification failures and rollback behavior.
  - Add tests for conflicting feature-dimension assumptions.

12. ?? Missing test for runtime import divergence
- No test that ensures runtime and non-runtime paths use same `CRTConfig` semantics.
- TODO:
  - Introduce import consistency contract test.

## MISSING_FROM_CONTEXT Registry

Status System: ✅ 🟡 🔴 🧪
- ?? Full behavior of archived and legacy scripts under `archive/` and `Archieve/`.
- ?? Full behavior of some top-level scripts not deep-read in this pass (inventory is present in `FILE_INDEX.md`).

