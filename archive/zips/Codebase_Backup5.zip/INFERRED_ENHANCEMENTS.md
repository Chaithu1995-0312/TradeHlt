﻿# INFERRED_ENHANCEMENTS

Status System: ✅ 🟡 🔴 🧪

## Status Legend

Status System: ✅ 🟡 🔴 🧪
- ? Confirmed feasible from current implementation
- ?? Inferred enhancement requiring moderate refactor
- ?? High-risk enhancement blocked by missing context
- ?? Experimental proposal

## Inferred (Not Yet Implemented) Enhancements

Status System: ✅ 🟡 🔴 🧪

### 1. Schema Contract Unification Engine

Status System: ✅ 🟡 🔴 🧪
- Status: ?? Inferred
- Rationale: current 24/32/35 dimension drift is the highest systemic risk.
- Proposal:
  - Introduce `SchemaContract` object with fields `{name, dim, order, checksum, version}`.
  - Replace scattered hardcoded dimension comments/constants with generated references.
  - Add CI hook scanning for stale dimension literals in core/runtime/engines.

### 2. Decision Vocabulary Normalization Layer

Status System: ✅ 🟡 🔴 🧪
- Status: ? Feasible
- Proposal:
  - Add canonical enum: `Decision = {EXECUTE, REJECT, WARN, WATCH, BLOCK}` with explicit mapping by context.
  - Provide serializer adapters for legacy outputs.
  - Enforce in collector/report writer schemas.

### 3. EngineRunner Policy Pack

Status System: ✅ 🟡 🔴 🧪
- Status: ?? Inferred
- Proposal:
  - Externalize gate thresholds (`fusion_min_score`, dual-engine thresholds, p_win floor) into versioned policy profiles.
  - Bind policy checksum into validation and promotion metadata.
  - Enable deterministic replay by policy ID.

### 4. Governance Hardening Pipeline

Status System: ✅ 🟡 🔴 🧪
- Status: ?? Inferred
- Proposal:
  - Add `PromotionPolicyValidator` enforcing non-regression of score, drawdown, and std-dev before write.
  - Require signed promotion metadata and append-only audit trail.
  - Add rollback command that references archived prior versions by version tag.

### 5. Live Alert Security Hardening

Status System: ✅ 🟡 🔴 🧪
- Status: ? Feasible
- Proposal:
  - Remove hardcoded defaults for bot token/chat ID.
  - Add startup mode flags: `STRICT_PROD=1` requires explicit secrets and deny-start otherwise.
  - Mask tokens from logs and event payloads.

### 6. Zone Registry Evolution Support

Status System: ✅ 🟡 🔴 🧪
- Status: ? Feasible
- Proposal:
  - Add registry schema version negotiation in `run_zone_gate_engine`.
  - Auto-migrate legacy schema via `zone_schema_migrator` with explicit telemetry event.
  - Add read-only dry-run mode for migration preview.

### 7. Feature Drift Sentinel Service

Status System: ✅ 🟡 🔴 🧪
- Status: ?? Experimental
- Proposal:
  - Promote `FeatureMonitor` to always-on background monitor in backtest/live loops.
  - Emit drift severity events used by `DecisionEngine` as confidence dampener.
  - Block or reduce risk when drift exceeds threshold.

### 8. Unified Replay/Live Runtime API

Status System: ✅ 🟡 🔴 🧪
- Status: ?? Inferred
- Proposal:
  - Create shared `ExecutionContext` object consumed by both `BacktestRunner` and `LiveEngine`.
  - Normalize lifecycle events (`TRADE_OPENED`, `TRADE_CLOSED`, `RISK_REJECTED`) and payload schemas.
  - Ensure report writer and live alert consume same canonical event model.

## Inferred Method Additions

Status System: ✅ 🟡 🔴 🧪

| Class | Missing/Implied Method | Purpose | Status |
|---|---|---|---|
| `FeaturePipeline` | `schema_contract()` | Return runtime schema object with checksum/version | ?? |
| `EngineRunner` | `validate_engine_contract()` | Assert expected engine outputs and vocab normalization | ?? |
| `PromotionManager` | `rollback(version)` | Safe rollback to archived config | ?? |
| `LiveEngine` | `healthcheck()` | Verify alert/network/model readiness at startup | ? |
| `MetaGovernorExecutor` | `validate_candidate_patch()` | Full range/type/schema checks before staging | ?? |

## Cross-Class Boundary Impact (Ripple)

Status System: ✅ 🟡 🔴 🧪
- Schema unification impacts: `features/*`, `engines/zone_gate_engine.py`, `training/trainer.py`, `runtime/*`.
- Decision vocabulary normalization impacts: `core/decision_engine.py`, `core/engine_runner.py`, `collector.py`, reporting modules.
- Governance hardening impacts: `config_validator.py`, `promotion_manager.py`, `production_config.py`.

