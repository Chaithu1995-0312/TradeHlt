import json
import shutil
import subprocess
import pandas as pd
from pathlib import Path

class ShadowPromotionGate:
    def __init__(self, active_config_path="production_configs/v1_multi_2026_03.json"):
        self.active_config_path = Path(active_config_path)
        self.candidate_path = Path("production_configs/candidate.json")
        self.backtest_script = "runtime/backtest_v2.py"
        self.data_csv = "data/AUDUSD_M15.csv"  # adjust as needed

    def stage_candidate(self, candidate_patch: dict):
        with open(self.active_config_path, 'r') as f:
            base_config = json.load(f)

        # Ensure decision_engine section exists
        if "decision_engine" not in base_config:
            base_config["decision_engine"] = {}
        base_config["fusion_min_score"] = candidate_patch["fusion_min_score"]
        base_config["decision_engine"]["weak_component_threshold"] = candidate_patch["decision_engine"]["weak_component_threshold"]

        with open(self.candidate_path, 'w') as f:
            json.dump(base_config, f, indent=4)
        print(f"Candidate config staged at {self.candidate_path}")

    def execute_shadow_test(self) -> float:
        # The CRT backtest expects --csv, --instrument, --output
        cmd = [
        "python", "runtime/backtest_bitnet.py",   # use BitNet backtest
        "--config", str(self.candidate_path),
        "--data", self.data_csv,
        "--output", "results/shadow_trades.csv"
        ]
        subprocess.run(cmd, check=True)
        shadow_trades = pd.read_csv("results/shadow_trades.csv")
        # We need to inject the candidate config into the BacktestRunner.
        # The CRT backtest currently doesn't read a config file.
        # For now, assume you have modified it to accept --config.
        # Simpler: just run the backtest with the default config and rely on the candidate config being written to a file that the runner reads.
        # But the CRT backtest uses BacktestConfig dataclass, not a JSON config.
        # So you may need to modify the CRT backtest to load thresholds from a JSON file.
        # For demonstration, we'll assume it reads from production_configs/active.json.
        # We'll run the backtest and then read the shadow trades CSV.
        total_pnl = shadow_trades['pnl_rr_net'].sum()
        return total_pnl

    def promote_if_superior(self, baseline_pnl: float, shadow_pnl: float):
        print(f"Baseline PnL: {baseline_pnl:.2f} | Shadow PnL: {shadow_pnl:.2f}")
        if shadow_pnl > baseline_pnl:
            print("Candidate outperformed baseline. Promoting to Active Config.")
            shutil.copy(self.candidate_path, self.active_config_path)
        else:
            print("Candidate failed to outperform. Discarding.")
            self.candidate_path.unlink(missing_ok=True)