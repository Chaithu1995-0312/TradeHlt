﻿
# Canonical System Overview

## Purpose
- Maintain a deterministic, file-based trading research/runtime stack centered on canonical feature generation, multi-engine scoring, and auditable decision logging.
- Support two active execution surfaces:
  - Historical row-by-row backtest path (`backtest_v2.py`) using `FeaturePipeline` + `BitNetModel` + `EngineRunner`.
  - Live alert path (`live_engine.py`) with Gaussian/ML advisory flow, BitNet zone gate, and Telegram/log outputs.
- Preserve model/config promotion and registry workflows (`production_config.py`, `promotion_manager.py`, `model_registry.py`) as the controlled deployment mechanism.

## Non-goals
- No broker/order execution is implemented; live module explicitly positions itself as alert-only.
- No single unified architecture currently exists; repository contains parallel scoring paths (`engine_runner` mesh, `crt_engine_v2`, and legacy wrappers).
- Markdown specs under `FuturePhaseConfig/spec` are not treated as implemented behavior unless corroborated by executable code.

## High-level architecture
1. Feature and schema contract layer
- `feature_schema.py` defines immutable canonical 24-feature order and schema hash.
- `schema_validator.py` and `feature_pipeline.py` enforce/emit canonical vectors.

2. Multi-engine orchestration layer
- `engine_runner.py` runs adapter gate -> 4 engines (`crt`, `gaussian`, `bitnet`, `rr`) -> fusion -> dual-engine regime governor -> collector log.
- `fusion_engine.py` supports both compact `compute(engine_results)` aggregation and richer `evaluate(features, signal)` scoring path.

3. Model/training and registry layer
- Gaussian stack: `dataset_builder.py`, `trainer.py`, `evaluator.py`, `train_pipeline.py`, `model_registry.py`.
- RR stack: `rr_dataset_builder.py`, `rr_pattern_miner.py`, `rr_fusion.py`.
- BitNet search stack: `bitnet/search_engine.py` + validators/forward tester.

4. Runtime interfaces
- Historical: `backtest_v2.py` (vectorized pipeline + BitNet model inference + `EngineRunner`).
- Live: `live_engine.py` (decision + gate + cooldown/dedup + Telegram/log).

5. Deployment/config governance
- `config_builder.py` + `market_router.py` create `CRTConfig`.
- `production_config.py` loads promoted params from `production_configs/<version>.json`.
- `config_validator.py` intended to validate promoted params (currently drifted/broken path noted below).


# Implementation Reality Map

## Implemented Components

### ✅ Canonical feature pipeline and schema contracts
- Evidence:
  - `feature_schema.py` defines fixed `CANONICAL_FEATURES` (24) and deterministic hash.
  - `feature_pipeline.py` builds and validates canonical feature dict/vector.
  - `schema_validator.py` provides strict dict/vector validation.
- Confidence: High.

### ✅ Engine orchestration and decision flow (compute path)
- Evidence:
  - `engine_runner.py` enforces adapter gate, executes all engines, checks completeness, computes fused score, applies Ultron regime governor, logs via `Collector`.
  - `decision_engine.py` provides central evaluate/reject contract (used by some paths; not the sole authority in `EngineRunner`, see conflict).
- Confidence: High.

### ✅ Historical backtest execution loop (current file behavior)
- Evidence:
  - `backtest_v2.py` reads CSV -> runs `FeaturePipeline.run()` -> validates schema -> `BitNetModel.predict()` -> routes each row through `EngineRunner.run()`.
- Confidence: High.

### ✅ BitNet search/validation subsystem
- Evidence:
  - `bitnet/search_engine.py`, `bitnet/zone_validator.py`, `bitnet/stability_checker.py`, `bitnet/forward_tester.py` contain complete search, candidate scoring, validation, and persistence primitives.
- Confidence: High.

### ✅ Production config loader and promotion scaffolding
- Evidence:
  - `production_config.py` loads versioned registry entries and optionally verifies hash.
  - `promotion_manager.py` provides promotion and hash utilities.
  - `config_builder.py` enforces immutable config construction.
- Confidence: High.

## Partially Implemented Components

### 🟡 RR/Gaussian training stack blocked by missing module dependency
- Evidence:
  - `dataset_builder.py`, `rr_dataset_builder.py`, `rr_fusion.py`, `bitnet_zone_builder.py`, `feature_monitor.py` import `feature_adapter`.
  - `feature_adapter.py` is absent from active tree (`D:\Tradelatest`).
- Impact:
  - Import-time failure risk for dataset build/train/fusion paths that touch these modules.
- Confidence: High.

### 🟡 BitNet runtime gating is implemented but artifact/schema alignment is inconsistent
- Evidence:
  - `live_engine.BitNetZoneGate` expects modern zone schema (`mu/sigma/weights/threshold`) and fail-opens if invalid.
  - `models/zone_registry.json` currently contains legacy `center/radius/min_score/weight`.
  - `zone_gate.py` supports both symbol-price and gaussian schema, but global registry content remains legacy.
- Confidence: High.

### 🟡 Gaussian registry state drift and mixed schema entries
- Evidence:
  - `models/gaussian_registry.json` marks `v2` active but `models/v2.json` is missing.
  - Registry contains mixed entry formats (`v1`/`v2` minimal vs `import_fix_v1` full metadata).
- Confidence: High.

### 🟡 RR dataset artifact is structurally valid but labels are degenerate
- Evidence:
  - `models/rr_dataset.json` has schema metadata and populated X but `y_rr` and `y_win` are effectively all zeros.
  - `rr_dataset_builder.extract_target()` reads `rr_achieved`/`outcome`; many system records use different keys (for example `pnl_rr_net`, `win`), creating likely extraction mismatch.
- Confidence: Medium-High.

### 🟡 Config validator convenience path is stale
- Evidence:
  - `config_validator.validate_prod_params()` imports `PROD_PARAMS` from `production_config.py`.
  - `production_config.py` is registry-driven and does not define `PROD_PARAMS`.
- Confidence: High.

### 🟡 `llm_score_batch` is declared but functionally unfinished
- Evidence:
  - `llama_gate.py` defines payload in `llm_score_batch(...)` and exits without HTTP call/parse/return list.
- Confidence: High.

### 🟡 Live secret handling is operational but unsafe-by-default
- Evidence:
  - `LiveEngineConfig.from_env()` includes hardcoded default Telegram token/chat values.
- Confidence: High.

### 🟡 `EngineRunner`/`DecisionEngine` authority split is inconsistent
- Evidence:
  - `engine_runner.py` returns direct approval/rejection strings (`Approved` / `REJECT`) based on fusion+gate logic.
  - `decision_engine.py` defines a separate central evaluate contract (`execute` / `reject`) but is not the final branch in `EngineRunner.run()`.
- Status: Ambiguous (reason)
  - Could be intentional transitional layering or unresolved architectural split.
- Confidence: Medium.
## Not Implemented / Planned

### 🔴 `FuturePhaseConfig/spec/bitnet_spec.md` target architecture is not implemented end-to-end
- Spec describes binary MLP + STE training, online retraining loop, drift management, and AI-CIO state machine as integrated runtime policy.
- Current codebase has partial analogs (BitNet inference/search modules) but no complete implementation of the full spec contract as a single executable pipeline.
- Confidence: High.

### 🔴 `FuturePhaseConfig/spec/bitpacking_spec.md` C++ bit-packing runtime is not present
- Python code includes binary/ternary handling in `bitnet_inference.py` and mentions portability, but no C++ implementation exists in workspace.
- Confidence: High.

## Deferred / Frozen

### 🧪 Experimental / Draft
- `trade_replay_validator.py`: explicitly marked connector upgrade with placeholder replay path (`TEMP: Use backtest truth directly`).
- `bitnet_zone_builder.py`: KMeans legacy zone generator outputs schema incompatible with `LiveEngine` modern gate expectation.
- `crt_engine_v2.py`: rich CRT state-machine engine exists but is not the primary executor in current `backtest_v2.py` flow.

### Frozen / Doctrine-like contracts (implemented in comments and guardrails)
- Config creation doctrine in `config_builder.py` (`ConfigBuilder` as mandatory factory).
- Canonical schema doctrine in `feature_schema.py`.
- Fail-open philosophy in gate/runtime pieces (RR/BitNet/LLM fallback behavior).


# File-Level Technical Index

Legend for `Code Reference Type`:
- `Concrete Code`
- `Pseudo-Code`
- `Interface / Contract`
- `Claude-Suggested`

## `README.md`
- Purpose: Repository title only.
- Status: 🔴 Not Implemented (documentation content)
- Code Reference Type: Interface / Contract (minimal, non-technical)
- Key classes & functions: None.
- Known invariants: None.
- Missing pieces: No architecture/usage content.

## `FuturePhaseConfig/spec/bitnet_spec.md`
- Purpose: Target-state BitNet system specification.
- Status: 🔴 Not Implemented (as an integrated system)
- Code Reference Type: Pseudo-Code + Interface / Contract
- Key classes & functions: N/A (spec text only).
- Known invariants: Defines intended risk/online-learning/drift behavior.
- Missing pieces: No complete code realization in active tree.

## `FuturePhaseConfig/spec/bitpacking_spec.md`
- Purpose: Target bit-packing inference method spec.
- Status: 🔴 Not Implemented (C++ runtime absent)
- Code Reference Type: Interface / Contract
- Key classes & functions: N/A.
- Known invariants: XNOR + popcount dot product contract.
- Missing pieces: No C++/native implementation.

## `CANONICAL_SYSTEM_OVERVIEW.md` (prior version)
- Purpose: Previous synthesized architecture map.
- Status: 🧪 Experimental / Draft (secondary claim source)
- Code Reference Type: Claude-Suggested + Interface / Contract
- Key classes & functions: N/A.
- Known invariants: Declared intended architecture.
- Missing pieces: Contains stale claims not matching current `backtest_v2.py` and dependency graph.

## `feature_schema.py`
- Purpose: Canonical 24-feature schema source of truth.
- Status: ✅ Implemented
- Code Reference Type: Interface / Contract + Concrete Code
- Key classes & functions: `CANONICAL_FEATURES`, `FEATURE_INDEX_MAP`, `SCHEMA_HASH`, `validate_features(...)`, `encode_session_ordinal(...)`.
- Known invariants: Tuple order is immutable; duplicates forbidden at import.
- Missing pieces: Backward compatibility remains uneven across modules expecting old names.

## `schema_validator.py`
- Purpose: Runtime validation helpers for feature dicts/vectors.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `validate_features(...)`, `validate_feature_values(...)`, `validate_vector(...)`.
- Known invariants: Hard-fail on schema mismatch.
- Missing pieces: None obvious.

## `feature_pipeline.py`
- Purpose: Batch OHLCV -> canonical feature dataframe/vector pipeline.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `FeaturePipeline`, `build_features(...)`, `build_feature_vector(...)`.
- Known invariants: Deterministic order, warmup NaN drop, strict validation.
- Missing pieces: Live-only trailing swing logic is not implemented (historical center-window behavior documented).

## `backtest_v2.py`
- Purpose: Row-by-row backtest loop integrating pipeline, BitNet model, and engine orchestration.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `run_backtest(...)`, `_derive_symbol_from_data_path(...)`.
- Known invariants: Per-row schema validation before inference; collector logging on row errors.
- Missing pieces: Relies on downstream engines with mixed maturity; no direct invocation of `crt_engine_v2` state machine.

## `engine_runner.py`
- Purpose: Central orchestration for adapter + engines + fusion + regime governor.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `EngineRunner.run(...)`, `detect_regime(...)`, `breakout_engine(...)`, `trap_engine(...)`, `ultron_governor(...)`.
- Known invariants: Reject if adapter fails or engine set incomplete.
- Missing pieces: Decision contract not unified with `decision_engine.DecisionEngine.evaluate(...)` output semantics.

## `adapter_engine.py`
- Purpose: Input pre-gating (`TrapValidatorEngine`).
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `TrapValidatorEngine.compute(...)`.
- Known invariants: Requires canonical gating fields; ATR/session checks.
- Missing pieces: Mutates input sentinel (`_data_integrity`) locally, reducing strict trust guarantees.

## `crt_engine.py`
- Purpose: Wrapper around `scoring_engine.compute_scores(...)`.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `compute(...)`.
- Known invariants: Returns `score` with fail-safe catch.
- Missing pieces: Uses legacy key aliases in log payload (`displacement` vs canonical `disp_strength`) in some paths.

## `gaussian_engine.py`
- Purpose: Lightweight Gaussian score calculator from canonical inputs.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `GaussianEngine.compute(...)`.
- Known invariants: Fail-fast on missing canonical features.
- Missing pieces: Simplified scoring not directly tied to promoted Gaussian bundle artifacts.

## `rr_engine.py`
- Purpose: Heuristic RR score from price structure.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `RREngine.compute(...)`.
- Known invariants: Uses high/low/close structure; returns normalized score.
- Missing pieces: Coexists with RR ML stack; boundary between heuristic RR and ML RR not fully consolidated.
## `zone_gate.py`
- Purpose: Zone registry evaluator supporting multiple schema styles.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `ZoneGate.evaluate(...)`, `_detect_schema(...)`.
- Known invariants: Supports symbol-price schema and gaussian schema with feature index mapping.
- Missing pieces: Global registry defaults still legacy; effectiveness depends on artifact alignment.

## `zone_gate_engine.py`
- Purpose: Engine wrapper around `ZoneGate`.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `compute(...)`, `ZoneGateEngine.compute(...)`.
- Known invariants: Expects canonical feature keys.
- Missing pieces: Runtime behavior tied to registry quality.

## `fusion_engine.py`
- Purpose: Multi-layer fusion utilities and aggregate compute.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `FusionEngine.compute(...)`, `FusionEngine.evaluate(...)`, `FusionConfig`, `FusionResult`.
- Known invariants: `compute(...)` requires all 4 engine outputs.
- Missing pieces: `evaluate(...)` richer path is not the path used by `EngineRunner.run()`; architectural overlap unresolved.

## `decision_engine.py`
- Purpose: Decision contract for execute/reject.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `DecisionEngine.evaluate(...)`, `DecisionResult`.
- Known invariants: Rejects invalid bitnet/low score/low p_win/low rr/weak setup.
- Missing pieces: Not wired as final authority in all active paths.

## `collector.py`
- Purpose: Structured audit logging for outcomes/engine outputs.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `collect(...)`, `Collector.log(...)`.
- Known invariants: Appends JSONL logs.
- Missing pieces: Decision label normalization mismatch (`Collector.log` checks `ACCEPT`, while `EngineRunner` emits `Approved`).

## `live_engine.py`
- Purpose: Live decision and alerting pipeline.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `BitNetZoneGate`, `LiveEngineConfig.from_env(...)`, `LiveEngine.process(...)`, `send_telegram_alert(...)`, `decide_trade(...)`.
- Known invariants: Alert-only, no order placement, cooldown/dedup/log path.
- Missing pieces: Hardcoded default Telegram credentials; zone gate schema dependency causes frequent fail-open.

## `bitnet/search_engine.py`
- Purpose: Discover/score/stabilize Gaussian zone candidates.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `ZoneCandidate`, `ZoneResult`, `compute_gaussian_score(...)`, `BitNetSearchEngine` methods.
- Known invariants: Search over depth/body/disp; validation/stability guards.
- Missing pieces: Requires clean RR dataset labels and runtime zone schema adoption.

## `bitnet/zone_validator.py`, `bitnet/stability_checker.py`, `bitnet/forward_tester.py`
- Purpose: Zone quality/stability/forward checks.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: module validators/testers.
- Known invariants: Enforce trade-count/temporal consistency constraints.
- Missing pieces: Depend on upstream dataset fidelity.

## `bitnet_inference.py`
- Purpose: BitNet model loader/inference (legacy + export schema support).
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract + Claude-Suggested (inline self-review notes)
- Key classes & functions: `BitNetModel.predict(...)`, `_forward_export(...)`, `bitnet_score(...)`.
- Known invariants: Input vector shape checks; fail-fast on mismatches.
- Missing pieces: `bitnet_score(...)` still legacy 6-feature path; full convergence to canonical vector path incomplete.

## `bitnet_zone_builder.py`
- Purpose: Legacy KMeans zone builder.
- Status: 🧪 Experimental / Draft
- Code Reference Type: Concrete Code + Pseudo-Code (legacy mode)
- Key classes & functions: `cluster_zones(...)`, `build_zones(...)`, `run(...)`.
- Known invariants: Emits `center/radius/min_score/weight` schema.
- Missing pieces: Output schema incompatible with `LiveEngine` modern gate (`mu/sigma/weights/threshold`).

## `dataset_builder.py`
- Purpose: Build Gaussian/BitNet datasets and temporal splits.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `build_feature_vector(...)`, `build_gaussian_dataset(...)`, `build_splits(...)`, `extract_bitnet_features(...)`.
- Known invariants: Temporal split and quality guards.
- Missing pieces: Hard dependency on missing `feature_adapter.py` blocks clean imports/runtime.

## `rr_dataset_builder.py`
- Purpose: RR dataset extraction and persistence.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code + Interface / Contract + Claude-Suggested (PATCH annotations)
- Key classes & functions: `extract_features(...)`, `extract_target(...)`, `build_dataset(...)`.
- Known invariants: 11-feature RR schema contract.
- Missing pieces: Missing `feature_adapter.py`; target key mismatch likely causing degenerate labels.

## `rr_pattern_miner.py`
- Purpose: Train/load RR model and inference engine.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `RRPatternTrainer`, `NanoInferenceEngine`, `train_and_save(...)`.
- Known invariants: Provides model artifact expected by RR fusion.
- Missing pieces: Effectiveness dependent on valid RR dataset labels; active model artifact not present.

## `rr_fusion.py`
- Purpose: Advisory RR fusion layer with fail-open behavior.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `RRFusionLayer.score(...)`, `get_fusion_layer(...)`.
- Known invariants: Falls back to Gaussian score on load/inference errors.
- Missing pieces: Depends on missing `feature_adapter.py`; default model file absent (`models/rr_model.json`).

## `trainer.py`
- Purpose: Gaussian and generic model training utilities.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `StandardScaler`, `GaussianNBModel`, `train_gaussian(...)`, `save_gaussian_model(...)`, `cross_val_gaussian(...)`.
- Known invariants: Includes calibration/correlation utilities and serialization.
- Missing pieces: Training pipeline blocked upstream when dataset modules fail import.

## `evaluator.py`
- Purpose: Model evaluation and update gate.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `GaussianEvalResult`, `evaluate_gaussian(...)`, `should_update(...)`, `EvalResult`.
- Known invariants: Compares calibration/correlation style metrics.
- Missing pieces: None obvious in module itself.

## `train_pipeline.py`
- Purpose: End-to-end training/promotion orchestration.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `run(...)`, `run_gaussian_update(...)`, `run_bitnet_search(...)`.
- Known invariants: time-ordered validation -> train -> evaluate -> register/promote.
- Missing pieces: Operational path impacted by `feature_adapter.py` absence and artifact drift.
## `model_registry.py`
- Purpose: Generic and Gaussian model registries.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `ModelRegistry`, `GaussianModelRegistry`, `register_gaussian(...)`, `promote_gaussian(...)`.
- Known invariants: Promotion margin for generic registry; versioned Gaussian registry entries.
- Missing pieces: Existing artifact file contains mixed legacy/new entry schemas.

## `production_config.py`
- Purpose: Load promoted config versions and build `CRTConfig`.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `get_prod_config(...)`, `load_prod_config_from_registry(...)`, hash helpers.
- Known invariants: Hard-stop on missing registry file.
- Missing pieces: Current registry entry lacks `config_hash`; integrity downgrade to warning.

## `promotion_manager.py`
- Purpose: Promotion and audit management for production config entries.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `PromotionManager` methods (`promote_*`, hashing, listing).
- Known invariants: Versioned registry workflow.
- Missing pieces: Existing promoted record predates full hash policy.

## `config_builder.py`
- Purpose: Authoritative immutable `CRTConfig` factory.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `ConfigBuilder.build(...)`, `from_existing(...)`, `validate_divergence(...)`.
- Known invariants: Override keys validated against dataclass fields.
- Missing pieces: None obvious.

## `market_router.py`
- Purpose: Instrument -> market profile routing.
- Status: ✅ Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `classify_market(...)`, `get_crt_config(...)`.
- Known invariants: Unknown instruments default to FOREX.
- Missing pieces: Restricted-caller check is brittle string-stack based.

## `config_validator.py`
- Purpose: Multi-instrument production parameter validation.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code
- Key classes & functions: `ConfigValidator.validate(...)`, `validate_prod_params(...)`.
- Known invariants: Designed as pre-promotion quality gate.
- Missing pieces: `validate_prod_params()` imports nonexistent `PROD_PARAMS` symbol.

## `trade_replay_validator.py`
- Purpose: Replay validation connector and flattened dataset export.
- Status: 🧪 Experimental / Draft
- Code Reference Type: Pseudo-Code + Concrete scaffolding
- Key classes & functions: `replay_single_trade(...)`, `validate_all(...)`, `classify_outcome(...)`.
- Known invariants: Emits validator dataset CSV.
- Missing pieces: Real replay logic not implemented; currently forwards backtest truth.

## `llama_gate.py`
- Purpose: LLM scoring and insight generation wrappers.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code + Pseudo-Code
- Key classes & functions: `llm_score(...)`, `llm_score_batch(...)`, `llm_insight(...)`, `llm_score_safe(...)`.
- Known invariants: Fail-open to score `1.0` on errors.
- Missing pieces: `llm_score_batch(...)` has no return path.

## `crt_engine_v2.py`
- Purpose: Full CRT state machine/risk/execution model.
- Status: 🟡 Partially Implemented
- Code Reference Type: Concrete Code + Interface / Contract
- Key classes & functions: `CRTEngine`, `StateMachine`, `ExecutionEngine`, `CRTConfig`, `state_risk_score(...)`.
- Known invariants: Rich domain model with frozen config patterns.
- Missing pieces: Not the dominant execution path in current `backtest_v2.py` integration.


# Module Deep Dive

## 1) Data + Feature Contract Module
- Responsibilities:
  - Convert OHLCV into canonical features and enforce strict schema parity.
- Data flow:
  - Raw CSV/dataframe -> `FeaturePipeline.run()` -> feature dict/vector -> validators -> engine inputs.
- Entry points:
  - `FeaturePipeline.run(...)`, `build_features(...)`, `validate_features(...)`, `validate_vector(...)`.
- Exit points:
  - Canonical 24-feature vectors and enriched dataframe rows.
- Failure modes:
  - Missing required columns, NaN/inf features, schema mismatch.
- Observed vs intended behavior:
  - Observed: deterministic and strict.
  - Intended: single source of truth achieved here more than any other module.

## 2) Orchestration + Decision Module (`engine_runner` mesh)
- Responsibilities:
  - Gate incoming data, run component engines, combine scores, apply regime-specific governor, log result.
- Data flow:
  - feature dict + context -> adapter gate -> `{crt,gaussian,bitnet,rr}` -> fusion -> dual-engine governor -> collector.
- Entry points:
  - `EngineRunner.run(...)`.
- Exit points:
  - Decision payload (`Approved` or `REJECT`) and collector JSONL record.
- Failure modes:
  - Missing engine outputs; score under threshold; regime conflict/neutral block.
  - Decision label inconsistency (`Approved`/`REJECT`) vs other modules expecting lowercase or `ACCEPT`.
- Observed vs intended behavior:
  - Observed: this is the active authority in backtest path.
  - Intended (per comments elsewhere): `DecisionEngine` should be sole authority; integration is split.
## 3) Runtime Interfaces (Backtest + Live)
- Responsibilities:
  - Execute historical scoring loop and live alerting flow.
- Data flow:
  - Backtest: CSV -> features -> BitNet inference -> `EngineRunner`.
  - Live: trade_data -> Gaussian + optional neural + zone gate -> decision -> Telegram/log.
- Entry points:
  - `run_backtest(...)`, `LiveEngine.process(...)`, `alert_from_scores(...)`.
- Exit points:
  - Backtest result rows, collector logs, live alerts/log entries.
- Failure modes:
  - Invalid/missing zone registry triggers fail-open.
  - Hardcoded Telegram fallback credentials create security and operational risk.
- Observed vs intended behavior:
  - Observed: both flows run independently with overlapping concepts.
  - Intended: tighter parity and unified decision semantics are implied but not complete.

## 4) Training + Registry Module
- Responsibilities:
  - Build datasets, train models, evaluate/promotion gate, store active/versioned artifacts.
- Data flow:
  - logs/trades -> dataset builders -> trainer/evaluator -> registries -> runtime loader.
- Entry points:
  - `train_pipeline.run(...)`, `run_gaussian_update(...)`, `register_gaussian(...)`, `load_prod_config_from_registry(...)`.
- Exit points:
  - `models/*.json`, registry metadata files, promoted config files.
- Failure modes:
  - Missing `feature_adapter.py` breaks import chain.
  - Gaussian registry active entry points to missing artifact.
  - Production config hash missing in promoted record lowers integrity to warning.
- Observed vs intended behavior:
  - Observed: framework code is present, operational integrity is blocked by dependency/artifact drift.
  - Intended: fully self-improving loop with strict promotion hygiene.

## 5) BitNet Module
- Responsibilities:
  - Provide two distinct capabilities:
    - Neural inference path (`bitnet_inference.py`).
    - Zone discovery/filter path (`bitnet/search_engine.py` + gate wrappers).
- Data flow:
  - Search path: RR dataset -> candidate zones -> registry.
  - Runtime path: feature vector/dict -> gate score/allow decision.
- Entry points:
  - `BitNetModel.predict(...)`, `ZoneGate.evaluate(...)`, `BitNetSearchEngine` methods.
- Exit points:
  - Inference score and/or zone pass/fail, saved zone registries.
- Failure modes:
  - Legacy zone artifacts mismatch modern gate schema.
  - Dual schema support obscures which representation is canonical.
- Observed vs intended behavior:
  - Observed: code supports both old and new schemas.
  - Intended: likely migration toward modern gaussian zone schema; not completed.


# Claude Self-Review Extraction

Derived from inline comments, PATCH/FIX annotations, and module docstrings (no standalone Claude self-review markdown present).

## Assumptions
- Canonical feature order must never drift (`feature_schema.py` as authority).
- Time-ordered train/validation splits are mandatory.
- Runtime should fail-open rather than crash when optional ML layers are unavailable.
- LLM is a tie-breaker/advisory layer, not a primary deterministic gate.

## Invariants
- Config creation should pass through `ConfigBuilder.build(...)`.
- Feature validation should fail fast on mismatch.
- Engine completeness is required before fusion-based approval in `EngineRunner`.
- Zone-gate should not hard-stop trading path when registry is invalid.

## Edge cases
- Missing/zero volume in Forex.
- NaN vector elements and wrong vector dimensions.
- Missing model files or malformed registries.
- Session encoding differences (string vs numeric) across modules.

## Failure modes
- Missing `feature_adapter.py` causing import/runtime failures.
- Mixed artifact schema in Gaussian registry.
- Legacy zone schema causing pass-through gate behavior.
- Incomplete `llm_score_batch` path silently unusable.

## Tests mentioned in codebase
- `test_schema_contracts.py`
- `test_feature_pipeline.py`
- `test_bitnet_inference.py`
- `test_bitnet_routing_and_gate.py`
- `test_engine_runner_dual_gate.py`
- `test_fusion_and_validator_regression.py`
- `test_auto_tuner_multi.py`
- `test_backtest_payload_integrity.py`
- `test_trap_validator.py`

## Risks flagged
- Silent architecture drift between comments/docs and executable wiring.
- Training/inference skew due stale artifacts and mixed schemas.
- Security risk from embedded Telegram fallback credentials.

# Rules, Doctrines & Invariants

## Immutable rules
- `CANONICAL_FEATURES` order is fixed and treated as schema contract.
- Config creation doctrine: `ConfigBuilder` as central factory.
- Temporal ordering doctrine in training split logic.
- Fail-open doctrine in optional runtime ML layers (RR/BitNet/LLM) to preserve continuity.

## Frozen architecture (declared, partially enforced)
- Production config is registry-driven (`production_config.py`), not hardcoded parameter dicts.
- Multi-engine orchestration expects all four engine outputs before approval.
- Live module is alert-only (no broker execution).

## Hard constraints
- Backtest/live behavior depends heavily on artifact files in `models/` and `production_configs/`.
- Missing critical files (`feature_adapter.py`, active model artifacts) can block or degrade major flows.


# Gaps & Engineering TODOs

## What is blocking production
1. Restore or replace missing `feature_adapter.py` in active tree and reconcile all dependent imports (`dataset_builder.py`, `rr_dataset_builder.py`, `rr_fusion.py`, `bitnet_zone_builder.py`, `feature_monitor.py`).
2. Fix `config_validator.validate_prod_params()` stale import of nonexistent `PROD_PARAMS`.
3. Reconcile Gaussian active registry with actual model file presence (`v2` currently active but missing file).
4. Migrate/regen zone registries to a single runtime schema accepted by active gate path.
5. Remove hardcoded Telegram token/chat defaults from `LiveEngineConfig.from_env()`.
6. Resolve decision label/authority drift (`EngineRunner` vs `DecisionEngine`, and collector `ACCEPT` expectation).

## What can be safely deferred
1. Complete `llm_score_batch(...)` if batch LLM scoring is not in critical path.
2. Consolidate duplicate/parallel architecture comments and deprecated wrapper paths.
3. Remove or archive legacy KMeans zone tooling after migration.
4. Tighten strict hash enforcement for old production registry entries after migration plan is approved.

## What requires user confirmation
1. Canonical BitNet runtime direction:
- Keep dual schema support (`symbol_price` + gaussian) or enforce a single schema and migrate artifacts.
2. Canonical decision contract:
- Should `DecisionEngine.evaluate(...)` become the sole final authority across all execution paths?
3. RR target source of truth:
- Confirm whether targets should come from `pnl_rr_net`/`win` instead of `rr_achieved`/`outcome` in dataset extraction.
4. Security posture:
- Enforce mandatory env-only Telegram credentials vs optional fallback behavior.


# Inferred Enhancements (Clearly Labeled)

> 🔍 **Inferred Enhancement (Not Implemented)**  
> Rationale:  
> Introduce a startup preflight (`python preflight.py`) that validates critical dependencies/artifacts (`feature_adapter.py`, active model files, registry schema consistency) before any backtest/live/train entrypoint.  
> Assumptions:  
> Existing workflows can tolerate hard-stop preflight failures in non-exploratory environments.  
> Risk if wrong:  
> Overly strict preflight could block exploratory research runs unless mode flags are added.

> 🔍 **Inferred Enhancement (Not Implemented)**  
> Rationale:  
> Unify decision semantics into one typed contract (`execute|reject`, normalized reason codes) and make `EngineRunner` delegate final verdict to `DecisionEngine`.  
> Assumptions:  
> Current dual-engine governance logic can be represented as structured inputs to `DecisionEngine`.  
> Risk if wrong:  
> Refactor may alter historical backtest comparability if reason/threshold precedence changes.

> 🔍 **Inferred Enhancement (Not Implemented)**  
> Rationale:  
> Replace ad-hoc RR target extraction with an explicit target schema adapter that maps multiple known record formats (`pnl_rr_net`, `rr_achieved`, `win`, `outcome`) and records provenance.  
> Assumptions:  
> Trade logs across data sources can be normalized without losing semantic meaning.  
> Risk if wrong:  
> Incorrect mapping could silently poison retraining data and degrade model quality.

# Appendix

## Source documents used
- `D:\Tradelatest\README.md`
- `D:\Tradelatest\CANONICAL_SYSTEM_OVERVIEW.md` (prior draft; revalidated)
- `D:\Tradelatest\FuturePhaseConfig\spec\bitnet_spec.md`
- `D:\Tradelatest\FuturePhaseConfig\spec\bitpacking_spec.md`

## Implementation evidence files sampled (main tree only)
- Core runtime: `backtest_v2.py`, `engine_runner.py`, `adapter_engine.py`, `crt_engine.py`, `gaussian_engine.py`, `rr_engine.py`, `zone_gate_engine.py`, `fusion_engine.py`, `decision_engine.py`, `live_engine.py`, `collector.py`.
- Feature/contracts: `feature_schema.py`, `schema_validator.py`, `feature_pipeline.py`.
- Training/model: `dataset_builder.py`, `trainer.py`, `evaluator.py`, `train_pipeline.py`, `rr_dataset_builder.py`, `rr_pattern_miner.py`, `rr_fusion.py`, `model_registry.py`.
- BitNet: `bitnet_inference.py`, `zone_gate.py`, `bitnet_zone_builder.py`, `bitnet/search_engine.py`, `bitnet/zone_validator.py`, `bitnet/stability_checker.py`, `bitnet/forward_tester.py`.
- Config/promotion: `config_builder.py`, `market_router.py`, `config_validator.py`, `production_config.py`, `promotion_manager.py`.
- Artifacts: `models/gaussian_registry.json`, `models/rr_dataset.json`, `models/zone_registry.json`, `production_configs/v1_multi_2026_03.json`.

## Notes that could not be confidently classified
- Status: Ambiguous (reason)
  - Whether `crt_engine_v2.py` is intentionally retained as parallel future engine or should be considered legacy in favor of `engine_runner` path.
- Status: Ambiguous (reason)
  - Whether dual BitNet schema support is transitional migration scaffolding or long-term design.
- Status: Ambiguous (reason)
  - Whether missing `feature_adapter.py` is accidental omission or expected external dependency not committed to this workspace.

## Conflict ledger (docs vs code)
1. Conflict: prior canonical doc described a different `backtest_v2.py` architecture (legacy state-machine/rejection branch details) than current executable file.
- Resolution rule applied: current code wins.
- Confidence: High.

2. Conflict: `FuturePhaseConfig/spec/bitnet_spec.md` describes integrated STE/online-learning governance not present as one executable pipeline in current tree.
- Resolution rule applied: classify spec as target-state contract, not implemented reality.
- Confidence: High.

3. Conflict: production config comments describe strict hash verification, but live promoted artifact lacks `config_hash` and loader degrades to warning.
- Resolution rule applied: classify as partially implemented integrity contract.
- Confidence: High.
