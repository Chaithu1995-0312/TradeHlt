from core.fusion_engine import FusionEngine
from features.schema_validator import validate_vector


def test_fusion_accepts_engine_results_without_canonical_validation():
    fusion = FusionEngine(gaussian_adapter=None)
    engine_results = {
        "crt": {"score": 0.4, "non_canonical": "x"},
        "gaussian": {"score": 0.5},
        "zone_gate": {"zone": 0.7},
        "rr": {"score": 0.6},
    }
    out = fusion.compute(engine_results)
    assert "final_score" in out
    assert out.get("missing_engines") == []


def test_validate_vector_uses_len_not_shape_tuple():
    schema = tuple(f"f{i}" for i in range(24))
    validate_vector([0.0] * 24, schema)
    try:
        validate_vector([0.0] * 23, schema)
        raise AssertionError("Expected AssertionError for vector length mismatch")
    except AssertionError as exc:
        assert "length mismatch" in str(exc)
