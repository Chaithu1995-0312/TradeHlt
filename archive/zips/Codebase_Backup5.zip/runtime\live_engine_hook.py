"""
live_engine_hook.py
Subclass wrapper around LiveEngine — does NOT modify live_engine.py.
Calls EngineRunner → ExecutionPlannerV1_2 → UltronRiskGate after process() returns.
"""
from engines.live_engine import LiveEngine
from core.engine_runner import EngineRunner
from execution_planner import ExecutionPlannerV1_2
from ultron_risk_gate import UltronRiskGate
import collector
import logging

try:
    from features.feature_monitor import FeatureMonitor
    _feature_monitor = FeatureMonitor(window_size=500)
    _MONITOR_AVAILABLE = True
except Exception:
    _feature_monitor = None
    _MONITOR_AVAILABLE = False

from utils.logging_config import get_flow_logger
logger = get_flow_logger("LIVE_HOOK")


class HookedLiveEngine(LiveEngine):

    def process(
        self,
        trade_data: dict,
        gaussian_model,
        scaler,
        neural_fn=None,
        candle_idx: int = 0,
        timeframe: str = "M15",
    ) -> dict:
        result = super().process(
            trade_data, gaussian_model, scaler, neural_fn, candle_idx, timeframe
        )

        trade_id = str(trade_data.get("symbol", "UNKNOWN")) + "_" + str(candle_idx)

        features = {
            "body_ratio": float(trade_data.get("body_ratio", 0.0)),
            "retest_depth": float(trade_data.get("retest_depth", 0.0)),
            "displacement": float(trade_data.get("disp_strength", trade_data.get("disp_str", 0.0))),
            "atr": float(trade_data.get("atr", 0.0)),
            "spread": float(trade_data.get("spread", 0.0)),
            "session": str(trade_data.get("session", "UNKNOWN")),
        }

        context = {
            "gaussian_score": float(result.get("confidence", 0.0)),
            "gaussian_p_win": float(
                max(result.get("probabilities") or [0.5]) if result.get("probabilities") else 0.5
            ),
            "candles_since_retest": int(trade_data.get("candles_since_retest", 0)),
            "sweep_detected": bool(trade_data.get("sweep_detected", False)),
            "double_sweep": bool(trade_data.get("double_sweep", False)),
        }

        # Build config from LiveEngineConfig fields relevant to EngineRunner
        engine_config = {
            "min_atr": 0.0005,
            "allowed_sessions": ["london", "new_york", "overlap"],
        }
        # ── Drift detection (FeatureMonitor) ────────────────────────────────
        if _MONITOR_AVAILABLE and _feature_monitor is not None:
            try:
                _feature_monitor.update(features)
                if _feature_monitor.detect_drift(features):
                    logger.warning(
                        "FeatureMonitor: drift detected for %s at candle %d — "
                        "features may be out-of-distribution. Proceeding with caution.",
                        trade_data.get("symbol", "UNKNOWN"),
                        candle_idx,
                    )
            except Exception as _drift_err:
                logger.debug("FeatureMonitor update/detect failed (ignored): %s", _drift_err)

        engine_outputs = EngineRunner(engine_config).run(features, context)

        # ── Layer 2: Execution Planner ──────────────────────────────────────
        trade_context = {
            "symbol": str(trade_data.get("symbol", "UNKNOWN")),
            "signal":  int(trade_data.get("signal", 0)),
            "score":   float(engine_outputs.get("final_score", 0.0)),
            "account_balance": float(trade_data.get("account_balance", 10000.0)),
        }
        planner = ExecutionPlannerV1_2(engine_config)
        trade_plan = planner.plan(engine_outputs, features, trade_context)
        logger.info(
            "ExecutionPlanner: %s | intent=%s | rr=%s",
            trade_plan.get("decision"),
            trade_plan.get("trade_intent"),
            trade_plan.get("rr_ratio"),
        )

        # ── Layer 3: Ultron Risk Gate ────────────────────────────────────────
        ultron_result = {"decision": "skipped", "risk_reason": "planner_did_not_execute"}
        if trade_plan.get("decision") == "execute":
            portfolio_state = {
                "account_balance":     float(trade_data.get("account_balance", 10000.0)),
                "total_open_risk_pct": float(trade_data.get("total_open_risk_pct", 0.0)),
                "trades_today":        int(trade_data.get("trades_today", 0)),
                "daily_loss_pct":      float(trade_data.get("daily_loss_pct", 0.0)),
                "open_positions":      int(trade_data.get("open_positions", 0)),
            }
            gate = UltronRiskGate(engine_config)
            ultron_result = gate.evaluate(trade_plan, portfolio_state)
            logger.info(
                "UltronRiskGate: %s | reason=%s | size=%s",
                ultron_result.get("decision"),
                ultron_result.get("risk_reason"),
                ultron_result.get("final_position_size"),
            )

        outcome = {
            "win":           False,
            "rr":            float(trade_plan.get("rr_ratio", 0.0)),
            "gaussian_rr":   float(result.get("expected_rr", 0.0)),
            "rr_fusion":     float((engine_outputs.get("rr") or {}).get("rr", 0.0)),
            "p_win":         float(context["gaussian_p_win"]),
            "trade_plan":    trade_plan,
            "ultron":        ultron_result,
        }
        collector.collect(trade_id, features, engine_outputs, outcome, context=context)

        return result
