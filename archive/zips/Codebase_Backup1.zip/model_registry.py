"""
model_registry.py
═══════════════════════════════════════════════════════════════════════════════
Versioned model registry with promotion guard.

Every trained model is registered with its eval metrics and composite score.
A new model is ONLY promoted to "active" if it beats the current best by
at least PROMOTION_MARGIN — preventing noisy score fluctuations from
silently deploying a worse model.

Registry lives at models/registry.json.
Active model name lives at models/active.txt.
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional

from evaluator import EvalResult

log = logging.getLogger("ModelRegistry")

MODELS_DIR       = Path("models")
REGISTRY_PATH    = MODELS_DIR / "registry.json"
ACTIVE_PATH      = MODELS_DIR / "active.txt"
PROMOTION_MARGIN = 0.02   # new model must beat current by this margin


# ─────────────────────────────────────────────────────────────────────────────
# REGISTRY ENTRY
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ModelEntry:
    name:            str
    composite_score: float
    accuracy:        float
    precision:       float
    recall:          float
    bucket_stats:    dict
    n_val_samples:   int
    trained_at:      str   # ISO timestamp
    promoted:        bool  = False


# ─────────────────────────────────────────────────────────────────────────────
# REGISTRY
# ─────────────────────────────────────────────────────────────────────────────

class ModelRegistry:

    def __init__(self, models_dir: Path = MODELS_DIR) -> None:
        self.dir      = models_dir
        self.reg_path = models_dir / "registry.json"
        self.act_path = models_dir / "active.txt"
        self.dir.mkdir(parents=True, exist_ok=True)

    # ── Load / Save ───────────────────────────────────────────────────────────

    def _load(self) -> dict[str, dict]:
        if not self.reg_path.exists():
            return {}
        try:
            return json.loads(self.reg_path.read_text())
        except Exception as e:
            log.warning(f"Registry load failed: {e}. Starting fresh.")
            return {}

    def _save(self, reg: dict) -> None:
        self.reg_path.write_text(json.dumps(reg, indent=2))

    # ── Register ──────────────────────────────────────────────────────────────

    def register(self, model_name: str, eval_result: EvalResult) -> ModelEntry:
        """
        Add a trained + evaluated model to the registry.
        Does NOT promote automatically — call try_promote() separately.
        """
        reg  = self._load()
        entry = ModelEntry(
            name            = model_name,
            composite_score = round(eval_result.composite_score, 6),
            accuracy        = round(eval_result.accuracy,        4),
            precision       = round(eval_result.precision,       4),
            recall          = round(eval_result.recall,          4),
            bucket_stats    = eval_result.bucket_stats,
            n_val_samples   = eval_result.n_samples,
            trained_at      = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            promoted        = False,
        )
        reg[model_name] = asdict(entry)
        self._save(reg)
        log.info(f"Registered {model_name}  composite={entry.composite_score:.4f}")
        return entry

    # ── Promotion ─────────────────────────────────────────────────────────────

    def try_promote(self, model_name: str) -> tuple[bool, str]:
        """
        Promote model_name to active if it beats current best by PROMOTION_MARGIN.

        Returns (promoted: bool, reason: str)
        """
        reg = self._load()

        if model_name not in reg:
            return False, f"{model_name} not in registry"

        new_score = reg[model_name]["composite_score"]

        # Get current active model score
        current_name  = self.get_active()
        current_score = 0.0
        if current_name and current_name in reg:
            current_score = reg[current_name]["composite_score"]

        if new_score > current_score + PROMOTION_MARGIN:
            # Promote
            if current_name and current_name in reg:
                reg[current_name]["promoted"] = False
            reg[model_name]["promoted"] = True
            self._save(reg)
            self.act_path.write_text(model_name)
            reason = (
                f"promoted {model_name} (score={new_score:.4f}) "
                f"over {current_name or 'none'} (score={current_score:.4f}) "
                f"Δ={new_score - current_score:+.4f}"
            )
            log.info(reason)
            print(f"\n  ✅ PROMOTED: {reason}\n")
            return True, reason
        else:
            reason = (
                f"not promoted: {model_name} score={new_score:.4f} "
                f"vs active={current_score:.4f} "
                f"Δ={new_score - current_score:+.4f} < margin={PROMOTION_MARGIN}"
            )
            log.info(reason)
            print(f"\n  ⚠  NOT PROMOTED: {reason}\n")
            return False, reason

    # ── Query ─────────────────────────────────────────────────────────────────

    def get_active(self) -> Optional[str]:
        """Return name of currently active model, or None."""
        if not self.act_path.exists():
            return None
        name = self.act_path.read_text().strip()
        return name if name else None

    def get_best(self) -> Optional[tuple[str, float]]:
        """Return (name, score) of highest-scoring registered model."""
        reg = self._load()
        if not reg:
            return None
        best = max(reg.items(), key=lambda kv: kv[1]["composite_score"])
        return best[0], best[1]["composite_score"]

    def list_all(self) -> list[dict]:
        reg = self._load()
        return sorted(reg.values(), key=lambda x: x["composite_score"], reverse=True)

    def print_leaderboard(self, n: int = 10) -> None:
        entries = self.list_all()[:n]
        active  = self.get_active()
        print(f"\n  {'─'*60}")
        print(f"  Model Leaderboard (top {n})")
        print(f"  {'─'*60}")
        print(f"  {'Name':<30} {'Score':>7}  {'Acc':>6}  {'Active'}")
        print(f"  {'─'*60}")
        for e in entries:
            flag = " ← ACTIVE" if e["name"] == active else ""
            print(
                f"  {e['name']:<30} {e['composite_score']:>7.4f}  "
                f"{e['accuracy']:>6.4f}  {flag}"
            )
        print(f"  {'─'*60}\n")


# ─────────────────────────────────────────────────────────────────────────────
# MODULE-LEVEL SINGLETON
# ─────────────────────────────────────────────────────────────────────────────

_registry = ModelRegistry()


def register(model_name: str, eval_result: EvalResult) -> ModelEntry:
    return _registry.register(model_name, eval_result)


def try_promote(model_name: str) -> tuple[bool, str]:
    return _registry.try_promote(model_name)


def get_active() -> Optional[str]:
    return _registry.get_active()


def print_leaderboard(n: int = 10) -> None:
    _registry.print_leaderboard(n)
