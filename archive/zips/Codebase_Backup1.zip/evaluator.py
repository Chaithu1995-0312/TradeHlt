"""
evaluator.py
═══════════════════════════════════════════════════════════════════════════════
Model evaluation: accuracy, confidence buckets, score-outcome calibration.

The composite score used for model selection (see model_registry.py) weights
high-confidence bucket win rates more than raw accuracy — because you only
trade when confidence is high. A model that's 60% accurate overall but 75%
accurate in the 0.7+ bucket is far more useful than one that's 65% flat.
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

log = logging.getLogger("Evaluator")

CONFIDENCE_BUCKETS = [
    (0.50, 0.60, "0.50-0.60"),
    (0.60, 0.70, "0.60-0.70"),
    (0.70, 0.80, "0.70-0.80"),
    (0.80, 1.01, "0.80-1.00"),
]


# ─────────────────────────────────────────────────────────────────────────────
# RESULT
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class EvalResult:
    n_samples:     int
    accuracy:      float
    precision:     float
    recall:        float
    bucket_stats:  dict[str, dict]   # label → {count, win_rate}
    composite_score: float           # used for model selection

    def print(self, label: str = "") -> None:
        tag = f" [{label}]" if label else ""
        print(f"\n  Eval{tag}  n={self.n_samples}")
        print(f"  Accuracy:  {self.accuracy:.4f}")
        print(f"  Precision: {self.precision:.4f}")
        print(f"  Recall:    {self.recall:.4f}")
        print(f"  Composite: {self.composite_score:.4f}")
        print(f"  Confidence buckets:")
        for bucket_label, stats in self.bucket_stats.items():
            wr = stats.get("win_rate")
            wr_str = f"{wr:.3f}" if wr is not None else "  N/A"
            print(f"    {bucket_label}  count={stats['count']:>4}  win_rate={wr_str}")
        print()


# ─────────────────────────────────────────────────────────────────────────────
# EVALUATOR
# ─────────────────────────────────────────────────────────────────────────────

def evaluate(
    model,
    X: list[list[float]],
    y: list[int],
    threshold: float = 0.5,
) -> EvalResult:
    """
    Evaluate a trained TradeNet on held-out validation data.

    Parameters
    ----------
    model     : trained model (eval mode)
    X         : feature vectors (validation set — future data only)
    y         : ground-truth labels
    threshold : decision threshold for binary predictions

    Returns
    -------
    EvalResult
    """
    import torch

    model.eval()
    X_t = torch.tensor(X, dtype=torch.float32)
    y_arr = list(y)

    with torch.no_grad():
        preds_raw = model(X_t).numpy().flatten().tolist()

    n = len(preds_raw)
    pred_labels = [1 if p >= threshold else 0 for p in preds_raw]

    # ── Accuracy ──────────────────────────────────────────────────────────────
    correct  = sum(pl == yl for pl, yl in zip(pred_labels, y_arr))
    accuracy = correct / n if n > 0 else 0.0

    # ── Precision / Recall ────────────────────────────────────────────────────
    tp = sum(pl == 1 and yl == 1 for pl, yl in zip(pred_labels, y_arr))
    fp = sum(pl == 1 and yl == 0 for pl, yl in zip(pred_labels, y_arr))
    fn = sum(pl == 0 and yl == 1 for pl, yl in zip(pred_labels, y_arr))
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0

    # ── Confidence buckets ────────────────────────────────────────────────────
    bucket_stats: dict[str, dict] = {}
    for lo, hi, label in CONFIDENCE_BUCKETS:
        bucket = [
            yl for p, yl in zip(preds_raw, y_arr)
            if lo <= p < hi
        ]
        if bucket:
            bucket_stats[label] = {
                "count":    len(bucket),
                "win_rate": sum(bucket) / len(bucket),
            }
        else:
            bucket_stats[label] = {"count": 0, "win_rate": None}

    # ── Composite score (trading-weighted) ────────────────────────────────────
    composite = _composite_score(accuracy, bucket_stats)

    return EvalResult(
        n_samples       = n,
        accuracy        = accuracy,
        precision       = precision,
        recall          = recall,
        bucket_stats    = bucket_stats,
        composite_score = composite,
    )


# ─────────────────────────────────────────────────────────────────────────────
# COMPOSITE SCORE
# ─────────────────────────────────────────────────────────────────────────────

def _composite_score(accuracy: float, bucket_stats: dict) -> float:
    """
    Weighted score that rewards high-confidence bucket accuracy.
    Trading only happens at high confidence — overall accuracy is secondary.

    Weights:
      40% overall accuracy
      30% win_rate in [0.70-0.80] bucket
      30% win_rate in [0.80-1.00] bucket
    """
    wr_high  = bucket_stats.get("0.70-0.80", {}).get("win_rate") or 0.0
    wr_elite = bucket_stats.get("0.80-1.00", {}).get("win_rate") or 0.0

    return (0.40 * accuracy) + (0.30 * wr_high) + (0.30 * wr_elite)
