"""
dataset_builder.py
═══════════════════════════════════════════════════════════════════════════════
Builds train / validation splits from validated fusion log records.

LEAKAGE PREVENTION RULES (non-negotiable):
  1. Records MUST be time-ordered (log file is append-only → guaranteed).
  2. Split is performed on temporal index, never shuffled.
  3. Validation set is always the MOST RECENT slice of data — it represents
     the future relative to the training window.
  4. Model NEVER sees validation data during training.

Usage:
  from dataset_validator import validate_logs
  from dataset_builder import build_splits

  records, _ = validate_logs("logs/GBPUSD_fusion.jsonl")
  splits = build_splits(records)
  # splits.X_train, splits.y_train, splits.X_val, splits.y_val
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

log = logging.getLogger("DatasetBuilder")

# ─────────────────────────────────────────────────────────────────────────────
# OUTPUT
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class DataSplits:
    X_train:    list[list[float]]
    y_train:    list[int]
    X_val:      list[list[float]]
    y_val:      list[int]
    n_features: int
    split_idx:  int

    @property
    def n_train(self) -> int: return len(self.X_train)

    @property
    def n_val(self) -> int: return len(self.X_val)

    @property
    def class_balance_train(self) -> float:
        """Fraction of wins in training set."""
        return sum(self.y_train) / len(self.y_train) if self.y_train else 0.0

    @property
    def class_balance_val(self) -> float:
        return sum(self.y_val) / len(self.y_val) if self.y_val else 0.0

    def print_summary(self) -> None:
        print(f"\n  Dataset splits:")
        print(f"    Train:      {self.n_train:>5} records  ({self.class_balance_train:.1%} wins)")
        print(f"    Validation: {self.n_val:>5} records  ({self.class_balance_val:.1%} wins)")
        print(f"    Features:   {self.n_features}")
        print(f"    Split idx:  {self.split_idx} (time-ordered, no shuffle)\n")


# ─────────────────────────────────────────────────────────────────────────────
# BUILDER
# ─────────────────────────────────────────────────────────────────────────────

def build_splits(
    records:     list[dict],
    train_ratio: float = 0.70,
) -> DataSplits:
    """
    Build time-ordered train/val splits.

    Parameters
    ----------
    records     : validated records from dataset_validator (time-ordered)
    train_ratio : fraction used for training (default 0.70 = 70% past, 30% future)

    Returns
    -------
    DataSplits
    """
    if not records:
        raise ValueError("No records provided to build_splits.")

    X: list[list[float]] = []
    y: list[int]         = []

    for r in records:
        vec = r.get("feature_vec")
        if not vec:
            continue
        outcome = r.get("outcome", {})
        label   = 1 if outcome.get("win", False) else 0
        X.append(vec)
        y.append(label)

    if not X:
        raise ValueError("No valid feature vectors found in records.")

    n         = len(X)
    split_idx = max(1, int(n * train_ratio))

    # Strict temporal split — no shuffle ever
    X_train, y_train = X[:split_idx], y[:split_idx]
    X_val,   y_val   = X[split_idx:], y[split_idx:]

    from feature_builder import N_FEATURES
    splits = DataSplits(
        X_train    = X_train,
        y_train    = y_train,
        X_val      = X_val,
        y_val      = y_val,
        n_features = N_FEATURES,
        split_idx  = split_idx,
    )

    splits.print_summary()
    return splits


def build_full(records: list[dict]) -> tuple[list[list[float]], list[int]]:
    """
    Return full dataset without splitting (used for final re-training
    after validation confirms the model is safe to promote).
    """
    X, y = [], []
    for r in records:
        vec = r.get("feature_vec")
        if not vec:
            continue
        label = 1 if r.get("outcome", {}).get("win", False) else 0
        X.append(vec)
        y.append(label)
    return X, y
