"""
train_pipeline.py
═══════════════════════════════════════════════════════════════════════════════
Full self-improvement pipeline:

  Logs → Validate → Time-split → Train (past) → Evaluate (future)
       → Register → Promote if better → Load into FusionEngine

Usage:
  python train_pipeline.py                         # train from default logs
  python train_pipeline.py --log-dir logs/         # specific dir
  python train_pipeline.py --force-promote         # skip margin check
  python train_pipeline.py --dry-run               # validate + eval only
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import argparse
import logging
import time
from pathlib import Path

from dataset_validator import validate_logs_multi_instrument, MIN_RECORDS_TO_TRAIN
from dataset_builder   import build_splits, build_full
from trainer           import train, save_model, load_model, make_neural_fn
from evaluator         import evaluate
from model_registry    import register, try_promote, get_active, print_leaderboard

log = logging.getLogger("TrainPipeline")
logging.basicConfig(
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)


# ─────────────────────────────────────────────────────────────────────────────
# PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

def run(
    log_dir:       str  = "logs",
    train_ratio:   float = 0.70,
    epochs:        int   = 100,
    dry_run:       bool  = False,
    force_promote: bool  = False,
) -> None:

    print(f"\n{'═'*60}")
    print(f"  CRT FUSION — TRAINING PIPELINE")
    print(f"{'═'*60}\n")

    # ── Step 1: Validate logs ─────────────────────────────────────────────────
    print("  Step 1/5: Validating logs...")
    records, report = validate_logs_multi_instrument(log_dir=log_dir, verbose=True)

    if not report.is_trainable:
        print(
            f"\n  ❌ Aborting: only {report.valid_for_training} valid records "
            f"(minimum: {MIN_RECORDS_TO_TRAIN}).\n"
            f"  Run more backtests or live sessions to accumulate trade history.\n"
        )
        return

    if dry_run:
        print("  [DRY RUN] Validation complete. Skipping training.\n")
        return

    # ── Step 2: Build time-split ──────────────────────────────────────────────
    print("  Step 2/5: Building time-ordered splits...")
    splits = build_splits(records, train_ratio=train_ratio)

    if splits.n_val < 30:
        print(
            f"\n  ⚠  Only {splits.n_val} validation records — results unreliable.\n"
            f"  Consider collecting more data before trusting this model.\n"
        )

    # ── Step 3: Train on past data only ──────────────────────────────────────
    print(f"  Step 3/5: Training on {splits.n_train} records...")
    t0    = time.perf_counter()
    model = train(splits.X_train, splits.y_train, epochs=epochs, verbose=True)
    elapsed = time.perf_counter() - t0
    print(f"  Training complete in {elapsed:.1f}s")

    # ── Step 4: Evaluate on future (held-out) data ────────────────────────────
    print(f"\n  Step 4/5: Evaluating on {splits.n_val} validation records...")
    result = evaluate(model, splits.X_val, splits.y_val)
    result.print(label="Validation")

    # Save model with timestamp
    model_name = f"tradenet_{int(time.time())}.pth"
    save_model(model, model_name)

    # Register
    entry = register(model_name, result)

    # ── Step 5: Try promotion ─────────────────────────────────────────────────
    print("  Step 5/5: Checking promotion...")
    if force_promote:
        from pathlib import Path as _P
        (_P("models")).mkdir(exist_ok=True)
        (_P("models/active.txt")).write_text(model_name)
        print(f"  [FORCE] Promoted {model_name}\n")
    else:
        promoted, reason = try_promote(model_name)

    print_leaderboard()

    # ── Summary ───────────────────────────────────────────────────────────────
    active = get_active()
    print(f"  Active model: {active or 'none'}")
    print(f"\n{'═'*60}\n")


def load_active_neural_fn():
    """
    Load the currently active model and return a neural_fn callable
    suitable for FusionEngine(neural_fn=...).

    Returns None if no active model is registered yet.
    """
    active = get_active()
    if not active:
        log.warning("No active model registered. Train first with train_pipeline.py.")
        return None
    try:
        model = load_model(active)
        fn    = make_neural_fn(model)
        log.info(f"Loaded active model: {active}")
        return fn
    except Exception as e:
        log.error(f"Failed to load active model {active}: {e}")
        return None


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    ap = argparse.ArgumentParser(description="CRT Fusion — Training Pipeline")
    ap.add_argument("--log-dir",       default="logs",  help="Directory containing *_fusion.jsonl logs")
    ap.add_argument("--train-ratio",   type=float, default=0.70)
    ap.add_argument("--epochs",        type=int,   default=100)
    ap.add_argument("--dry-run",       action="store_true", help="Validate only, skip training")
    ap.add_argument("--force-promote", action="store_true", help="Promote regardless of margin")
    args = ap.parse_args()

    run(
        log_dir       = args.log_dir,
        train_ratio   = args.train_ratio,
        epochs        = args.epochs,
        dry_run       = args.dry_run,
        force_promote = args.force_promote,
    )


if __name__ == "__main__":
    main()
