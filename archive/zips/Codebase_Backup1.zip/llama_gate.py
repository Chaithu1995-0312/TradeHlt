"""
llama_gate.py
═══════════════════════════════════════════════════════════════════════════════
Semantic evaluation gate using a persistent local inference server.
Provides a qualitative score multiplier to the quantitative backtest metrics.
"""

import json
import logging
import re
import urllib.request
import urllib.error
from functools import lru_cache
import json
logger = logging.getLogger("LlamaGate")
logger.setLevel(logging.DEBUG)

# Configuration: Target the local inference server endpoint.
# Defaults to the standard llama.cpp HTTP server port.
SERVER_URL = "http://127.0.0.1:8080/completion"
FAIL_COUNT = 0


def build_prompt(metrics: dict) -> str:
    """
    Constructs a strict, zero-shot prompt forcing a numeric output.
    """
    prompt = (
        "You are a strict quantitative trading risk evaluator. "
        "Review the following backtest metrics and output a single float between "
        "0.0 (terrible, high risk of overfitting) and 1.0 (excellent, robust). "
        "Do not include any other text, explanations, or formatting.\n\n"
        f"Metrics:\n"
        f"Win Rate: {metrics.get('win_rate', 0):.2%}\n"
        f"Expectancy: {metrics.get('expectancy_rr', 0):.2f}R\n"
        f"Trades: {metrics.get('approved_trades', 0)}\n"
        f"Max Drawdown: {metrics.get('max_drawdown_pct', 0):.2%}\n"
        f"Expansions to Retests Ratio: {metrics.get('retests', 0)} / {max(metrics.get('expansions', 1), 1)}\n\n"
        "Score:"
    )
    return prompt

def llm_score(metrics: dict, endpoint: str = SERVER_URL) -> float:
    """
    Calls the local inference server. Returns 1.0 on failure to ensure the pipeline 
    doesn't break, but logs the error. Returns 0.0 if the LLM explicitly rejects the metrics.
    """
    prompt = build_prompt(metrics)
    
    # Payload optimized for llama.cpp / completion endpoints
    payload = {
        "prompt": prompt,
        "n_predict": 4,          # Only need a few tokens for a float
        "temperature": 0.0,      # Maximum determinism
        "cache_prompt": True     # Drastically speeds up inference for static prefix prompts
    }
    
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(endpoint, data=data, headers={'Content-Type': 'application/json'})

    try:
        # Strict 2.0-second timeout enforcement
        with urllib.request.urlopen(req, timeout=2.0) as response:
            result = json.loads(response.read().decode('utf-8'))
            
            # Extract content (adjust key if using a different API wrapper)
            raw_output = result.get('content', '').strip()
            logger.debug(f"Raw LLM output: {raw_output}")

            # Extract the first float found in the output
            match = re.search(r"\b(0\.\d+|1\.0|0\.0)\b", raw_output)
            if match:
                weight = float(match.group(1))
                return max(0.0, min(1.0, weight))
            else:
                logger.warning(f"Could not parse numeric score from LLM output: '{raw_output}'. Defaulting to 1.0.")
                return 1.0

    except urllib.error.URLError as e:
        if isinstance(e.reason, TimeoutError):
            logger.warning("Inference server execution timed out (>2.0s). Defaulting weight to 1.0.")
        else:
            logger.error(f"Failed to connect to inference server at {endpoint}: {e}. Defaulting weight to 1.0.")
        return 1.0
    except Exception as e:
        logger.error(f"Unexpected error in LLM gate HTTP client: {e}. Defaulting weight to 1.0.")
        return 1.0
def llm_score_batch(metrics_list: list[dict], endpoint: str = SERVER_URL) -> list[float]:
    payload = {
        "prompt": [build_prompt(m) for m in metrics_list],
        "n_predict": 4,
        "temperature": 0.0,
        "cache_prompt": True
    }


@lru_cache(maxsize=5000)
def cached_llm_score(metrics_key: str) -> float:
    metrics = json.loads(metrics_key)
    return llm_score(metrics)

def llm_score_cached(metrics: dict) -> float:
    key = json.dumps(metrics, sort_keys=True)
    return cached_llm_score(key)
FAIL_COUNT = 0

def llm_score_safe(metrics):
    global FAIL_COUNT
    
    try:
        score = llm_score(metrics)
        FAIL_COUNT = 0
        return score
    except:
        FAIL_COUNT += 1
        if FAIL_COUNT > 10:
            return 1.0  # disable gate
        return 1.0