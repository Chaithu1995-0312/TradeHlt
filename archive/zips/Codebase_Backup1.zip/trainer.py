"""
trainer.py
═══════════════════════════════════════════════════════════════════════════════
TradeNet — small binary classifier for CRT trade signal quality.

Architecture: 6 → 32 → 16 → 1 (sigmoid)
Input:  feature vector from feature_builder.py (N_FEATURES = 6)
Output: float in [0, 1]  (probability of winning trade)

torch is imported LAZILY inside functions — so this module can be imported
in environments without torch and only fails when training is actually called.
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from feature_builder import N_FEATURES

log = logging.getLogger("Trainer")

MODELS_DIR = Path("models")


# ─────────────────────────────────────────────────────────────────────────────
# MODEL DEFINITION
# ─────────────────────────────────────────────────────────────────────────────

def _build_model():
    """Return a fresh TradeNet. Called lazily to avoid torch import at module load."""
    import torch.nn as nn

    class TradeNet(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(N_FEATURES, 32),
                nn.ReLU(),
                nn.Dropout(0.2),
                nn.Linear(32, 16),
                nn.ReLU(),
                nn.Linear(16, 1),
                nn.Sigmoid(),
            )

        def forward(self, x):
            return self.net(x)

    return TradeNet()


# ─────────────────────────────────────────────────────────────────────────────
# TRAINING
# ─────────────────────────────────────────────────────────────────────────────

def train(
    X: list[list[float]],
    y: list[int],
    epochs:    int   = 100,
    lr:        float = 0.001,
    batch_size: int  = 64,
    verbose:   bool  = True,
):
    """
    Train TradeNet on (X, y).

    Parameters
    ----------
    X       : feature vectors (list of lists, length N_FEATURES each)
    y       : binary labels (1 = win, 0 = loss)
    epochs  : training iterations over full dataset
    lr      : Adam learning rate
    batch_size : mini-batch size; if <= 0 or > len(X), uses full batch

    Returns
    -------
    trained model (eval mode)
    """
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset

    model   = _build_model()
    opt     = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.BCELoss()

    X_t = torch.tensor(X, dtype=torch.float32)
    y_t = torch.tensor(y, dtype=torch.float32).unsqueeze(1)

    dataset = TensorDataset(X_t, y_t)
    bs      = batch_size if 0 < batch_size <= len(X) else len(X)
    loader  = DataLoader(dataset, batch_size=bs, shuffle=True)

    model.train()

    for epoch in range(1, epochs + 1):
        epoch_loss = 0.0
        for xb, yb in loader:
            pred  = model(xb)
            loss  = loss_fn(pred, yb)
            opt.zero_grad()
            loss.backward()
            opt.step()
            epoch_loss += loss.item()

        if verbose and epoch % 20 == 0:
            avg = epoch_loss / len(loader)
            log.info(f"epoch {epoch:>4} / {epochs}  loss={avg:.4f}")
            print(f"  epoch {epoch:>4}/{epochs}  loss={avg:.4f}")

    model.eval()
    return model


# ─────────────────────────────────────────────────────────────────────────────
# SAVE / LOAD
# ─────────────────────────────────────────────────────────────────────────────

def save_model(model, name: str) -> Path:
    import torch
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    path = MODELS_DIR / name
    torch.save(model.state_dict(), path)
    log.info(f"Model saved → {path}")
    return path


def load_model(name: str):
    import torch
    model = _build_model()
    path  = MODELS_DIR / name
    model.load_state_dict(torch.load(path, map_location="cpu"))
    model.eval()
    return model


# ─────────────────────────────────────────────────────────────────────────────
# INFERENCE WRAPPER  (used by FusionEngine as neural_fn)
# ─────────────────────────────────────────────────────────────────────────────

def make_neural_fn(model):
    """
    Returns a callable(features: dict) -> float suitable for FusionEngine.neural_fn.

    Input  : cached_features dict (keys: retest_depth, body_ratio, ...)
    Output : float probability in [0, 1]

    Usage:
      from trainer import load_model, make_neural_fn
      model = load_model("model_v1.pth")
      fn    = make_neural_fn(model)
      fusion = FusionEngine(..., neural_fn=fn)
    """
    import torch
    from feature_builder import feature_dict_to_vector

    def _infer(features: dict) -> float:
        try:
            vec = feature_dict_to_vector(features)
            # Correct shape: [1, N_FEATURES] — unsqueeze(0) adds batch dim
            x   = torch.tensor(vec, dtype=torch.float32).unsqueeze(0)
            with torch.no_grad():
                return float(model(x).item())
        except Exception as e:
            log.warning(f"neural_fn inference failed: {e}. Returning 0.5.")
            return 0.5

    return _infer
