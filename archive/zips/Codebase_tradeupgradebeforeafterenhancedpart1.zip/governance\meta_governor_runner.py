import subprocess

def run_meta_governor_query(prompt):
    bin_path = "./bitnet/bin/main"
    model_path = "./models/bitnet_b1_58_70b.gguf"

    cmd = [
        bin_path, 
        "-m", model_path, 
        "-p", prompt,
        "-n", "256",
        "--temp", "0.2"
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.stdout

def optimize_thresholds(reflection_summary):
    prompt = f"""
    [SYSTEM] You are the Nexus Meta-Governor. 
    [CONTEXT] Current Config: fusion_min_score=0.45, weak_component_threshold=0.55.
    [DATA] {reflection_summary}
    [TASK] Propose a JSON patch to improve the DecisionEngine logic. 
    Response must be ONLY valid JSON.
    """
    response = run_meta_governor_query(prompt)
    return response
