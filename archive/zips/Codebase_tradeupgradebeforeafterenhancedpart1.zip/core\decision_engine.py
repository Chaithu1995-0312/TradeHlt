"""
Central execution authority.

Only this module decides execute vs reject.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class DecisionResult:
    decision: str
    reason: str
    confidence: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision,
            "reason": self.reason,
            "confidence": round(float(self.confidence), 4),
        }


class DecisionEngine:
    def __init__(self, config=None):
        self.config = config
        self.score_threshold = config.get("score_threshold", 0.45)
        self.p_win_threshold = config.get("p_win_threshold", 0.4)
        self.rr_threshold = config.get("rr_threshold", 1.2)
        self.weak_link_weight = 0.30
        # Default 0.30 means final_score must be >= 0.70 to pass.
        # Set to 0.55 to make real threshold 0.45.
        self.weak_component_threshold = config.get("weak_component_threshold", 0.55)
    def evaluate(
        self,
        score: float,
        p_win: float,
        zone_gate: dict,
        fusion: dict,
        config: Any,
    ) -> dict:
        score_threshold = self._get_cfg(config, "score_threshold", 0.45)
        weak_link_weight = self._get_cfg(config, "weak_link_weight", 0.30)
        weak_component_threshold = self._get_cfg(config, "weak_component_threshold", 0.55)

        if not bool(zone_gate.get("valid", False)):
            return self.reject("zone_gate_invalid")

        if float(score) < float(score_threshold):
            return self.reject("low_score")

        if float(p_win) < 0.4:
            return self.reject("low_probability")

        if float(fusion.get("rr", 0.0)) < 1.2:
            return self.reject("low_rr")

        if float(fusion.get("weak_component", 0.0)) > float(weak_component_threshold):
            return self.reject("weak_setup")

        return DecisionResult(
            decision="execute",
            reason="all_conditions_met",
            confidence=max(0.0, min(1.0, float(p_win))),
        ).to_dict()

    @staticmethod
    def reject(reason: str) -> dict:
        return DecisionResult(
            decision="reject",
            reason=reason,
            confidence=0.0,
        ).to_dict()

    @staticmethod
    def _get_cfg(config: Any, key: str, default: float) -> float:
        if isinstance(config, dict):
            return float(config.get(key, default))
        return float(getattr(config, key, default))
