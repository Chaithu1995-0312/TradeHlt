"""
Centralized Logging Configuration for Trading System
Provides per-flow logging differentiation and aligned format across all modules.

Flows:
    FEATURE_PIPELINE  - Step 1: Feature computation pipeline
    ZONE_GATE         - Step 2: BitNet Zone Gate engine
    ENGINE_RUNNER     - Step 3: Engine fusion + decision
    EXECUTION_PLANNER - Step 4: Trade plan generation
    ULTRON_RISK_GATE  - Step 5: Final risk approval
    LIVE_HOOK         - Live execution hook layer
    COLLECTOR         - Structured data collector

All flows log to:
  1. Dedicated individual log file: logs/flow_{name}.log
  2. Aggregated system log: logs/trade_system.log
  3. Console with color coded flow prefix
"""

import logging
import os
from pathlib import Path
from typing import Optional

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True, parents=True)

# Flow definitions
FLOWS = {
    "FEATURE_PIPELINE": {
        "file": "flow_feature_pipeline.log",
        "color": "\033[94m",  # Blue
        "level": logging.INFO
    },
    "ZONE_GATE": {
        "file": "flow_zone_gate.log",
        "color": "\033[96m",  # Cyan
        "level": logging.INFO
    },
    "ENGINE_RUNNER": {
        "file": "flow_engine_runner.log",
        "color": "\033[92m",  # Green
        "level": logging.INFO
    },
    "EXECUTION_PLANNER": {
        "file": "flow_execution_planner.log",
        "color": "\033[93m",  # Yellow
        "level": logging.INFO
    },
    "ULTRON_RISK_GATE": {
        "file": "flow_ultron_risk_gate.log",
        "color": "\033[91m",  # Red
        "level": logging.INFO
    },
    "LIVE_HOOK": {
        "file": "flow_live_hook.log",
        "color": "\033[95m",  # Magenta
        "level": logging.INFO
    },
    "COLLECTOR": {
        "file": "flow_collector.log",
        "color": "\033[90m",  # Gray
        "level": logging.INFO
    }
}

BASE_FORMAT = "[%(asctime)s] [FLOW:%(flow_name)s] [%(levelname)s] %(message)s"
DATE_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
COLOR_RESET = "\033[0m"


class FlowLogFilter(logging.Filter):
    """Filter that injects flow_name into log records"""
    def __init__(self, flow_name: str):
        super().__init__()
        self.flow_name = flow_name

    def filter(self, record):
        record.flow_name = self.flow_name
        return True


class ColoredFlowFormatter(logging.Formatter):
    """Format log lines with color coding per flow"""
    def __init__(self, flow_name: str, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.color = FLOWS[flow_name]["color"] if flow_name in FLOWS else ""

    def format(self, record):
        formatted = super().format(record)
        if self.color:
            return f"{self.color}{formatted}{COLOR_RESET}"
        return formatted


def get_flow_logger(flow_name: str) -> logging.Logger:
    """
    Get a configured logger for a specific system flow.
    Creates per-flow file handler + aggregated system handler + console handler.
    
    Args:
        flow_name: One of the predefined flow names from FLOWS dict
    Returns:
        Configured logging.Logger instance
    """
    if flow_name not in FLOWS:
        raise ValueError(f"Unknown flow name: {flow_name}. Valid flows: {list(FLOWS.keys())}")

    logger = logging.getLogger(f"flow.{flow_name.lower()}")
    logger.propagate = False

    # Prevent duplicate handlers on repeated calls
    if logger.handlers:
        return logger

    config = FLOWS[flow_name]
    logger.setLevel(config["level"])
    logger.addFilter(FlowLogFilter(flow_name))

    # 1. Dedicated per-flow file handler
    flow_file_handler = logging.FileHandler(LOG_DIR / config["file"], encoding="utf-8")
    flow_file_handler.setFormatter(logging.Formatter(BASE_FORMAT, DATE_FORMAT))
    logger.addHandler(flow_file_handler)

    # 2. Aggregated system log handler
    system_file_handler = logging.FileHandler(LOG_DIR / "trade_system.log", encoding="utf-8")
    system_file_handler.setFormatter(logging.Formatter(BASE_FORMAT, DATE_FORMAT))
    logger.addHandler(system_file_handler)

    # 3. Console handler with coloring
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(ColoredFlowFormatter(flow_name, BASE_FORMAT, DATE_FORMAT))
    logger.addHandler(console_handler)

    return logger


def setup_logging() -> None:
    """Initialize logging system. Call once at application startup."""
    logging.basicConfig(level=logging.WARNING, format=BASE_FORMAT, datefmt=DATE_FORMAT)

    # Pre-configure all flow loggers
    for flow_name in FLOWS:
        get_flow_logger(flow_name)

    # Root logger handler for non-flow logs
    root_logger = logging.getLogger()
    root_file_handler = logging.FileHandler(LOG_DIR / "root.log", encoding="utf-8")
    root_file_handler.setFormatter(logging.Formatter("[%(asctime)s] [ROOT] [%(levelname)s] %(message)s", DATE_FORMAT))
    root_logger.addHandler(root_file_handler)


if __name__ == "__main__":
    # Self test
    setup_logging()
    print("=== Testing Logging Configuration ===")

    # Test all flows
    for flow in FLOWS:
        logger = get_flow_logger(flow)
        logger.info(f"Configuration test log for {flow}")

    print(f"\nLog files created in: {LOG_DIR.absolute()}")
    print("✅ Logging configuration initialized successfully")