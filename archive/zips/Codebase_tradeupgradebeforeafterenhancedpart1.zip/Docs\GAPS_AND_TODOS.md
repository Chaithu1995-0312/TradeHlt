﻿# GAPS_AND_TODOS.md
> Confirmed deficiencies, implied-but-missing functionality, and technical debt.
> Priority: 🔴 Critical | 🟡 Important | 🔵 Low/Enhancement

---

## 1. CRITICAL GAPS 🔴

### GAP-001 — No Dedicated Test for UltronRiskGate
**Status:** ✅ RESOLVED (2026-04-10)  
**Module:** `ultron_risk_gate.py`  
**Resolution:**  
- `test_ultron_risk_gate.py` created at repo root with 43 tests.  
- Covers: approval path, TTL enforcement (expired/malformed/naive), RR floor, daily trade limit, kill switch (drawdown breach), portfolio exposure cap, invalid SL distance, position sizing (no hint / hint smaller / hint larger / zero balance / negative hint), rejection response structure, config overrides, and check ordering (first failure wins).

---

### GAP-002 — No Dedicated Test for ExecutionPlanner
**Status:** ✅ RESOLVED (2026-04-10)  
**Module:** `execution_planner.py`  
**Resolution:**  
- `test_execution_planner.py` created at repo root.  
- Covers: happy path for all intent types (BREAKOUT, PULLBACK, LIQ_SWEEP, REVERSAL — long + short), rejection paths (engine reject, missing features, invalid prices, invalid direction, UNKNOWN intent, RR too low, invalid SL/TP order), SL computation per intent, TP computation (ATR-only vs hybrid liquidity), position sizing formula, TTL derivation, precision rounding, execution ID determinism, and config overrides.

---

### GAP-003 — FeatureStore TTL / Staleness Not Implemented
**Status:** 🔴  
**Module:** `core/feature_store.py`  
**Impact:** In live mode, the FeatureStore may serve cached features from a prior bar to the current bar. This produces a one-bar lag in signal computation.  
**Action Required:** Implement `is_fresh(pair, timeframe, max_age_seconds)` and enforce in `FeaturePipeline.build()`.  
**Blocking:** Yes for live trading.

---

### GAP-004 — Slippage Model Absent from ExecutionPlanner
**Status:** 🔴  
**Module:** `execution_planner.py`  
**Impact:** Backtest results do not account for slippage. Live P&L will be lower than backtest P&L for instruments with spread.  
**Action Required:** Add `apply_slippage(plan, spread_config)` to `ExecutionPlanner`. Parameterize spread per instrument in production config.  
**Blocking:** Yes for production accuracy.

---

### GAP-005 — LLMEngine Has No Test and No API Config
**Status:** 🔴  
**Module:** `engines/llm_engine.py`  
**Impact:** LLMEngine cannot be used in production without confirmed API credentials, timeout handling, and response validation. Uncaught API failures propagate as unhandled exceptions.  
**Action Required:** (1) Add `LLM_API_KEY` and `LLM_ENDPOINT` to config. (2) Add timeout + retry logic in `query()`. (3) Create `test_llm_engine.py` with mocked API.  
**Blocking:** Yes if LLMEngine is in production config.

---

### GAP-006 — UltronRiskGate Daily Reset Not Automated
**Status:** 🔴  
**Module:** `ultron_risk_gate.py`  
**Impact:** `reset_daily_stats()` timing is not confirmed to be automated. If not triggered at session open, daily drawdown and exposure limits accumulate indefinitely.  
**Action Required:** Add scheduler trigger in `LiveEngineHook` or `MetaGovernorRunner` to call `reset_daily_stats()` at session open time.  
**Blocking:** Yes for live trading.

---

### GAP-007 — No LiveEngine Test Coverage
**Status:** 🔴  
**Module:** `engines/live_engine.py`  
**Impact:** Tick processing, subscription lifecycle, and decision cycle in live mode are untested.  
**Action Required:** Create `test_live_engine.py` with mock tick stream.  
**Blocking:** Yes for live deployment confidence.

---

### GAP-008 — ModelRegistry.promote() Atomicity Not Confirmed
**Status:** ✅ RESOLVED (2026-04-09)  
**Module:** `model_registry.py`  
**Resolution:**  
- `_save_atomic(path, data)` — writes to `.tmp` sibling then `os.replace()`. Atomic on POSIX (rename) and Windows (MoveFileExW). Readers never see a partial write.  
- `_file_lock(lock_path, timeout)` context manager — cross-process mutual exclusion via `O_CREAT|O_EXCL` lockfile. Times out after 5 s.  
- `_PROMOTE_LOCK` (threading.RLock) — in-process guard.  
- `_assert_single_active(reg, key)` — GOV-3 guard fires before every disk write; raises `RuntimeError` if two entries have `promoted/active=True`.  
- `ModelRegistry.try_promote()` — wrapped in both locks; all state mutations in-memory before single `_save_atomic()` call; `active.txt` written after registry is safe; no longer the canonical truth.  
- `ModelRegistry.get_active()` — hardened: falls back to registry `promoted=True` scan when `active.txt` is stale or names an unregistered model; auto-repairs `active.txt`.  
- `GaussianModelRegistry.promote_gaussian()` — same lock + atomic write pattern; `current_active` derived from registry scan inside the lock (eliminates TOCTOU race).  
- 14 tests in `test_model_registry.py` covering GOV-3 invariant, dual-active prevention, atomic write, fallback paths, and concurrent threading.

---

## 2. IMPORTANT GAPS 🟡

### GAP-009 — AutoTuner Canonical Variant Unclear
**Status:** 🟡  
**Modules:** `auto_tuner.py`, `auto_tuner_multi.py`, `auto_tuner_gemin_pro.py`  
**Impact:** Three variants exist with no documentation on which is canonical for production use. Maintenance burden is tripled.  
**Action Required:** Designate canonical variant. Deprecate or archive others. Document in README.

---

### GAP-010 — FusionEngine Conflict Resolution Policy Not Documented
**Status:** ✅ RESOLVED (2026-04-09)  
**Module:** `core/fusion_engine.py`  
**Resolution:**  
- `conflict_resolution_policy` field added to `FusionConfig` (default `"conservative"`).  
- `FusionEngine.compute()` now detects opposing non-zero directions across `crt`, `gaussian`, `zone_gate`, `rr` engine results and applies the configured policy.  
- `"conservative"`: any conflict → `final_score=0.0`, `reason="directional_conflict"`.  
- `"majority"`: minority direction overruled; exact tie falls back to conservative.  
- Policy externalized to `production_configs/v1_multi_2026_03.json` under `fusion_engine.conflict_resolution_policy`.  
- `EngineRunner` reads policy from config and passes it through `FusionConfig` on construction.  
- Tests added: `test_fusion_conservative_rejects_directional_conflict`, `test_fusion_majority_resolves_conflict`, `test_fusion_majority_tie_falls_back_to_conservative`, `test_fusion_no_conflict_when_directions_agree`.

---

### GAP-011 — FusionEngine Weights Not Externalized
**Status:** ✅ RESOLVED (2026-04-09)  
**Module:** `core/fusion_engine.py`  
**Resolution:**  
- `weight_crt=0.30`, `weight_gaussian=0.25`, `weight_zone_gate=0.25`, `weight_rr=0.20` added to `FusionConfig`.  
- `FusionEngine.compute()` now uses a normalised weighted sum over these fields instead of the hardcoded `/ 4.0` equal average.  
- `EngineRunner._compute_weighted_vote()` updated to read weights from `self.fusion.cfg` — single source of truth.  
- `EngineRunner.__init__()` reads all four weight keys from `config["fusion_engine"]` and passes them through `FusionConfig`.  
- All four keys added to `production_configs/v1_multi_2026_03.json` under `fusion_engine`.  
- Tests added: `test_fusion_weighted_score_reflects_config_weights`, `test_fusion_weighted_score_is_not_flat_average`, `test_fusion_config_defaults_match_production_config`.

---

### GAP-012 — FeatureMonitor Integration Not Confirmed
**Status:** ✅ RESOLVED (2026-04-09)  
**Module:** `features/feature_monitor.py`, `features/feature_pipeline.py`, `runtime/live_engine_hook.py`  
**Resolution:**  
- Live path was already integrated (`live_engine_hook.py` lines 66-78).  
- Live path upgraded from binary `detect_drift()` → `detect_drift_severity()`: `'soft'` → WARNING, `'hard'` → ERROR. Severity surfaced on returned result dict (`result["drift_severity"]`) so callers can gate.  
- Batch path (`FeaturePipeline.run()`) now creates a `FeatureMonitor` instance on `__init__` (injectable). After `finalize()`, each row's `{retest_depth, body_ratio, disp_strength}` is fed to `monitor.update()` + `detect_drift()`. Batch drift count logged at WARNING if > 0.  
- `FeaturePipeline` accepts `monitor=` parameter for cross-run accumulation (live incremental ingestion).  
- Stale `from_trade()` docstring reference removed.  
- Tests added: `test_pipeline_monitor_populated_after_run`, `test_pipeline_monitor_injected_instance_is_shared`, `test_pipeline_monitor_no_drift_on_clean_data`, `test_pipeline_monitor_detects_extreme_drift`.

---

### GAP-013 — Shadow Trade Minimum Not Parameterized
**Status:** ✅ RESOLVED (2026-04-10)  
**Module:** `governance/shadow_promotion_gate.py`  
**Resolution:**  
- `governance` section added to `production_configs/v1_multi_2026_03.json` with `min_shadow_trades: 30`, `shadow_data_csv`, `shadow_output_csv`.  
- `ShadowPromotionGate.__init__()` gains `governance_config: dict` param; auto-loads from production config when not injected. `_validate_min_shadow_trades()` validates type (must be integer-coercible) and range (>= 1) at construction time — `ValueError` on misconfiguration.  
- `execute_shadow_test()` now returns `(total_pnl, n_trades)` tuple.  
- `promote_if_superior(baseline_pnl, shadow_pnl, n_shadow_trades)` enforces two gates in order: (1) sample-size gate blocks if `n_shadow_trades < min_shadow_trades`, (2) performance gate blocks if `shadow_pnl <= baseline_pnl`. Returns `{"promoted": bool, "reason": str}` in all paths.  
- Call site in `exectue_governance_scripts.py` updated to unpack tuple return and pass `n_shadow_trades`.  
- 14 tests in `test_shadow_promotion_gate.py` covering init validation, both gate paths, boundary conditions, return contract.

---

### GAP-014 — RRFusion and RRPatternMiner Not Integrated
**Status:** ✅ RESOLVED (2026-04-10)  
**Modules:** `rr_fusion.py`, `rr_pattern_miner.py`  
**Resolution:**  
- `RRFusionLayer` is imported and wired in `core/engine_runner.py` as a config-gated optional enhancement layer applied after `RREngine` and before `FusionEngine`.  
- Integration uses `rr_fusion.enabled` key in production config; fail-open import guard prevents crashes if module is missing.  
- Test coverage in `tests/test_engine_runner_rr_fusion.py`.

---

### GAP-015 — CUDA Fallback Not Confirmed in MLGaussianEngine
**Status:** ✅ RESOLVED (2026-04-10) — N/A  
**Module:** `engines/ml_gaussian_engine.py`  
**Resolution:**  
- `MLGaussianEngine` uses a pure Python `GaussianNBModel` (no PyTorch, no CUDA dependency). There is no GPU code path and no `get_device()` call.  
- All load and inference exceptions are caught and produce a `{"score": 0.5, "reason": "ml_gaussian_fallback"}` fail-open result. No CUDA concern exists.

---

### GAP-016 — Governance Audit Log Format Not Standardized
**Status:** ✅ RESOLVED (2026-04-10)  
**Module:** `governance/meta_governor_executor.py`  
**Resolution:**  
- Added `MetaGovernorExecutor.log_governance_event(...)` with JSONL output at `logs/governance_audit.jsonl` (or caller-provided path).  
- Enforced required schema fields on every event: `timestamp`, `event_type`, `engine_id`, `metrics_snapshot`, `decision`.  
- Added normalization to keep `metrics_snapshot` and `decision` machine-parseable when callers pass scalar/string values.  
- Added tests in `tests/test_meta_governor_executor.py` to validate schema, serialization, and required-field guards.

---

### GAP-017 — dataset_validator.py Not Called in Training Pipeline
**Status:** ✅ RESOLVED (2026-04-09)  
**Module:** `train_pipeline.py`, `dataset_validator.py`  
**Resolution:**  
- `validate_training_dataset(records)` added to `train_pipeline.py`. Checks per record: required keys, valid label (0/1), all canonical features present and extractable via `extract_feature_vector()`. Returns `(valid_records, report)`.  
- Called at start of `run_training_pipeline()` after `load_training_data()`. Raises `ValueError` if valid count < `MIN_RECORDS_TO_TRAIN` (200). Warns if < `MIN_RECORDS_RECOMMEND` (500).  
- `validation_report` surfaced in `run_training_pipeline()` return dict under `"dataset_validation"` key.  
- `MIN_RECORDS_TO_TRAIN` / `MIN_RECORDS_RECOMMEND` imported from `dataset_validator.py` — single source of truth for thresholds.  
- 10 tests in `test_train_pipeline.py` covering pass, block, per-record skip paths, and pipeline integration.

---

### GAP-018 — ModelRegistry.deregister() Has No Confirmation Gate
**Status:** 🟡  
**Module:** `model_registry.py`  
**Impact:** `deregister()` is irreversible and could be called accidentally by automated scripts.  
**Action Required:** Add `confirm=True` parameter requirement and log deregistration event.

---

## 3. LOW PRIORITY / ENHANCEMENTS 🔵

### GAP-019 — No Cross-Pair Correlation Matrix in UltronRiskGate
**Status:** 🔵  
**Impact:** `check_exposure()` may not account for correlations between pairs (e.g., EURUSD + GBPUSD). This understates actual risk.  
**Action Required:** Add correlation matrix to production config. Weight exposure by correlation coefficient.

---

### GAP-020 — Filename Typo: `exectue_governance_scripts.py`
**Status:** 🔵  
**Module:** `governance/exectue_governance_scripts.py`  
**Impact:** Minor — cosmetic. Causes confusion in imports and references.  
**Action Required:** Rename to `execute_governance_scripts.py`. Update all imports.

---

### GAP-021 — BitNet SearchEngine Purpose Undocumented
**Status:** 🔵  
**Module:** `bitnet/search_engine.py`  
**Impact:** Unknown intent makes maintenance risky.  
**Action Required:** Add docstring explaining purpose. If unused, archive.

---

### GAP-022 — Phase5Calibration Not in CI Pipeline
**Status:** 🔵  
**Impact:** Calibration is a manual step. Automated integration into training pipeline would prevent uncalibrated models from being registered.  
**Action Required:** Add calibration step to `train_pipeline.py` post-training.

---

### GAP-023 — No Health Check / Heartbeat in LiveEngineHook
**Status:** 🔵  
**Module:** `runtime/live_engine_hook.py`  
**Impact:** If the tick stream silently disconnects, the live engine stops trading without alerting operators.  
**Action Required:** Add heartbeat check in `on_bar_close()`. Alert if no tick received within N seconds.

---

### GAP-024 — ReflectionBuffer Persistence Not Confirmed
**Status:** ✅ RESOLVED (2026-04-10) — N/A  
**Module:** `governance/reflection_buffer_basic.py`, `reflection_buffer_advanced.py`  
**Resolution:**  
- Both `ReflectionBuffer` variants hold no in-memory state. Every call reads directly from disk (`logs/collector.jsonl`, `results/trades.csv`). There is no buffer flush step — source data is already file-backed by the collector/backtest output. No crash-loss risk exists.

---

## 4. MISSING DOCUMENTATION

| Item | Module | Status |
|---|---|---|
| HeuristicGaussianEngine heuristic rules | `engines/heuristic_gaussian_engine.py` | 🔴 |
| Zone decay formula | `engines/zone_gate_engine.py` | 🔴 |
| Position sizing method (Kelly vs. fixed) | `execution_planner.py` | 🟡 |
| LLM prompt template | `engines/llm_engine.py` | 🔴 |
| Governance config schema | `governance/` | 🟡 |
| AutoTuner search space definition | `auto_tuner_multi.py` | 🟡 |
