
import json, random

def main():
    random.seed(42)
    model = {
        "layers": [
            {"in":6,"out":32},
            {"in":32,"out":16},
            {"in":16,"out":1}
        ],
        "weights": [],
        "bias": [],
        "scales": []
    }
    for l in model["layers"]:
        w = [[random.choice([-1,1]) for _ in range(l["in"])] for _ in range(l["out"])]
        b = [random.uniform(-1,1) for _ in range(l["out"])]
        model["weights"].append(w)
        model["bias"].append(b)
        model["scales"].append(1.0)
    with open("model.json","w") as f:
        json.dump(model,f,indent=2)

if __name__ == "__main__":
    main()
