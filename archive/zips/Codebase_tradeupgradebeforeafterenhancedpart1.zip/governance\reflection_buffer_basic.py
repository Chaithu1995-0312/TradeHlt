import json
import pandas as pd
from pathlib import Path

class ReflectionBuffer:
    def __init__(self, logs_path="logs/collector.jsonl", trades_path="results/trades.csv"):
        self.logs_path = Path(logs_path)
        self.trades_path = Path(trades_path)

    def generate_reflection_set(self, output_path="logs/reflection_data.json"):
        # Load decision logs
        decisions = []
        with open(self.logs_path, 'r') as f:
            for line in f:
                decisions.append(json.loads(line))
        df_decisions = pd.DataFrame(decisions)

        # Load actual trade outcomes
        df_trades = pd.read_csv(self.trades_path)

        # Join on candle_idx/timestamp to pair the "Intent" with the "Outcome"
        reflection_set = pd.merge(
            df_decisions, 
            df_trades[['candle_idx', 'pnl', 'exit_reason']], 
            on='candle_idx', 
            how='left'
        )

        reflection_data = reflection_set.to_dict(orient='records')

        with open(output_path, 'w') as f:
            json.dump(reflection_data, f, indent=4)

        print(f"Generated reflection set with {len(reflection_data)} records.")
