"""
EngineRunner — orchestrates the full pipeline.

PIPELINE ORDER (strict):
  1. Adapter gating (TrapValidatorEngine) — MUST pass; score <= 0.0 → hard reject
  2. All four engines run unconditionally (CRT, Gaussian, BitNet, RR)
  3. Engine completeness check — if ANY expected engine is absent → hard reject
  4. Fusion — combines all engine outputs into final_score
  5. Decision — threshold applied to final_score
  6. Collector — structured logging of every decision path

ENGINE COMPLETENESS POLICY:
  Fusion silently re-normalizes if engines are missing. To prevent a partial
  engine set from producing an ACCEPT, engine_runner enforces that ALL four
  engines must be present in engine_results before fusion is called.
"""

import logging
import math
import os
from engines.adapter_engine import TrapValidatorEngine
from engines.crt_engine import compute as crt_compute
from engines.heuristic_gaussian_engine import HeuristicGaussianEngine
from engines.ml_gaussian_engine import MLGaussianEngine
from engines.zone_gate_engine import run_zone_gate_engine, _compute_soft_zone_score
from engines.rr_engine import RREngine
from core.fusion_engine import FusionEngine, GaussianAdapter
from core.decision_engine import DecisionEngine
from core.signal_audit import SignalAuditRecorder
from core.acceptance_controller import AcceptanceController
from core.convergence_controller import ConvergenceController
from collector import Collector
from engines.live_engine import get_zone_gate
from utils.logging_config import get_flow_logger

try:
    from rr_fusion import RRFusionLayer
    _RR_FUSION_IMPORT_ERROR = None
except Exception as _rr_fusion_import_exc:  # pragma: no cover - defensive import guard
    RRFusionLayer = None
    _RR_FUSION_IMPORT_ERROR = _rr_fusion_import_exc

logger = get_flow_logger("ENGINE_RUNNER")

EXPECTED_ENGINES = {"crt", "gaussian", "zone_gate", "rr"}

DUAL_ENGINE_DEFAULTS = {
    "trend_strength_threshold": 0.15,
    "momentum_threshold": 0.30,
    "range_volatility_threshold": 0.80,
    "breakout_min_score": 0.30,
    "trap_min_score": 0.40,
    "neutral_min_score": 0.45,
    "fusion_min_score": 0.25,
}


def _safe_float(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _signed_direction(value: float) -> int:
    if value > 0:
        return 1
    if value < 0:
        return -1
    return 0


def detect_regime(features: dict, cfg: dict) -> str:
    trend_strength = abs(_safe_float(features.get("ema_spread"), 0.0))
    momentum = abs(_safe_float(features.get("momentum_score"), 0.0))
    volatility = _safe_float(features.get("volatility_ratio"), 1.0)

    if (
        trend_strength >= _safe_float(cfg.get("trend_strength_threshold"), DUAL_ENGINE_DEFAULTS["trend_strength_threshold"])
        and momentum >= _safe_float(cfg.get("momentum_threshold"), DUAL_ENGINE_DEFAULTS["momentum_threshold"])
    ):
        return "trend"
    if volatility <= _safe_float(cfg.get("range_volatility_threshold"), DUAL_ENGINE_DEFAULTS["range_volatility_threshold"]):
        return "range"
    return "neutral"


def breakout_engine(features: dict, cfg: dict) -> dict:
    trend = _safe_float(features.get("trend_bias"), 0.0)
    momentum = abs(_safe_float(features.get("momentum_score"), 0.0))
    spread = abs(_safe_float(features.get("ema_spread"), 0.0))
    min_score = _safe_float(cfg.get("breakout_min_score"), DUAL_ENGINE_DEFAULTS["breakout_min_score"])

    score = min(1.0, max(0.0, (spread + momentum) / 2.0))
    direction = _signed_direction(trend)
    if score < min_score:
        direction = 0

    return {
        "engine": "breakout",
        "score": float(score),
        "direction": int(direction),
        "reason": "trend_follow" if direction != 0 else "weak_breakout",
        "meta": {
            "trend_bias": float(trend),
            "momentum": float(momentum),
            "ema_spread": float(spread),
        },
    }


def trap_engine(features: dict, cfg: dict) -> dict:
    sweep = _safe_float(features.get("sweep_detected"), 0.0)
    disp = max(0.0, _safe_float(features.get("disp_strength"), 0.0))
    trend = _safe_float(features.get("trend_bias"), 0.0)
    min_score = _safe_float(cfg.get("trap_min_score"), DUAL_ENGINE_DEFAULTS["trap_min_score"])

    if sweep <= 0:
        return {
            "engine": "trap",
            "score": 0.0,
            "direction": 0,
            "reason": "no_sweep",
            "meta": {"trend_bias": float(trend)},
        }

    score = min(1.0, disp)
    direction = -_signed_direction(trend)
    if score < min_score:
        direction = 0

    return {
        "engine": "trap",
        "score": float(score),
        "direction": int(direction),
        "reason": "liquidity_trap" if direction != 0 else "weak_trap",
        "meta": {
            "sweep_detected": int(sweep),
            "disp_strength": float(disp),
            "trend_bias": float(trend),
        },
    }


def ultron_governor(regime: str, dual_results: dict, cfg: dict) -> dict:
    breakout = dual_results.get("breakout", {})
    trap = dual_results.get("trap", {})
    neutral_min = _safe_float(cfg.get("neutral_min_score"), DUAL_ENGINE_DEFAULTS["neutral_min_score"])

    if regime == "trend":
        selected = breakout
        gate_reason = "regime_trend"
    elif regime == "range":
        selected = trap
        gate_reason = "regime_range"
    else:
        b_score = _safe_float(breakout.get("score"), 0.0)
        t_score = _safe_float(trap.get("score"), 0.0)
        b_dir = int(breakout.get("direction", 0))
        t_dir = int(trap.get("direction", 0))

        if b_score < neutral_min and t_score < neutral_min:
            return {"allow": False, "reason": "neutral_low_confidence", "selected": None}
        if b_score >= neutral_min and t_score >= neutral_min and b_dir != 0 and t_dir != 0 and b_dir != t_dir:
            return {"allow": False, "reason": "neutral_conflict", "selected": None}
        selected = breakout if b_score >= t_score else trap
        gate_reason = "regime_neutral_high_confidence"

    direction = int(selected.get("direction", 0))
    if direction == 0:
        return {"allow": False, "reason": f"{gate_reason}_no_direction", "selected": selected}

    return {
        "allow": True,
        "reason": gate_reason,
        "selected": selected,
    }


class EngineRunner:

    @staticmethod
    def _get_gaussian_engine(config: dict):
        """
        Instantiate the correct Gaussian engine based on GAUSSIAN_IMPL env var.

        Priority: env var GAUSSIAN_IMPL > config["gaussian_impl"] > default "heuristic"

        Values:
          "heuristic" → HeuristicGaussianEngine (EMA/momentum kernel)
          "ml"        → MLGaussianEngine (GaussianNBModel, 32-dim)
        """
        impl = os.getenv(
            "GAUSSIAN_IMPL",
            config.get("gaussian_impl", "heuristic") if isinstance(config, dict) else "heuristic"
        ).lower()

        if impl == "ml":
            logger.info("EngineRunner: using MLGaussianEngine (GAUSSIAN_IMPL=ml)")
            return MLGaussianEngine(config)
        else:
            logger.info("EngineRunner: using HeuristicGaussianEngine (GAUSSIAN_IMPL=%s)", impl)
            return HeuristicGaussianEngine(config)

    def __init__(self, config: dict):
        self.config = config
        self.adapter = TrapValidatorEngine(config)
        #self.crt = CRTEngine(config)
        self.gaussian = self._get_gaussian_engine(config)
        self.rr = RREngine(config)
        self.rr_fusion = None
        self._rr_fusion_enabled = False
        rr_fusion_cfg = (config.get("rr_fusion", {}) if isinstance(config, dict) else {}) or {}
        if bool(rr_fusion_cfg.get("enabled", False)):
            if RRFusionLayer is None:
                logger.warning("EngineRunner: rr_fusion requested but import failed: %s", _RR_FUSION_IMPORT_ERROR)
            else:
                try:
                    self.rr_fusion = RRFusionLayer(
                        model_path=str(rr_fusion_cfg.get("model_path", "models/rr_model.json")),
                        threshold=float(rr_fusion_cfg.get("threshold", 0.5)),
                        enabled=True,
                    )
                    self._rr_fusion_enabled = bool(self.rr_fusion.is_loaded)
                    if self.rr_fusion.is_loaded:
                        logger.info("EngineRunner: rr_fusion enabled")
                    else:
                        logger.warning(
                            "EngineRunner: rr_fusion configured but model not loaded: %s",
                            self.rr_fusion.load_error,
                        )
                except Exception as exc:
                    logger.warning("EngineRunner: rr_fusion initialization failed: %s", exc)
                    self.rr_fusion = None
        # Wrap GaussianEngine in GaussianAdapter so FusionEngine.evaluate()
        # uses a real scorer instead of a neutral 0.5 stub.
        # GaussianAdapter.score() delegates to GaussianEngine.compute().
        self._gaussian_adapter = GaussianAdapter(self.gaussian)

        # Convergence layer — injected into FusionEngine.compute()
        self._convergence = ConvergenceController(window_size=500)
        _fusion_cfg_dict = (config or {}).get("fusion_engine", {}) if isinstance(config, dict) else {}
        from core.fusion_engine import FusionConfig
        _fusion_config = FusionConfig(
            weight_crt=float(_fusion_cfg_dict.get("weight_crt", 0.30)),
            weight_gaussian=float(_fusion_cfg_dict.get("weight_gaussian", 0.25)),
            weight_zone_gate=float(_fusion_cfg_dict.get("weight_zone_gate", 0.25)),
            weight_rr=float(_fusion_cfg_dict.get("weight_rr", 0.20)),
            conflict_resolution_policy=_fusion_cfg_dict.get("conflict_resolution_policy", "conservative"),
        )
        self.fusion = FusionEngine(
            gaussian_adapter=self._gaussian_adapter,
            convergence_controller=self._convergence,
            config=_fusion_config,
        )

        self.decision = DecisionEngine(config)
        self.collector = Collector()
        dual_cfg = config.get("dual_engine", {}) if isinstance(config, dict) else {}
        self.dual_cfg = {**DUAL_ENGINE_DEFAULTS, **(dual_cfg or {})}
        self._fusion_use_evaluate = bool(
            (config or {}).get("fusion_use_evaluate", False)
        ) if isinstance(config, dict) else False
        self._fusion_compare_evaluate = bool(
            (config or {}).get("fusion_compare_evaluate", False)
        ) if isinstance(config, dict) else False
        # BitNet zone gate — lazy-loaded singleton; fail-open if registry missing
        zone_registry_path = (
            config.get("zone_registry_path", "models/zone_registry.json")
            if isinstance(config, dict) else "models/zone_registry.json"
        )
        self._zone_gate = get_zone_gate(zone_registry_path)

        # Observability + adaptive control (zero overhead when debug_mode=False)
        debug_mode = bool((config or {}).get("debug_mode", True)) if isinstance(config, dict) else False
        self._audit      = SignalAuditRecorder(debug_mode=debug_mode)
        self._acceptance = AcceptanceController(config)

    def _reject(
        self,
        reason: str,
        input_data: dict = None,
        actual_pnl: float | None = None,
        adapter_result: dict = None,
        engine_results: dict = None,
        fusion_result: dict | None = None,
        dual_results: dict | None = None,
        gate_result: dict | None = None,
    ) -> dict:
        """Build a standardised REJECT record and log it."""
        def _infer_stage(reject_reason: str) -> str:
            r = str(reject_reason or "")
            if r.startswith("adapter_") or r.startswith("data_integrity") or r.startswith("missing_fields") \
               or r.startswith("invalid_session") or r.startswith("low_atr") or r.startswith("non_positive_atr"):
                return "adapter"
            if r.startswith("zone_gate"):
                return "zone_gate"
            if r.startswith("ultron_gate"):
                return "ultron"
            if r.startswith("incomplete_engine_execution") or r.startswith("fusion_missing_engines") \
               or r.startswith("low_fusion_score"):
                return "fusion"
            if r in {"low_score", "low_probability", "low_rr", "weak_setup"}:
                return "decision"
            return "unknown"

        reject_stage = _infer_stage(reason)
        record = {
            "adapter": adapter_result or {},
            "engines": engine_results or {},
            "fusion": fusion_result or {},
            "dual_engines": dual_results or {},
            "gate": gate_result or {},
            "final_score": _safe_float((fusion_result or {}).get("final_score"), 0.0),
            "decision": "REJECT",
            "reason": reason,
            "reject_stage": reject_stage,
            "features": input_data or {},
            "pnl": actual_pnl,
        }
        self.collector.log(record)
        return {
            "decision": "REJECT",
            "reason": reason,
            "score": _safe_float((fusion_result or {}).get("final_score"), 0.0),
            "regime": (gate_result or {}).get("regime"),
            "selected_engine": ((gate_result or {}).get("selected") or {}).get("engine"),
            "reject_stage": reject_stage,
        }

    # ------------------------------------------------------------------
    # Helper: weighted engine vote (advisory — does not replace fusion)
    # ------------------------------------------------------------------

    def _compute_weighted_vote(self, engine_results: dict) -> float:
        """
        Weighted directional vote: Σ(w_i * direction_i * confidence_i).
        Maps [-1, 1] → [0, 1]. Advisory only — logged but does not override
        fusion result unless config["use_weighted_vote"] is True.
        Weights are read from FusionConfig so they stay in sync with compute().
        """
        cfg = getattr(self.fusion, "cfg", None)
        weights = {
            "crt": _safe_float(getattr(cfg, "weight_crt", 0.30), 0.30),
            "gaussian": _safe_float(getattr(cfg, "weight_gaussian", 0.25), 0.25),
            "zone_gate": _safe_float(getattr(cfg, "weight_zone_gate", 0.25), 0.25),
            "rr": _safe_float(getattr(cfg, "weight_rr", 0.20), 0.20),
        }
        total = 0.0
        for name, w in weights.items():
            s = float((engine_results.get(name) or {}).get("score", 0.5))
            direction  = 1 if s >= 0.5 else -1
            confidence = abs(s - 0.5) * 2.0
            total += w * direction * confidence
        return max(0.0, min(1.0, (total + 1.0) / 2.0))

    def _evaluate_fusion_path(self, input_data: dict, context: dict) -> dict:
        """
        Optional evaluate() path adapter.
        Returns a dict contract so callers can merge it into compute() payloads.
        """
        raw_idx = (context or {}).get("candle_idx", input_data.get("candle_idx", 0))
        try:
            candle_idx = int(raw_idx)
        except (TypeError, ValueError):
            candle_idx = 0

        eval_result = self.fusion.evaluate(
            features=input_data,
            signal=context or {},
            candle_idx=candle_idx,
        )
        eval_dict = eval_result.to_dict()
        eval_dict["missing_engines"] = []
        return eval_dict

    def run(self, input_data: dict, context: dict, actual_pnl: float | None = None) -> dict:
        # ------------------------------------------------------------------ #
        # Step 1: Adapter gating                                              #
        # ------------------------------------------------------------------ #
        merged = {**input_data, **(context or {})}
        adapter_result = self.adapter.compute(merged)

        # Audit: start bar record (no-op when debug_mode=False)
        bar_id    = str(input_data.get("bar_id", id(input_data)))
        timestamp = str(input_data.get("timestamp", ""))
        price     = float(input_data.get("close", input_data.get("price", 0.0)))
        self._audit.start_bar(bar_id, timestamp, price)

        # Use <= 0.0 to guard against floating-point values like -0.0 or tiny
        # negatives from future adapter extensions, without relying on == 0.0.
        if adapter_result.get("score", 1.0) <= 0.0:
            reason = adapter_result.get("reason", "adapter_rejected")
            self._audit.finalize("REJECT", reason)
            self._audit.flush()
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
            )

        # ------------------------------------------------------------------ #
        # Step 2: Run ALL engines unconditionally                             #
        # ------------------------------------------------------------------ #
        
        zonegate_input = {**input_data, **(context or {})}

        _zone_threshold = float(
            self.config.get("bitnet_zone_threshold", 0.5)
            if isinstance(self.config, dict) else 0.5
        )

        _exec_mode = (
            self.config.get("zone_gate_execution_mode", "normal")
            if isinstance(self.config, dict) else "normal"
        )

        _debug_mode = bool((self.config or {}).get("debug_mode", False)) if isinstance(self.config, dict) else False
        _zone_debug_config = {
            "zones_loaded_count": len(getattr(self._zone_gate, "_zones", []) or []),
            "inside_zone":        False,
            "zone_strength":      float(zonegate_input.get("zone_strength",  0.0)),
            "zone_freshness":     float(zonegate_input.get("zone_freshness", 0.0)),
            "distance_to_nearest":zonegate_input.get("zone_distance"),
        } if _debug_mode else None

        def _zone_model_fn(vector: list) -> float:
            """Score via BitNetZoneGate. Returns 0.5 on any error (neutral, non-blocking)."""
            try:
                result = self._zone_gate.check(vector)
                return float(result.get("score", 0.5))
            except Exception as _e:
                logger.debug(f"ZoneGate scoring fallback (0.5): {_e}")
                return 0.5

        zone_raw = run_zone_gate_engine(
            raw_features=zonegate_input,
            model_fn=_zone_model_fn,
            threshold=_zone_threshold,
            execution_mode=_exec_mode,
            zone_debug_config=_zone_debug_config,
        )

        # Soft zone scoring (optional override of score only — pass/fail still from hard gate)
        _zone_mode = (self.config or {}).get("zone_mode", "hard") if isinstance(self.config, dict) else "hard"
        if _zone_mode == "soft":
            soft_score = _compute_soft_zone_score(zonegate_input)
            zone_raw = {**zone_raw, "score": soft_score}

        # Audit: record zone result
        self._audit.record_zone(zone_raw)

        zone_result = {
            "engine": "zone_gate",
            "score": float(zone_raw.get("score", 0.0)),
            "direction": 1 if zone_raw.get("passed") else 0,
            "meta": zone_raw,
        }
        crt_result = crt_compute(trade_id="Test:", features=input_data, context={})
        gaussian_result = self.gaussian.compute(input_data)
        rr_result = self.rr.compute(input_data)
        base_rr_score = _safe_float(rr_result.get("score"), 0.0)

        # Optional RR enhancement layer: after RREngine, before FusionEngine.
        if self.rr_fusion and self.rr_fusion.is_loaded:
            try:
                rr_fusion_result = self.rr_fusion.score_dict(
                    depth=_safe_float(input_data.get("retest_depth"), 0.0),
                    body=_safe_float(input_data.get("body_ratio"), 0.0),
                    disp=_safe_float(input_data.get("disp_strength"), 0.0),
                    gaussian_score=_safe_float(gaussian_result.get("score"), 0.5),
                    gaussian_p_win=_safe_float(gaussian_result.get("score"), 0.5),
                    is_asia=_safe_float(input_data.get("is_asia"), 0.0),
                    is_london=_safe_float(input_data.get("is_london"), 0.0),
                    is_newyork=_safe_float(input_data.get("is_newyork"), 0.0),
                    hour=int(_safe_float(input_data.get("hour"), _safe_float((context or {}).get("hour"), 0.0))),
                    threshold=_safe_float(
                        ((self.config or {}).get("rr_fusion", {}) or {}).get("threshold"),
                        0.5,
                    ),
                )
                fused_rr_score = float(rr_fusion_result.get("final_score", rr_result.get("score", 0.0)))
                if not math.isfinite(fused_rr_score):
                    raise ValueError("rr_fusion produced non-finite final_score")
                rr_result = {
                    **rr_result,
                    "score": max(0.0, min(1.0, fused_rr_score)),
                    "rr_fusion": rr_fusion_result,
                }
                logger.debug(
                    "EngineRunner: rr_fusion applied base_rr=%.4f fused_rr=%.4f status=%s",
                    base_rr_score,
                    _safe_float(rr_result.get("score"), 0.0),
                    str(rr_fusion_result.get("status", "unknown")),
                )
            except Exception as exc:
                logger.warning("EngineRunner: rr_fusion failed, using base RR: %s", exc)

        engine_results = {
            "crt": crt_result,
            "gaussian": gaussian_result,
            "zone_gate": zone_result,
            "rr": rr_result,
        }

        # Audit: record all engine scores
        self._audit.record_engines(engine_results)

        # ------------------------------------------------------------------ #
        # Step 3: Engine completeness check                                   #
        # ------------------------------------------------------------------ #
        missing_engines = EXPECTED_ENGINES - engine_results.keys()
        if missing_engines:
            reason = f"incomplete_engine_execution:{sorted(missing_engines)}"
            logger.error(f"EngineRunner: {reason}")
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
                engine_results=engine_results,
            )

        # ------------------------------------------------------------------ #
        # Step 4: Fusion                                                      #
        # ------------------------------------------------------------------ #
        fusion_result = self.fusion.compute(engine_results)
        use_evaluate = bool(getattr(self, "_fusion_use_evaluate", False))
        compare_evaluate = bool(getattr(self, "_fusion_compare_evaluate", False))
        if use_evaluate or compare_evaluate:
            try:
                eval_fusion = self._evaluate_fusion_path(input_data, context)
                if compare_evaluate:
                    fusion_result["evaluate_shadow"] = eval_fusion
                if use_evaluate:
                    fusion_result = {
                        **fusion_result,
                        "final_score": _safe_float(eval_fusion.get("final_score"), 0.0),
                        "evaluate_used": True,
                        "evaluate_action": eval_fusion.get("action"),
                        "evaluate_risk_mult": _safe_float(eval_fusion.get("risk_mult"), 0.0),
                        "evaluate_llm_fired": bool(eval_fusion.get("llm_fired", False)),
                    }
            except Exception as exc:
                logger.warning("EngineRunner: fusion.evaluate path failed, falling back to compute(): %s", exc)

        # Audit: record fusion result
        self._audit.record_fusion(fusion_result)

        # Advisory: weighted engine vote (logged but advisory only)
        _weighted_vote = self._compute_weighted_vote(engine_results)
        if _debug_mode:
            logger.debug("EngineRunner weighted_vote=%.4f", _weighted_vote)

        # Also reject if fusion itself detected missing engines (defensive)
        if fusion_result.get("missing_engines"):
            reason = f"fusion_missing_engines:{fusion_result['missing_engines']}"
            logger.error(f"EngineRunner: {reason}")
            self._audit.finalize("REJECT", reason)
            self._audit.flush()
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
                engine_results=engine_results,
            )

        # ------------------------------------------------------------------ #
        # Step 5: Fusion baseline decision                                    #
        # ------------------------------------------------------------------ #
        final_score = _safe_float(fusion_result.get("final_score"), 0.0)
        if final_score < _safe_float(self.dual_cfg.get("fusion_min_score"), DUAL_ENGINE_DEFAULTS["fusion_min_score"]):
            reason = "low_fusion_score"
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
                engine_results=engine_results,
                fusion_result=fusion_result,
            )

        # ------------------------------------------------------------------ #
        # Step 6: Dual-engine regime gate (Ultron)                            #
        # ------------------------------------------------------------------ #
        regime = detect_regime(input_data, self.dual_cfg)
        dual_results = {
            "breakout": breakout_engine(input_data, self.dual_cfg),
            "trap": trap_engine(input_data, self.dual_cfg),
        }
        gate_result = ultron_governor(regime, dual_results, self.dual_cfg)
        gate_result["regime"] = regime

        if not gate_result.get("allow", False):
            reason = f"ultron_gate:{gate_result.get('reason', 'blocked')}"
            return self._reject(
                reason,
                input_data=input_data,
                actual_pnl=actual_pnl,
                adapter_result=adapter_result,
                engine_results=engine_results,
                fusion_result=fusion_result,
                dual_results=dual_results,
                gate_result=gate_result,
            )

        # ------------------------------------------------------------------ #
        # Step 7: DecisionEngine — FINAL authority (Issue 5 fix)             #
        # DecisionEngine.evaluate() is the ONLY place that emits             #
        # "execute" or "reject". EngineRunner NEVER returns "Approved".      #
        # ------------------------------------------------------------------ #
        selected = gate_result.get("selected", {})
        p_win = _safe_float(
            engine_results.get("gaussian", {}).get("score"), 0.5
        )
        zone_gate_ctx = {
            "valid": bool(zone_result.get("passed", False)),
            "score": _safe_float(zone_result.get("score"), 0.0),
        }
        fusion_ctx = {
            # DecisionEngine expects a true RR ratio (e.g. >= 1.2),
            # not the normalized RR score used by fusion averaging.
            "rr": _safe_float(
                engine_results.get("rr", {}).get("rr_ratio"),
                _safe_float(engine_results.get("rr", {}).get("score"), 0.0),
            ),
            "weak_component": max(
                0.0,
                1.0 - _safe_float(fusion_result.get("final_score"), 0.0),
            ),
        }

        # Inject adaptive thresholds into config — DecisionEngine reads from config
        adaptive_thresholds = self._acceptance.get_thresholds()
        effective_config = {**(self.config or {}), **adaptive_thresholds}

        decision_result = self.decision.evaluate(
            score=final_score,
            p_win=p_win,
            zone_gate=zone_gate_ctx,
            fusion=fusion_ctx,
            config=effective_config,
        )
        # Attach routing metadata (read-only — does NOT change the decision)
        decision_result["regime"] = regime
        decision_result["selected_engine"] = selected.get("engine")
        decision_result["selected_direction"] = selected.get("direction", 0)
        decision_result["dual_score"] = _safe_float(selected.get("score"), 0.0)
        decision_result["gate_reason"] = gate_result.get("reason", "")
        decision_result["final_score"] = final_score
        decision_result["reject_stage"] = (
            "decision" if str(decision_result.get("decision", "")).lower() == "reject" else "none"
        )

        # ------------------------------------------------------------------ #
        # Step 8: Log full record                                             #
        # ------------------------------------------------------------------ #
        self.collector.log({
            "adapter": adapter_result,
            "engines": engine_results,
            "fusion": fusion_result,
            "dual_engines": dual_results,
            "gate": gate_result,
            "final_score": final_score,
            "decision": decision_result.get("decision", "UNKNOWN"),
            "reason": decision_result.get("reason", ""),
            "reject_stage": decision_result.get("reject_stage", "none"),
            "missing_engines": [],
            "features": input_data,
            "pnl": actual_pnl,
        })

        # Update adaptive controllers (per-bar, stateful per session)
        accepted = str(decision_result.get("decision", "")).lower() == "execute"
        self._acceptance.update_metrics(
            engine_scores={
                name: float((result or {}).get("score", 0.0))
                for name, result in engine_results.items()
            },
            fusion_score=final_score,
            accepted=accepted,
        )
        self._acceptance.adjust_thresholds()
        self._convergence.record_outcome(accepted)

        # Finalize audit (no-op when debug_mode=False)
        self._audit.finalize(
            decision=str(decision_result.get("decision", "UNKNOWN")),
            reason=str(decision_result.get("reason", "")),
        )
        self._audit.flush()

        return decision_result
