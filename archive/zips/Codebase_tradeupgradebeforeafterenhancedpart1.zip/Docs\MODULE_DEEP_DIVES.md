﻿# MODULE_DEEP_DIVES.md
> Method-level control flow, Mermaid diagrams, and inter-module logic chains.
> Status: ✅ Implemented | 🟡 Partial | 🔴 Missing | 🧪 Mocked/Experimental

---

## MODULE 1: Feature Pipeline — `features/feature_pipeline.py`

### Control Flow

`FeaturePipeline.build()` is the sole entry point for feature production. It is synchronous, sequential, and must complete atomically before engines receive any data.

```mermaid
sequenceDiagram
    participant Caller as EngineRunner / Runtime
    participant FP as FeaturePipeline
    participant FB as FeatureBuilder
    participant FS_Schema as FeatureSchema
    participant FS_Cache as FeatureStore

    Caller->>FP: build(bar_data, pair, timeframe)
    FP->>FB: _compute_indicators(bars)
    FB-->>FP: raw_features dict
    FP->>FP: _handle_missing_bars(bars) [NaN / gap fill]
    FP->>FS_Schema: validate(raw_features)
    alt Validation fails
        FS_Schema-->>FP: raises FeatureValidationError
        FP-->>Caller: raises (pipeline halted)
    else Validation passes
        FS_Schema-->>FP: OK
        FP->>FS_Cache: put(pair, timeframe, features)
        FP-->>Caller: validated feature dict
    end
```

**Key Invariant:** If `FeatureSchema.validate()` raises, the pipeline MUST propagate the exception. No partial feature vectors may be cached.

**Layer:** Ingestion → Feature  
**Type:** Stateful (writes to FeatureStore)

---

## MODULE 2: Engine Runner + Decision Engine — `core/engine_runner.py` + `core/decision_engine.py`

### Control Flow

`EngineRunner.run()` delegates to `DecisionEngine.decide()`. The decision engine applies a pre-filter (ZoneGate), routes to configured engine(s), and fuses results before returning to EngineRunner for risk gating.

```mermaid
sequenceDiagram
    participant RT as Runtime (Live/Backtest)
    participant ER as EngineRunner
    participant DE as DecisionEngine
    participant ZG as ZoneGateEngine
    participant ENG as Engine (Gaussian/ML/CRT/RR)
    participant FE as FusionEngine
    participant URG as UltronRiskGate
    participant EP as ExecutionPlanner

    RT->>ER: run(features, context)
    ER->>ER: _select_engine(context)
    ER->>DE: decide(features, bar, config)
    DE->>ZG: gate(features, zone_config)
    alt Zone BLOCK
        ZG-->>DE: BLOCK
        DE-->>ER: NoSignal (zone filtered)
    else Zone PASS
        ZG-->>DE: PASS
        DE->>ENG: score(features)
        ENG-->>DE: SignalDict (direction, confidence, score)
        DE->>FE: fuse([signals])
        FE->>FE: _weight_signals()
        FE->>FE: _resolve_conflict()
        FE-->>DE: FusedSignal
        DE-->>ER: FusedSignal
    end
    ER->>URG: evaluate(signal, context)
    alt Risk REJECT
        URG-->>ER: REJECTED (reason)
        ER-->>RT: NoTrade + reason
    else Risk APPROVE
        URG-->>ER: APPROVED
        ER->>EP: plan(signal, config)
        EP-->>ER: ExecutionPlan
        ER->>ER: _build_response(ExecutionPlan, metadata)
        ER-->>RT: ExecutionPlan
    end
```

**Key Invariant:** `UltronRiskGate.evaluate()` is ALWAYS called, even for fused NoSignal — it must record the attempt for daily tracking.

**Layers:** Feature → Cognition → Risk → Service  
**Types:** EngineRunner: Stateful (logs); DecisionEngine: Pure routing; FusionEngine: Pure computation

---

## MODULE 3: UltronRiskGate — `ultron_risk_gate.py`

### State Transition Model

```mermaid
stateDiagram-v2
    [*] --> EVALUATING: signal received
    EVALUATING --> DRAWDOWN_CHECK: enter evaluate()
    DRAWDOWN_CHECK --> EXPOSURE_CHECK: drawdown within limit
    DRAWDOWN_CHECK --> REJECTED: drawdown exceeded
    EXPOSURE_CHECK --> APPROVED: exposure within limit
    EXPOSURE_CHECK --> REJECTED: exposure exceeded
    APPROVED --> [*]: signal stamped APPROVED
    REJECTED --> [*]: signal stamped REJECTED + logged
```

### Risk Gate Checks (Sequential, All Must Pass)

1. **`check_drawdown(account)`** — Compares session drawdown to `max_drawdown_pct` from config. If breached: hard reject.
2. **`check_exposure(positions)`** — Checks open position volume against `max_exposure_lots`. If breached: hard reject.
3. **`approve(signal)`** — Stamps with approval metadata (timestamp, gate version, session P&L snapshot).
4. **`reject(signal, reason)`** — Stamps with rejection reason and logs to audit trail.

**Daily Reset:** `reset_daily_stats()` must be triggered at session open (00:00 server time). If not triggered, daily limits accumulate across sessions — this is a **🟡 risk** if not automated.

**Layer:** Risk  
**Type:** Stateful (tracks session state), Write-authoritative

---

## MODULE 4: FusionEngine — `core/fusion_engine.py`

### Fusion Logic

`FusionEngine.fuse()` accepts a list of SignalDicts from multiple engines and produces a single FusedSignal. The fusion policy is:

1. **Weight Application** (`_weight_signals`): Each engine signal is multiplied by its configured weight. Weights are loaded from production config. If weights are missing, equal weights are 🟡 assumed.
2. **Conflict Resolution** (`_resolve_conflict`): If engines disagree on direction (BUY vs. SELL), the conservative policy applies — default to NoTrade unless one direction holds a supermajority (configurable threshold).
3. **Score Normalization** (`_normalize_scores`): Raw engine scores are mapped to [0,1] before weighting to prevent scale dominance by any single engine.

```mermaid
sequenceDiagram
    participant DE as DecisionEngine
    participant FE as FusionEngine

    DE->>FE: fuse([sig_gaussian, sig_ml, sig_crt])
    FE->>FE: _normalize_scores(signals)
    FE->>FE: _weight_signals(normalized_signals)
    FE->>FE: _resolve_conflict(weighted_signals)
    Note over FE: If directional conflict → NoTrade (conservative)
    FE->>FE: get_fusion_metadata() [provenance]
    FE-->>DE: FusedSignal {direction, confidence, provenance}
```

**Conflict Resolution Policy:** Conservative (no-trade default) — this is a **critical invariant** for risk management. Any change to this policy requires governance review.

**Layer:** Cognition  
**Type:** Pure computation (no side effects)

---

## MODULE 5: Governance Loop — `governance/`

### Governance Cycle State Machine

```mermaid
stateDiagram-v2
    [*] --> IDLE
    IDLE --> COLLECTING: governance cycle triggers
    COLLECTING --> EVALUATING: reflection buffer has N+ trades
    EVALUATING --> RANKING: engine metrics computed
    RANKING --> SHADOW_CHECK: underperformer identified
    SHADOW_CHECK --> PROMOTING: shadow criteria met
    SHADOW_CHECK --> WAITING: shadow criteria not met
    PROMOTING --> REGISTRY_UPDATE: PromotionManager.promote() called
    REGISTRY_UPDATE --> IDLE: governance cycle complete
    WAITING --> IDLE: no action taken
    EVALUATING --> IDLE: insufficient data
```

### Inter-Class Interaction

```
MetaGovernorExecutor.run_cycle()
  → ReflectionBufferAdvanced.compute_metrics()      [reads trade history]
  → MetaGovernorExecutor.evaluate_engines()         [ranks by metrics]
  → ShadowPromotionGate.check(engine_id, metrics)   [promotion gate]
    → ShadowPromotionGate.approve_promotion()        [if criteria met]
  → PromotionManager.promote(model_id, metrics)      [write boundary]
    → ModelRegistry.promote(model_id)                [registry write]
  → MetaGovernorExecutor.log_governance_event()     [audit trail]
```

**Write Boundary:** `ModelRegistry.promote()` is the only method that changes the active model. All paths to this method MUST pass through `ShadowPromotionGate.check()`.

**Layer:** Governance  
**Type:** Transactional (registry write with audit log)

---

## MODULE 6: BitNet Inference — `bitnet_inference.py` + `models/bitnet_runner.py`

### Inference Pipeline

```mermaid
sequenceDiagram
    participant Caller as EngineRunner / BacktestV2
    participant BI as BitNetInference
    participant BR as BitNetRunner

    Caller->>BI: run(features, pair)
    BI->>BI: preprocess(features)
    Note over BI: feature dict → quantized tensor
    BI->>BR: infer(quantized_tensor)
    BR->>BR: forward_pass(tensor)
    Note over BR: 1-bit quantized weights applied
    BR-->>BI: raw_output tensor
    BI->>BI: postprocess(raw_output)
    Note over BI: logits → SignalDict
    BI->>BR: validate_output(output)
    alt Invalid output
        BR-->>BI: validation error
        BI-->>Caller: raises InferenceError
    else Valid
        BI-->>Caller: SignalDict
    end
```

**Quantization Note:** BitNet uses 1-bit weights. The `quantize()` method in `BitNetRunner` converts float32 weights to ±1. This is done at model load time, not inference time. If weights are corrupted post-quantization, output is undefined — `StabilityChecker.check()` should be run after each model load.

**Layer:** Cognition / Inference  
**Type:** Read-only (model weights are frozen at load time)

---

## MODULE 7: Training Pipeline — `training/trainer.py` + `dataset_builder.py` + `phase5_calibration.py`

### Training Lifecycle

```mermaid
sequenceDiagram
    participant CLI as train_pipeline.py
    participant DB as DatasetBuilder
    participant TR as Trainer
    participant EV as Evaluator
    participant CAL as Phase5Calibration
    participant MR as ModelRegistry

    CLI->>DB: build(pair, timeframe, config)
    DB->>DB: label_bars(bars, config)
    DB->>DB: split(dataset, ratio)
    DB-->>CLI: {train, val, test} splits
    CLI->>TR: train(train_split, config)
    TR->>TR: training loop (epochs)
    TR->>TR: compute_loss(predictions, labels)
    TR->>TR: save_model(model, checkpoint_path)
    TR-->>CLI: trained_model
    CLI->>EV: evaluate(trained_model, val_split)
    EV-->>CLI: metrics dict
    CLI->>CAL: calibrate(trained_model, val_split)
    CAL->>CAL: threshold adjustment
    CAL->>CAL: export_calibration(model, path)
    CAL-->>CLI: calibrated_model_path
    CLI->>MR: register(model_id, metadata)
    MR-->>CLI: registration confirmed
```

**Phase 5 Calibration:** Post-training step that adjusts decision thresholds to optimize precision/recall tradeoff. This is domain-specific and should NOT be skipped even if initial training metrics are high.

**Layer:** Training  
**Type:** Write-authoritative (produces model artifacts on disk)

---

## MODULE 8: Zone Gate Engine — `engines/zone_gate_engine.py`

### Zone Gate Logic

The ZoneGateEngine is a hard pre-filter. It does NOT score signals — it blocks or passes them.

```mermaid
sequenceDiagram
    participant DE as DecisionEngine
    participant ZGE as ZoneGateEngine

    DE->>ZGE: gate(features, zone_config)
    ZGE->>ZGE: load_zones(registry_path) [if not cached]
    ZGE->>ZGE: get_active_zones(pair)
    ZGE->>ZGE: is_valid_zone(features)
    Note over ZGE: Checks: price within zone, zone freshness, zone strength score
    alt In valid zone
        ZGE-->>DE: PASS
    else Not in valid zone
        ZGE-->>DE: BLOCK (zone type, distance)
    end
```

**Zone Freshness:** A zone that has been tested multiple times loses validity (strength decays). This decay logic is 🟡 partially confirmed — decay formula not externalized.

**Layer:** Engine  
**Type:** Pure (read-only against zone registry, no writes)

---

## MODULE 9: Unified Replay Harness — `runtime/unified_replay_harness.py`

### Replay Architecture

The replay harness reuses the FULL production pipeline (features → engines → risk → planner) on historical data. This ensures backtest fidelity matches live behavior.

```mermaid
sequenceDiagram
    participant CLI as User / CI
    participant RH as UnifiedReplayHarness
    participant FP as FeaturePipeline
    participant ER as EngineRunner
    participant TL as TradeLogger

    CLI->>RH: run_replay(config)
    RH->>RH: load_history(pair, timeframe, path)
    loop For each bar in history
        RH->>FP: build(bar, pair, timeframe)
        FP-->>RH: features
        RH->>ER: run(features, context)
        ER-->>RH: ExecutionPlan | NoTrade
        RH->>TL: log(ExecutionPlan)
    end
    RH->>RH: collect_results()
    RH->>RH: export_results(path)
    RH-->>CLI: summary + CSV path
```

**Fidelity Guarantee:** Replay uses `EngineRunner.run()` — the same entry point as live trading. Any divergence between replay and live results indicates a look-ahead bias or config mismatch bug.

**Layer:** Runtime  
**Type:** Read-only (historical data), Write for results export

---

## MODULE 10: Model Registry + Promotion — `model_registry.py` + `promotion_manager.py`

### Registry State Transitions

```mermaid
stateDiagram-v2
    [*] --> REGISTERED: ModelRegistry.register()
    REGISTERED --> SHADOW: deploy to shadow mode
    SHADOW --> PROMOTION_PENDING: ShadowPromotionGate.check() passes
    PROMOTION_PENDING --> ACTIVE: PromotionManager.promote()
    ACTIVE --> DEPRECATED: new model promoted
    DEPRECATED --> ARCHIVED: manual or auto-archive
    SHADOW --> REJECTED: shadow metrics fail
    REJECTED --> [*]
```

**Invariant:** Only ONE model may be ACTIVE per (pair, timeframe) combination at any time. `ModelRegistry.promote()` must atomically demote the current ACTIVE before setting the new one.

**Layer:** Governance / Service  
**Type:** Transactional (atomic state change required)