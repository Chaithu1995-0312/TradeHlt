
import os

os.system("python generate_vectors.py")
os.system("python export_model.py")
os.system("python python_runner.py")
print("Run C++ separately then run compare.py")
