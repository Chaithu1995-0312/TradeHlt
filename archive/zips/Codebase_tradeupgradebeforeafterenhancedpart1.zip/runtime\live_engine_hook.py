"""
live_engine_hook.py
Subclass wrapper around LiveEngine - does NOT modify live_engine.py.
Calls EngineRunner -> ExecutionPlannerV1_2 -> UltronRiskGate after process() returns.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime, timezone

import collector

from core.engine_runner import EngineRunner
from engines.live_engine import LiveEngine
from execution_planner import ExecutionPlannerV1_2
from production_config import get_prod_metadata
from ultron_risk_gate import UltronRiskGate
from utils.logging_config import get_flow_logger

try:
    from features.feature_monitor import FeatureMonitor

    _feature_monitor = FeatureMonitor(window_size=500)
    _MONITOR_AVAILABLE = True
except Exception:
    _feature_monitor = None
    _MONITOR_AVAILABLE = False


logger = get_flow_logger("LIVE_HOOK")

_DEFAULT_ENGINE_CONFIG = {
    "min_atr": 0.0005,
    "allowed_sessions": ["asia", "london", "new_york", "overlap"],
}
_ENGINE_CONFIG_CACHE: dict | None = None


def _safe_float(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _normalize_session(value) -> str:
    session_map = {
        0: "asia",
        1: "london",
        2: "new_york",
        3: "overlap",
        "0": "asia",
        "1": "london",
        "2": "new_york",
        "3": "overlap",
        "asia": "asia",
        "asian": "asia",
        "london": "london",
        "newyork": "new_york",
        "new_york": "new_york",
        "ny": "new_york",
        "overlap": "overlap",
    }
    if value is None:
        return "london"
    key = str(value).strip().lower()
    return session_map.get(key, session_map.get(value, key))


def _derive_session(trade_data: dict) -> str:
    if "session" in trade_data and trade_data.get("session") is not None:
        return _normalize_session(trade_data.get("session"))
    if _safe_float(trade_data.get("is_asia"), 0.0) > 0.5:
        return "asia"
    if _safe_float(trade_data.get("is_london"), 0.0) > 0.5:
        return "london"
    if _safe_float(trade_data.get("is_newyork"), 0.0) > 0.5:
        return "new_york"
    return "london"


def _load_engine_config() -> dict:
    global _ENGINE_CONFIG_CACHE
    if _ENGINE_CONFIG_CACHE is not None:
        return deepcopy(_ENGINE_CONFIG_CACHE)

    config = deepcopy(_DEFAULT_ENGINE_CONFIG)
    try:
        metadata = get_prod_metadata()
        engine_cfg = (metadata or {}).get("engine_runner") or {}
        min_atr = _safe_float(engine_cfg.get("min_atr"), config["min_atr"])
        allowed = engine_cfg.get("allowed_sessions", config["allowed_sessions"])
        if isinstance(allowed, list) and allowed:
            config["allowed_sessions"] = [_normalize_session(s) for s in allowed]
        config["min_atr"] = max(0.0, min_atr)
        config["ultron_risk_gate"] = (metadata or {}).get("ultron_risk_gate") or {}
    except Exception as exc:
        logger.warning("LIVE_HOOK: using default engine config; failed to load production metadata: %s", exc)

    _ENGINE_CONFIG_CACHE = deepcopy(config)
    return config


def _build_engine_input(trade_data: dict) -> dict:
    close = _safe_float(trade_data.get("close"), 0.0)
    open_ = _safe_float(trade_data.get("open"), close)
    high = _safe_float(trade_data.get("high"), max(open_, close))
    low = _safe_float(trade_data.get("low"), min(open_, close))
    ema_fast = _safe_float(trade_data.get("ema_fast"), close)
    ema_slow = _safe_float(trade_data.get("ema_slow"), close)
    disp_strength = _safe_float(
        trade_data.get("disp_strength", trade_data.get("disp_str")),
        0.0,
    )

    return {
        "_data_integrity": "real",
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "volume": _safe_float(trade_data.get("volume"), 1.0),
        "atr": max(0.0, _safe_float(trade_data.get("atr"), 0.0)),
        "ema_fast": ema_fast,
        "ema_slow": ema_slow,
        "session": _derive_session(trade_data),
        "trend_bias": _safe_float(trade_data.get("trend_bias"), 0.0),
        "ema_spread": _safe_float(trade_data.get("ema_spread"), ema_fast - ema_slow),
        "momentum_score": _safe_float(trade_data.get("momentum_score"), 0.0),
        "volatility_ratio": max(0.0, _safe_float(trade_data.get("volatility_ratio"), 1.0)),
        "sweep_detected": _safe_float(trade_data.get("sweep_detected"), 0.0),
        "double_sweep": _safe_float(trade_data.get("double_sweep"), 0.0),
        "body_ratio": _safe_float(trade_data.get("body_ratio"), 0.0),
        "disp_strength": disp_strength,
        "retest_depth": _safe_float(trade_data.get("retest_depth"), 0.0),
        "candles_since_retest": int(_safe_float(trade_data.get("candles_since_retest"), 0.0)),
    }


class _DailyResetTracker:
    """Forces trades_today and daily_loss_pct to 0 on UTC day rollover (GAP-006)."""

    def __init__(self) -> None:
        self._last_reset_date: date | None = None

    def apply_reset_if_new_day(self, portfolio_state: dict) -> bool:
        today = datetime.now(timezone.utc).date()
        if self._last_reset_date == today:
            return False
        portfolio_state["trades_today"] = 0
        portfolio_state["daily_loss_pct"] = 0.0
        self._last_reset_date = today
        logger.warning(
            "DailyResetTracker: new UTC day %s — reset trades_today=0, daily_loss_pct=0.0",
            today,
        )
        return True


_daily_reset_tracker = _DailyResetTracker()


class HookedLiveEngine(LiveEngine):
    def process(
        self,
        trade_data: dict,
        gaussian_model,
        scaler,
        neural_fn=None,
        candle_idx: int = 0,
        timeframe: str = "M15",
    ) -> dict:
        result = super().process(
            trade_data, gaussian_model, scaler, neural_fn, candle_idx, timeframe
        )

        trade_id = str(trade_data.get("symbol", "UNKNOWN")) + "_" + str(candle_idx)
        engine_input = _build_engine_input(trade_data)

        drift_features = {
            "body_ratio": float(engine_input.get("body_ratio", 0.0)),
            "retest_depth": float(engine_input.get("retest_depth", 0.0)),
            "disp_strength": float(engine_input.get("disp_strength", 0.0)),
        }

        context = {
            "gaussian_score": float(result.get("confidence", 0.0)),
            "gaussian_p_win": float(
                max(result.get("probabilities") or [0.5]) if result.get("probabilities") else 0.5
            ),
            "candles_since_retest": int(trade_data.get("candles_since_retest", 0)),
            "sweep_detected": bool(trade_data.get("sweep_detected", False)),
            "double_sweep": bool(trade_data.get("double_sweep", False)),
            "symbol": str(trade_data.get("symbol", "UNKNOWN")),
        }

        engine_config = _load_engine_config()

        # Drift detection (FeatureMonitor)
        _drift_severity = "none"
        if _MONITOR_AVAILABLE and _feature_monitor is not None:
            try:
                _feature_monitor.update(drift_features)
                _drift_severity = _feature_monitor.detect_drift_severity(drift_features)
                if _drift_severity == "hard":
                    logger.error(
                        "FeatureMonitor: HARD drift for %s at candle %d - "
                        "features strongly out-of-distribution (Z > 3.0). "
                        "Trade signal unreliable.",
                        trade_data.get("symbol", "UNKNOWN"),
                        candle_idx,
                    )
                elif _drift_severity == "soft":
                    logger.warning(
                        "FeatureMonitor: soft drift for %s at candle %d - "
                        "features mildly out-of-distribution (Z > 2.5).",
                        trade_data.get("symbol", "UNKNOWN"),
                        candle_idx,
                    )
            except Exception as _drift_err:
                logger.debug("FeatureMonitor update/detect failed (ignored): %s", _drift_err)

        engine_outputs = EngineRunner(engine_config).run(engine_input, context)

        trade_context = {
            "symbol": str(trade_data.get("symbol", "UNKNOWN")),
            "signal": int(trade_data.get("signal", 0)),
            "score": float(engine_outputs.get("final_score", 0.0)),
            "account_balance": float(trade_data.get("account_balance", 10000.0)),
        }
        planner = ExecutionPlannerV1_2(engine_config)
        trade_plan = planner.plan(engine_outputs, engine_input, trade_context)
        logger.info(
            "ExecutionPlanner: %s | intent=%s | rr=%s",
            trade_plan.get("decision"),
            trade_plan.get("trade_intent"),
            trade_plan.get("rr_ratio"),
        )

        ultron_result = {"decision": "skipped", "risk_reason": "planner_did_not_execute"}
        if trade_plan.get("decision") == "execute":
            portfolio_state = {
                "account_balance": float(trade_data.get("account_balance", 10000.0)),
                "total_open_risk_pct": float(trade_data.get("total_open_risk_pct", 0.0)),
                "trades_today": int(trade_data.get("trades_today", 0)),
                "daily_loss_pct": float(trade_data.get("daily_loss_pct", 0.0)),
                "open_positions": int(trade_data.get("open_positions", 0)),
            }
            _daily_reset_tracker.apply_reset_if_new_day(portfolio_state)  # GAP-006
            gate = UltronRiskGate(engine_config.get("ultron_risk_gate"))
            ultron_result = gate.evaluate(trade_plan, portfolio_state)
            logger.info(
                "UltronRiskGate: %s | reason=%s | size=%s",
                ultron_result.get("decision"),
                ultron_result.get("risk_reason"),
                ultron_result.get("final_position_size"),
            )

        outcome = {
            "win": False,
            "rr": float(trade_plan.get("rr_ratio", 0.0)),
            "gaussian_rr": float(result.get("expected_rr", 0.0)),
            "rr_fusion": float((engine_outputs.get("rr") or {}).get("rr", 0.0)),
            "p_win": float(context["gaussian_p_win"]),
            "trade_plan": trade_plan,
            "ultron": ultron_result,
            "drift_severity": _drift_severity,
        }
        collector.collect(trade_id, engine_input, engine_outputs, outcome, context=context)

        # Surface drift severity so upstream callers can decide whether to gate.
        result["drift_severity"] = _drift_severity
        return result
