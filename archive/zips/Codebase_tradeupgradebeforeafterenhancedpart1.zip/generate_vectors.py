
import json, random, math

FEATURES = [
    "gaussian_score",
    "rr_ratio",
    "sweep_flag",
    "volume_spike",
    "regime_score",
    "liquidity_distance"
]

def random_record():
    def maybe_nan(x):
        return x if random.random() > 0.1 else 0.0
    return {
        "gaussian_score": maybe_nan(random.uniform(-5,5)),
        "rr_ratio": maybe_nan(random.uniform(0,10)),
        "sweep_flag": random.choice([-1,1]),
        "volume_spike": random.choice([-1,1]),
        "regime_score": maybe_nan(random.uniform(-1,1)),
        "liquidity_distance": maybe_nan(random.uniform(0,1))
    }

def main(n=200):
    random.seed(42)
    data = [random_record() for _ in range(n)]
    with open("test_vectors.json","w") as f:
        json.dump(data,f,indent=2)

if __name__ == "__main__":
    main()
