# 1. Generate enriched trades.csv (already done)
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# 2. Run ReflectionBuffer
from .reflection_buffer_advanced import ReflectionBuffer
buffer = ReflectionBuffer(logs_path="logs/collector.jsonl", trades_path="results/portfolio_p1/GBPUSD_trades.csv")
df = buffer.load_and_merge()
prompt_path = buffer.generate_prompt_payload(df)

# 3. Run MetaGovernorExecutor
from .meta_governor_executor import MetaGovernorExecutor
executor = MetaGovernorExecutor()
raw_output = executor.run_inference(prompt_path)
candidate_patch = executor.extract_and_validate_config(raw_output)

# 4. Shadow test
from .shadow_promotion_gate import ShadowPromotionGate
# governance_config is auto-loaded from production config when not injected
gate = ShadowPromotionGate(active_config_path="production_configs/v1_multi_2026_03.json")
gate.stage_candidate(candidate_patch)
baseline_pnl = ... # you need to compute baseline PnL from a reference backtest
shadow_pnl, n_shadow_trades = gate.execute_shadow_test()
result = gate.promote_if_superior(baseline_pnl, shadow_pnl, n_shadow_trades)
print(f"Shadow gate result: promoted={result['promoted']} reason={result['reason']}")