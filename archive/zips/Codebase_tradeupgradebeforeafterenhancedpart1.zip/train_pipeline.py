import json
import os
import logging
from dataset_builder import build_dataset, extract_feature_vector
from dataset_validator import MIN_RECORDS_TO_TRAIN, MIN_RECORDS_RECOMMEND

logger = logging.getLogger(__name__)


def validate_training_record(record: dict) -> bool:
    """Validate a training record has all required features and a valid label."""
    if "features" not in record:
        raise ValueError("Training record missing 'features' key")
    if "label" not in record:
        raise ValueError("Training record missing 'label' key")
    if record["label"] not in (0, 1):
        raise ValueError(f"Invalid label: {record['label']}. Must be 0 or 1.")
    return True


def load_training_data(path: str) -> list:
    """Load training records from a JSON file."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Training data not found: {path}")
    with open(path, "r") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError("Training data must be a list of records")
    return data


def prepare_training_vectors(records: list) -> tuple:
    """
    Convert training records to (X, y) arrays.
    Each record must have 'features' (dict) and 'label' (0 or 1).
    Returns (feature_matrix, label_vector).

    Raises:
        ValueError: If any record is missing required keys, or features are invalid.
        TypeError: If any feature value has the wrong type.
        AssertionError: If any extracted vector dimension does not match CANONICAL_FEATURE_DIM.
    """
    X = []
    y = []
    for i, record in enumerate(records):
        validate_training_record(record)
        features = record["features"]
        label = record["label"]
        vector = extract_feature_vector(features)
        X.append(vector)
        y.append(label)
    return X, y


def validate_training_dataset(records: list) -> tuple:
    """
    Validate a loaded training dataset before model training.

    Checks per record:
      - Required keys present ('features', 'label')
      - Label is 0 or 1
      - Feature vector extractable and non-degenerate

    Returns
    -------
    (valid_records, report)
      valid_records : list of records that passed all checks
      report        : dict with keys total, valid, skipped_bad_record,
                      skipped_bad_features, warnings, errors

    Raises
    ------
    ValueError
        If the number of valid records is below MIN_RECORDS_TO_TRAIN.
    """
    report = {
        "total":                len(records),
        "valid":                0,
        "skipped_bad_record":   0,
        "skipped_bad_features": 0,
        "warnings":             [],
        "errors":               [],
    }

    valid_records = []
    for i, record in enumerate(records):
        # 1. Schema + label check
        try:
            validate_training_record(record)
        except ValueError as exc:
            report["skipped_bad_record"] += 1
            report["warnings"].append(f"Record {i}: {exc}")
            continue

        # 2. Feature vector extractability
        try:
            extract_feature_vector(record["features"])
        except (ValueError, TypeError, KeyError) as exc:
            report["skipped_bad_features"] += 1
            report["warnings"].append(f"Record {i}: bad feature vector — {exc}")
            continue

        valid_records.append(record)

    report["valid"] = len(valid_records)

    if report["valid"] < MIN_RECORDS_RECOMMEND:
        msg = (
            f"Only {report['valid']} valid records — "
            f"recommend {MIN_RECORDS_RECOMMEND}+ for reliable training."
        )
        report["warnings"].append(msg)
        logger.warning("DatasetValidation: %s", msg)

    if report["valid"] < MIN_RECORDS_TO_TRAIN:
        raise ValueError(
            f"Dataset validation failed: {report['valid']} valid records, "
            f"minimum required is {MIN_RECORDS_TO_TRAIN}. "
            f"Skipped {report['skipped_bad_record']} bad records, "
            f"{report['skipped_bad_features']} bad feature vectors. "
            f"Warnings: {report['warnings']}"
        )

    logger.info(
        "DatasetValidation passed: %d/%d valid records "
        "(%d bad-record, %d bad-features skipped).",
        report["valid"], report["total"],
        report["skipped_bad_record"], report["skipped_bad_features"],
    )
    return valid_records, report


def run_training_pipeline(
    data_path: str,
    model_fn: callable,
    output_path: str = None,
    threshold: float = 0.5,
    calibration_fn: callable = None,
) -> dict:
    """
    Full training pipeline:
    1. Load data
    2. Validate dataset (raises ValueError if below minimum threshold)
    3. Prepare vectors using canonical extract_feature_vector
    4. Run model training
    5. Run Phase-5 Calibration gate (if calibration_fn provided)
    6. Optionally save results
    """
    records = load_training_data(data_path)
    records, validation_report = validate_training_dataset(records)
    X, y = prepare_training_vectors(records)

    logger.info(
        "Training on %d samples with %d features each",
        len(X), len(X[0]) if X else 0,
    )

    results = model_fn(X, y)
    results["dataset_validation"] = validation_report

    # Step 5 — Phase-5 Calibration Gate (GAP-022)
    if calibration_fn is not None:
        logger.info("Phase5Calibration: running post-training calibration gate...")
        calibration_result = calibration_fn(X, y)
        results["calibration"] = calibration_result
        if not calibration_result.get("integration_approved", False):
            raise RuntimeError(
                "Phase5Calibration gate FAILED — model not approved for registration. "
                f"Verdict: {calibration_result.get('verdict', 'unknown')}"
            )
        logger.info("Phase5Calibration: APPROVED — %s", calibration_result.get("verdict", ""))

    if output_path:
        os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(results, f, indent=2)
        logger.info(f"Training results saved to {output_path}")

    return results
