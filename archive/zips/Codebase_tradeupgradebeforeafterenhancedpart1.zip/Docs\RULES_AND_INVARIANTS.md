﻿# RULES_AND_INVARIANTS.md
> Mandatory Constraints, Safety Rails, and Agent-Executable Invariants
> Violation of any HARD rule constitutes a critical system defect.

---

## RULE CLASSIFICATION

| Tag | Meaning |
|---|---|
| `[HARD]` | Non-negotiable. Violation is a system defect. Must be enforced by code, not convention. |
| `[SOFT]` | Strong preference. Violation requires documented justification. |
| `[GOVERNANCE]` | Applies to model lifecycle, promotion, and demotion actions. |
| `[SAFETY]` | Risk/capital protection rules. |
| `[SCHEMA]` | Data contract rules. |
| `[INFRA]` | Infrastructure/operational rules. |

---

## 1. SAFETY RAILS — Do Not Bypass

### SR-1 `[HARD][SAFETY]` — UltronRiskGate is Mandatory
Every signal that originates from any engine MUST pass through `UltronRiskGate.evaluate()` before an `ExecutionPlan` is created.  
**Violation:** Executing a trade without risk gate approval.  
**Enforcement:** `EngineRunner._apply_risk_gate()` must wrap ALL engine outputs unconditionally.  
**Verification Hook:** Assert that `ExecutionPlan.risk_gate_approved == True` before any dispatch.

---

### SR-2 `[HARD][SAFETY]` — Zone Gate is a Hard Pre-Filter
`ZoneGateEngine.gate()` must execute BEFORE any engine scoring. Engines must NOT receive features for bars outside valid zones.  
**Violation:** Engine receives and scores a feature vector that the zone gate would block.  
**Enforcement:** `DecisionEngine._evaluate_zone_gate()` must be the first call in `decide()`.  
**Verification Hook:** Log zone gate decision alongside engine output for audit.

---

### SR-3 `[HARD][SAFETY]` — No Trade After Daily Drawdown Breach
Once `UltronRiskGate.check_drawdown()` returns REJECT for the session, no further trades may be approved for that session regardless of signal quality.  
**Enforcement:** `UltronRiskGate` state must be persisted in memory until `reset_daily_stats()` is called.  
**Reset Trigger:** Must be called exactly once per trading session open. Automated trigger is 🟡 required.

---

### SR-4 `[HARD][SAFETY]` — Maximum Exposure Enforcement
`UltronRiskGate.check_exposure()` must account for ALL open positions across ALL pairs before approving a new signal.  
**Violation:** Approving a new position when total exposure already exceeds `max_exposure_lots`.  
**Note:** Cross-pair correlation MUST be considered (e.g., EURUSD + GBPUSD are partially correlated).

---

### SR-5 `[HARD][SAFETY]` — ExecutionPlan Must Have Valid SL and TP
`ExecutionPlanner.validate_plan()` must reject any plan where `sl_price == None`, `tp_price == None`, or `sl_price == entry_price`.  
**Violation:** Dispatching a trade without a stop-loss.  
**Enforcement:** Hard validation in `validate_plan()` with exception on failure.

---

## 2. SCHEMA INVARIANTS

### SCH-1 `[HARD][SCHEMA]` — Feature Vector Must Pass Schema Validation
`FeatureSchema.validate()` must be called in `FeaturePipeline.build()` before any feature is cached or passed to engines.  
**On failure:** Raise `FeatureValidationError`. Do NOT cache partial or invalid features.  
**Verification:** `test_schema_contracts.py` must pass in CI.

---

### SCH-2 `[HARD][SCHEMA]` — No NaN in Feature Vector Passed to Engines
Any feature dict containing NaN values MUST be rejected at `FeatureSchema.check_nan()`.  
**Violation:** NaN propagating into engine scoring (produces undefined behavior in Gaussian/ML engines).  
**Enforcement:** `check_nan()` is part of the standard `validate()` call.

---

### SCH-3 `[HARD][SCHEMA]` — SignalDict Must Have Required Fields
All engine outputs must conform to the canonical `SignalDict` format before entering `FusionEngine.fuse()`.  
**Required fields (minimum):** `direction` (BUY/SELL/NONE), `confidence` (float [0,1]), `score` (float), `engine_id` (str), `timestamp` (ISO8601).  
**Enforcement:** `AdapterEngine._normalize_output()` is responsible for conformance when non-standard engines are used.

---

### SCH-4 `[SOFT][SCHEMA]` — Model Export Must Conform to `model_export_format.json`
All trained models registered to `ModelRegistry` must have metadata conforming to the canonical export schema.  
**Validation Point:** `ModelRegistry.validate_entry()` before `register()`.

---

## 3. GOVERNANCE INVARIANTS

### GOV-1 `[HARD][GOVERNANCE]` — Only PromotionManager May Call ModelRegistry.promote()
No module may call `ModelRegistry.promote()` directly except `PromotionManager.promote()`.  
**Violation:** Direct promotion bypasses `ShadowPromotionGate.check()` and shadow trade minimum.  
**Do Not Touch Zone:** `ModelRegistry.promote()` — treat as a Write Boundary.

---

### GOV-2 `[HARD][GOVERNANCE]` — Shadow Trade Minimum Before Promotion
A model/engine may not be promoted from SHADOW to ACTIVE until it has completed a minimum number of shadow trades (N = configured in governance config).  
**Enforcement:** `ShadowPromotionGate.check()` must validate shadow trade count.  
**Violation:** Promoting a model with zero or insufficient shadow validation.

---

### GOV-3 `[HARD][GOVERNANCE]` — Single Active Model Per (Pair, Timeframe)
`ModelRegistry` must enforce that exactly one model is ACTIVE per `(pair, timeframe)` combination.  
**Enforcement:** `ModelRegistry.promote()` must atomically demote the previous ACTIVE before setting the new one. This MUST be atomic (or transactional) to prevent dual-active state.

---

### GOV-4 `[SOFT][GOVERNANCE]` — Governance Events Must Be Logged
Every `MetaGovernorExecutor` decision (promote, demote, no-action) must be written to the governance audit log via `log_governance_event()`.  
**Verification:** Audit log file must be append-only.

---

### GOV-5 `[SOFT][GOVERNANCE]` — ReflectionBuffer Must Receive Every Trade Outcome
`ReflectionBuffer.record()` must be called for every completed trade (win or loss).  
**Violation:** Missing trades in reflection buffer produces skewed governance metrics.

---

## 4. LIFECYCLE INVARIANTS

### LC-1 `[HARD]` — FeatureStore Cache Must Not Serve Stale Features to Live Engine
In live mode, `FeatureStore.get()` must validate freshness before returning cached features.  
**TTL Enforcement:** 🔴 Currently inferred as missing — `is_fresh()` method is implied but not confirmed.  
**Risk:** Stale features from a previous bar being served to the engine for the current bar.

---

### LC-2 `[SOFT]` — Engines Must Be Stateless Across Bars
Individual engine `score()` methods must not maintain per-bar state between calls. All state must be passed in via `features` and `context`.  
**Exception:** `LiveEngine.on_tick()` maintains subscription state — this is explicit and expected.

---

### LC-3 `[HARD]` — Model Reload Must Trigger StabilityCheck (BitNet)
After `BitNetRunner.load()`, `StabilityChecker.check()` must be called before the model is declared ready for inference.  
**Verification Hook:** Check that `StabilityChecker.check()` returns True before marking model as READY.

---

## 5. OPERATIONAL INVARIANTS

### OPS-1 `[SOFT][INFRA]` — Training Must Not Use Live Data Directly
`DatasetBuilder.build()` must operate on historical archived data, not the live data feed.  
**Violation:** Training on live tick data introduces look-ahead bias.

---

### OPS-2 `[SOFT][INFRA]` — Backtest Must Use UnifiedReplayHarness (Not Raw Data Loops)
All backtesting must route through `UnifiedReplayHarness.run_replay()` to ensure the same pipeline as live trading is used.  
**Violation:** Custom raw data loops that bypass `FeaturePipeline` or `UltronRiskGate`.

---

### OPS-3 `[SOFT][INFRA]` — AutoTuner Variants Must Not Run Concurrently
Only one `AutoTuner` variant may run at a time. Concurrent tuning sessions corrupt shared model state.

---

### OPS-4 `[HARD][INFRA]` — Destructive Registry Operations Require Confirmation
`ModelRegistry.deregister()` is irreversible. It must require explicit confirmation parameter (`confirm=True`) and log the deregistration event.  
**Do Not Touch Zone:** Never call `deregister()` in automated governance loops without human approval gate.

---

## 6. AGENT SAFETY RAILS (LLM-Executor Specific)

The following are explicit constraints for any LLM agent operating autonomously on this codebase:

### AS-1 — Never Modify UltronRiskGate Thresholds Automatically
Risk thresholds (`max_drawdown_pct`, `max_exposure_lots`) are capital-protection parameters. Any modification requires explicit human approval.

### AS-2 — Never Call ModelRegistry.promote() or .deregister() Without Human Approval
These are write-authoritative operations with irreversible consequences.

### AS-3 — Never Skip FeatureSchema.validate() When Refactoring FeaturePipeline
Any refactor of `FeaturePipeline.build()` must preserve the `FeatureSchema.validate()` call. Removing it silences all schema errors downstream.

### AS-4 — Do Not Merge AutoTuner Variants Without Deprecation Plan
Three AutoTuner variants exist. Merging them requires understanding which is canonical and deprecating the others with explicit documentation.

### AS-5 — Never Run LiveEngine.hook() Against a Non-Calibrated Model
A model without `Phase5Calibration` output must not be promoted to ACTIVE in live mode.

### AS-6 — LLMEngine Responses Must Be Validated Before Signal Use
`LLMEngine.validate_response()` must always be called. LLM hallucinated signals are possible and must be caught before reaching `FusionEngine`.

---

## 7. MANDATORY VERIFICATION HOOKS (CI/CD)

| Hook | Trigger | Test |
|---|---|---|
| Feature schema validation | Every feature pipeline run | `test_schema_contracts.py` |
| Engine runner dual gate | Every EngineRunner code change | `test_engine_runner_dual_gate.py` |
| Zone gate functionality | Every zone config change | `test_zone_gate.py` |
| CRT trap detection | Every CRTEngine change | `test_trap_validator.py` |
| BitNet inference | Every model load | `bitnet/_smoke_test.py` |
| Backtest payload integrity | Every runtime change | `test_backtest_payload_integrity.py` |
| Fusion + validator regression | Every FusionEngine change | `test_fusion_and_validator_regression.py` |
| Gaussian impl switch | Every engine config change | `test_gaussian_impl_switch.py` |
| UltronRiskGate | Risk gate changes | 🔴 No dedicated test — MUST BE ADDED |
| ExecutionPlanner | Planner changes | 🔴 No dedicated test — MUST BE ADDED |