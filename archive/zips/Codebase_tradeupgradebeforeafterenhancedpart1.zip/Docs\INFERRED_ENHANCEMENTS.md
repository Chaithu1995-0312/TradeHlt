﻿# INFERRED_ENHANCEMENTS.md
> Proposed architectural enhancements inferred from codebase analysis.
> All items are INFERRED unless marked [CONFIRMED].
> Status: 🟢 High-Value | 🟡 Medium-Value | � Exploratory

---

## ENHANCEMENT CLASSIFICATION

| Tag | Meaning |
|---|---|
| `[ARCH]` | Architectural change |
| `[PERF]` | Performance improvement |
| `[SAFETY]` | Risk/safety improvement |
| `[OPS]` | Operational/DevOps improvement |
| `[ML]` | Machine learning / model improvement |
| `[GOVERNANCE]` | Governance loop improvement |

---

## 1. HIGH-VALUE ENHANCEMENTS 🟢

### ENH-001 `[ARCH][SAFETY]` — Unified Signal Audit Trail
**Rationale:** Currently, engine signals, fusion decisions, and risk gate decisions are logged at different points with no single correlated record per bar.  
**Proposed:** Introduce a `SignalAuditRecord` per bar containing: features hash, per-engine signal, fusion output, risk gate decision, execution plan, and trade outcome. Store as JSON lines.  
**Impact:** Enables full root-cause analysis for any trade. Feeds governance loop with richer data.  
**Risk of Implementation:** LOW — additive change, no behavioral modification.  
**Entry Point:** `EngineRunner._build_response()` constructs the record; `TradeLogger` persists it.

---

### ENH-002 `[SAFETY][GOVERNANCE]` — Circuit Breaker for Engine Degradation
**Rationale:** If an engine consistently produces losing signals, it continues to participate in fusion until the governance cycle runs (which may be slow).  
**Proposed:** Add a real-time `CircuitBreaker` in `EngineRunner._select_engine()` that temporarily disables an engine if its rolling win rate falls below a threshold (e.g., <40% over last 20 signals).  
**Impact:** Faster response to engine degradation than the governance cycle allows.  
**Risk of Implementation:** MED — requires rolling window state in EngineRunner.  
**State Impact:** EngineRunner gains per-engine rolling metrics.

---

### ENH-003 `[ML]` — Ensemble Confidence Calibration
**Rationale:** `FusionEngine` combines engine scores, but the resulting confidence score is not calibrated to actual win probability.  
**Proposed:** After Phase5Calibration, add a `ConfidenceCalibrator` that maps FusedSignal confidence to historical win probability using Platt scaling or isotonic regression.  
**Impact:** FusedSignal.confidence becomes a reliable probability estimate, enabling better position sizing via Kelly criterion.  
**Risk of Implementation:** MED — requires calibration dataset and new training step.  
**Entry Point:** Between `FusionEngine.fuse()` output and `UltronRiskGate.evaluate()`.

---

### ENH-004 `[GOVERNANCE]` — Automated Shadow Promotion Pipeline
**Rationale:** Currently, shadow deployment and promotion are partially manual. A newly trained model requires human intervention to enter shadow mode and progress to active.  
**Proposed:** Implement `ShadowOrchestrator` that automatically:
  1. Detects new model registrations
  2. Deploys to shadow mode
  3. Monitors shadow metrics via ReflectionBufferAdvanced
  4. Calls ShadowPromotionGate on threshold crossing
  5. Initiates promotion on approval  
**Impact:** Fully automated model lifecycle from training to production.  
**Risk of Implementation:** HIGH — requires careful testing of automated promotion paths.  
**Prerequisite:** GAP-008 (ModelRegistry atomicity) must be resolved first.

---

### ENH-005 `[PERF]` — Async Feature Pipeline for Multi-Pair Live Trading
**Rationale:** `FeaturePipeline.build()` is synchronous. For multi-pair live trading (4+ pairs), sequential feature computation creates latency accumulation.  
**Proposed:** Wrap `FeaturePipeline.build()` calls in `asyncio.gather()` within `LiveEngine` for concurrent per-pair feature computation.  
**Impact:** Reduces multi-pair latency by ~N× (where N = number of pairs), enabling tighter M15 timing.  
**Risk of Implementation:** MED — requires that FeaturePipeline and FeatureStore are thread-safe (FeatureStore cache access must be protected).  
**Caution:** Do NOT apply async to UltronRiskGate — it must remain sequential to prevent race conditions in exposure tracking.

---

### ENH-006 `[SAFETY]` — Feature Drift Alert Integration
**Rationale:** `FeatureMonitor` exists but is not confirmed to trigger alerts. Silent feature drift causes gradual model degradation.  
**Proposed:** 
  1. Establish baseline feature distribution at model promotion time
  2. Monitor KL-divergence per feature on each bar
  3. Alert (`governance/meta_governor_executor.py`) when drift exceeds threshold
  4. Trigger governance cycle early on severe drift  
**Impact:** Proactive detection of market regime shifts or data pipeline failures.  
**Risk of Implementation:** LOW — FeatureMonitor framework exists; alert path to MetaGovernorExecutor is additive.

---

### ENH-007 `[ARCH]` — Canonicalize AutoTuner into Single Configurable Module
**Rationale:** Three AutoTuner variants (`auto_tuner.py`, `auto_tuner_multi.py`, `auto_tuner_gemin_pro.py`) create maintenance fragmentation.  
**Proposed:** Merge into single `AutoTuner` with backend selector: `{optuna | gemini_pro | grid_search}`. Archive non-canonical variants.  
**Impact:** Reduces duplicate code, standardizes hyperparameter search interface.  
**Risk of Implementation:** LOW — internal restructure, no behavioral change to consumers.

---

## 2. MEDIUM-VALUE ENHANCEMENTS 🟡

### ENH-008 `[ML]` — Regime-Aware Engine Routing
**Rationale:** `DecisionEngine._route_to_engine()` uses a static engine selection from config. Different market regimes (trending vs. ranging) favor different engines.  
**Proposed:** Add `RegimeClassifier` (simple: ATR percentile + ADX threshold) that maps current regime to optimal engine subset. Route accordingly.  
**Impact:** Improved signal quality without model retraining.  
**Risk:** MED — introduces dynamic routing that may be harder to debug.

---

### ENH-009 `[OPS]` — Structured Governance Audit Log (JSON Lines)
**Rationale:** Current governance log format is 🟡 unclear. Machine-parseable logs enable automated governance analytics.  
**Proposed:** Standardize `log_governance_event()` to emit JSON lines with schema: `{ts, event_type, engine_id, action, metrics, decision_reason}`.  
**Impact:** Enables dashboarding, automated anomaly detection in governance decisions.  
**Risk:** LOW — logging change only.

---

### ENH-010 `[PERF]` — GaussianEngine Model Cache
**Rationale:** `GaussianEngine.load_model()` reads from disk on each initialization. In multi-pair/multi-timeframe setups, this creates repeated I/O.  
**Proposed:** Add a class-level model cache keyed by `(model_path, mtime)`. Invalidate on file modification.  
**Impact:** Reduces model load latency to near-zero after first load.  
**Risk:** LOW — additive cache with mtime-based invalidation is safe.

---

### ENH-011 `[SAFETY]` — Correlation-Aware Exposure Calculation
**Rationale:** GAP-019. `check_exposure()` currently counts raw lots across pairs without correlation weighting.  
**Proposed:** Load a correlation matrix from config. Weight each pair's exposure by its correlation to the portfolio.  
**Effective Exposure = Σ(lots_i × correlation_i_to_portfolio)**  
**Impact:** More accurate risk management for multi-pair portfolios.  
**Risk:** LOW — read-only change to exposure calculation.

---

### ENH-012 `[ML]` — Online Learning for Gaussian Weights
**Rationale:** Gaussian model parameters are fixed post-training. Market dynamics shift over time.  
**Proposed:** Add incremental update capability to `GaussianEngine` using a sliding window of recent trade outcomes. Update weight means/covariances with exponential decay.  
**Impact:** Model adapts to recent market conditions without full retraining.  
**Risk:** HIGH — online updates can cause model instability. Requires governance gate on update magnitude.  
**Prerequisite:** Must be tested in shadow mode before live deployment.

---

### ENH-013 `[OPS]` — LiveEngineHook Heartbeat and Dead-Man Switch
**Rationale:** GAP-023. Silent disconnection from tick stream stops trading without alert.  
**Proposed:** Add heartbeat timer in `LiveEngineHook`. If no tick received within `max_tick_gap_seconds`, emit alert and attempt reconnection. After N failed reconnections, trigger dead-man switch (close all positions, halt trading).  
**Impact:** Prevents indefinite silent failure in live trading.  
**Risk:** MED — dead-man switch requires confirmed close-all-positions mechanism.

---

### ENH-014 `[GOVERNANCE]` — Promotion Rollback Mechanism
**Rationale:** `PromotionManager` currently has no confirmed rollback. If a promoted model immediately underperforms, reverting to the prior model requires manual intervention.  
**Proposed:** Add `PromotionManager.rollback(model_id)` that:
  1. Looks up the model that was demoted during last promotion
  2. Calls `ModelRegistry.promote()` for the prior model
  3. Logs rollback event  
**Impact:** Reduces recovery time from bad promotion from hours (manual) to seconds (automated).  
**Risk:** MED — requires ModelRegistry to store promotion history.

---

## 3. EXPLORATORY ENHANCEMENTS 🔵

### ENH-015 `[ML]` — LLM Engine as Meta-Reasoner (Not Signal Generator)
**Rationale:** Using LLMEngine to generate directional signals is high-risk due to hallucination. A safer use is as a meta-reasoner that validates the consistency of multi-engine signal confluence.  
**Proposed:** Instead of `LLMEngine` producing a signal, use it to review the `SignalAuditRecord` and flag inconsistencies or anomalies in the fusion decision.  
**Impact:** LLM adds an audit/explainability layer without being in the critical trading path.  
**Risk:** LOW — LLM output is advisory only, not signal-authoritative.

---

### ENH-016 `[ARCH]` — Multi-Timeframe Feature Fusion
**Rationale:** Currently M15 is the primary timeframe. Higher timeframe (H1, H4) context often improves signal quality.  
**Proposed:** Add `MultiTimeframeFeatureBuilder` that computes features at M15, H1, H4. `FusionEngine` receives a feature tensor across timeframes, not just M15.  
**Impact:** Richer context for engine scoring, potentially significant improvement in signal precision.  
**Risk:** HIGH — major architectural change. Requires schema updates, engine compatibility changes.

---

### ENH-017 `[ML]` — Synthetic Data Augmentation for Rare Regimes
**Rationale:** `DatasetBuilder` labels real historical bars. Rare market regimes (extreme volatility, flash crashes) are underrepresented in training data.  
**Proposed:** Add `SyntheticAugmentor` to `DatasetBuilder` that generates synthetic bars for rare regime events using Gaussian noise + volatility scaling.  
**Impact:** Improved model robustness in tail events.  
**Risk:** MED — synthetic data can introduce distribution shift. Must be monitored via `FeatureMonitor`.

---

### ENH-018 `[PERF]` — C++ Runner Integration for Feature Computation
**Rationale:** `cpp_runner.cpp` and `cpp_runner.exe` exist in the repo. Feature computation (indicators) is computationally intensive and a C++ path could be 10-50× faster.  
**Proposed:** Route `FeatureBuilder._compute_indicators()` to the C++ runner via `python_runner.py` subprocess interface. Python path remains as fallback.  
**Impact:** Significant latency reduction for M15 live bar processing.  
**Risk:** MED — platform dependency (Windows binary). Must build from source on Linux.