# Happy Flow: From Market Data to Executable Trade

This document describes the **deterministic, multi-layer trade validation pipeline** of the Canonical Trading System.  
Each layer acts as a strict gate – only if all checks pass does a trade reach execution.

*Ground truth as of 2026-04-04. Any changes to the pipeline MUST update this document.*

---

## 1. Feature Ingestion (FeaturePipeline)

- **Input:** Raw M15 OHLCV data (CSV or live feed).  
- **Output:** 32-dimension canonical feature vector (float32).  
- **Guarantees:**  
  - All 32 features present (validated by `feature_schema.py`).  
  - No NaNs, no inf, no negative prices.  
  - `_data_integrity = "real"` sentinel attached.

---

## 2. BitNet – Zone Gate (Statistical Regime Validation)

The **BitNet module** acts as the first and most critical filter. It ensures that the current market environment matches historically profitable zones.

### 2.1 Cosine Similarity Search (`BitNetSearchEngine`)

- Takes the 32-dim feature vector.  
- Searches `zone_registry.json` for similar historical market clusters (zones).  
- Uses cosine similarity; returns top matching zones.

### 2.2 Zone Validation (`ZoneValidator`)

For a zone to be considered valid, it must meet **all three** hard thresholds:

| Metric | Requirement |
|--------|-------------|
| Sample size | ≥ 100 trades |
| Win rate | > 40% |
| Maximum drawdown | < 25% |

If any fails → **HARD REJECT** (no signal).

### 2.3 Stability Check (`StabilityChecker`)

- Splits the zone's historical data into **5 temporal segments** (chronological).  
- Verifies that performance (RR, win rate) is consistent across all segments.  
- If one segment is an outlier → **REJECT** (zone not stable).

### 2.4 Forward Test (`ForwardTester`)

- Compares training performance vs. out-of-sample test performance.  
- Accepts zone only if **test RR ≥ 0.6 × train RR** (i.e., degradation ≤ 40%).  

### 2.5 Signal & Confidence Output

If all above pass, BitNet outputs:

```json
{
  "signal": -1 | 0 | 1,
  "confidence": 0.0 … 1.0
}
```

- `confidence` reflects how similar the current vector is to the winning zone(s) and the zone's historical win rate.  
- This pair is passed to `EngineRunner` as the ZoneGate engine score.

---

## 3. EngineRunner – Multi-Engine Fusion & Decision

The `EngineRunner` runs **four engines unconditionally** (CRT, Gaussian, ZoneGate, RR).  

### 3.1 TrapValidatorEngine (Adapter Gate)

- Validates data integrity sentinel, session whitelist, ATR > 0.  
- Score = 0.0 → **HARD REJECT**.

### 3.2 Four Engines Run

| Engine | Role | Output |
|--------|------|--------|
| CRT Engine | Candle range theory scoring | score ∈ [0,1] |
| Gaussian Engine | Probabilistic regime score | score ∈ [0,1] |
| ZoneGate Engine (BitNet) | Zone-based confidence | score = confidence, valid flag |
| RR Engine | Risk-reward from price levels | score ∈ [0,1] |

### 3.3 Engine Completeness Check

If any engine missing → **HARD REJECT**.

### 3.4 Fusion Engine (`compute` path)

- Simple arithmetic mean of the four engine scores.  
- `final_score = (crt + gaussian + zone_gate + rr) / 4.0`

### 3.5 Fusion Score Gate

- If `final_score < 0.50` → **REJECT (low_fusion_score)**.

### 3.6 Dual-Engine Regime Gate (Ultron governor)

- Detects market regime (trend / range / neutral) using `detect_regime()`.  
- Runs breakout and trap sub-engines.  
- If regime gate rejects → **REJECT**.

### 3.7 DecisionEngine Evaluation

- Combines final score, p_win (Gaussian score), RR, zone validity, weak component.  
- **Only place** where `decision = "execute"` is emitted.

### 3.8 Output from EngineRunner

```json
{
  "decision": "execute",
  "confidence": 0.82,
  "direction": 1,
  "regime": "trend",
  "final_score": 0.71,
  "selected_engine": "breakout",
  "selected_direction": 1
}
```

---

## 4. Execution Planner v1.2 – Trade Construction

Consumes `engine_result` + raw `features` + `context` to build a concrete trade plan.

### 4.1 Price Validation

- Rejects if any price (close, high, low, atr) is NaN, inf, or ≤ 0.

### 4.2 Intent Derivation (deterministic rules)

| Condition | Intent |
|-----------|--------|
| `sweep_detected` or `double_sweep` | `LIQ_SWEEP` |
| `0.3 ≤ retest_depth ≤ 0.7`, `candles_since_retest ≤ 5`, `momentum_score > 0` | `PULLBACK` |
| `body_ratio > 0.6` and `disp_strength > 1.5` | `BREAKOUT` |
| Counter-trend (EMA fast/slow vs direction) | `REVERSAL` |
| None of above | `UNKNOWN` → **reject** (if configured) |

### 4.3 Entry Logic

| Intent | Entry Type | Price |
|--------|------------|-------|
| `BREAKOUT` / `REVERSAL` | MARKET | `close` |
| `PULLBACK` | LIMIT | `ema_fast` (long) / `ema_slow` (short) |
| `LIQ_SWEEP` | LIMIT | `low + 0.1×ATR` (long) / `high - 0.1×ATR` (short) |

### 4.4 Stop Loss Logic (priority order)

| Intent | SL Method | Price |
|--------|-----------|-------|
| `LIQ_SWEEP` | Beyond sweep wick | `low - 0.2×ATR` (long) / `high + 0.2×ATR` (short) |
| `PULLBACK` | Last N candles | `lowest_low_N` / `highest_high_N` (fallback to current bar) |
| `BREAKOUT` | Breakout candle | `low` / `high` |
| `REVERSAL` | 3-candle swing | `lowest_low_3` / `highest_high_3` |
| Fallback | ATR multiple | `entry ± default_sl_atr_mult × ATR` |

### 4.5 Take Profit Logic (Hybrid: ATR + liquidity)

- Base: ATR multiplier per intent (configurable: 1.0–2.0).  
- Liquidity adjustment: if `touches_high_N ≥ 2` and `volume / volume_ma20 ≥ 1.5`, TP moves to that recent high/low.  
- Outputs TP1 (primary), TP2 (2× ATR), TP3 = None.

### 4.6 Risk-Reward Gate

- Computes `rr_ratio = |TP1 - entry| / |entry - SL|`.  
- If `rr_ratio < min_rr_ratio` (default 1.5) → **REJECT (reject_rr)**.

### 4.7 Sanity Checks

- Long: `SL < entry_price < TP1`.  
- Short: `TP1 < entry_price < SL`.  
- If violated → **REJECT (reject_invalid)**.

### 4.8 Position Size Hint (for Ultron)

- `risk_usd = account_balance × (risk_percent / 100)`.  
- `position_size_hint = risk_usd / risk_amount`.  
- Rounded to 4 decimals.  
- This is a **hint** – Ultron may reduce it further.

### 4.9 Timestamps & TTL

- `created_at` = UTC now.  
- `expires_at = created_at + TTL` (TTL per intent: 120–300 seconds).  
- Execution ID deterministic: `MD5(symbol + intent + rounded_entry + rounded_SL)[:12]`.

### 4.10 Output Schema (Execution Planner)

```json
{
  "decision": "execute",
  "execution_id": "EX_a1b2c3d4e5f6",
  "trade_intent": "BREAKOUT",
  "direction": 1,
  "entry_type": "MARKET",
  "entry_price": 42150.50,
  "stop_loss": 41800.00,
  "take_profit_1": 42750.00,
  "take_profit_2": 43350.00,
  "take_profit_3": null,
  "rr_ratio": 2.3,
  "risk_percent": 0.5,
  "position_size_hint": 0.12,
  "risk_source": "local_estimate",
  "validity_ttl_sec": 180,
  "created_at": "2026-04-04T10:00:00+00:00",
  "expires_at": "2026-04-04T10:03:00+00:00",
  "sl_method": "breakout_candle",
  "tp_method": "hybrid_liquidity",
  "confidence": 0.82,
  "regime": "trend",
  "symbol": "BTCUSDT",
  "signal": 1,
  "score": 0.71,
  "trace": { "..." : "..." }
}
```

---

## 5. Ultron Risk Gate v1 – Final Approval

Consumes the trade plan and the current portfolio state.  
**Only layer that can approve a trade for execution.**

### 5.1 Inputs

- `trade` = output from Execution Planner.  
- `portfolio_state` = `{account_balance, total_open_risk_pct, trades_today, daily_loss_pct, open_positions}`.

### 5.2 Checks (in order, any reject stops the flow)

| Check | Condition | Reject Reason |
|-------|-----------|---------------|
| TTL | `now > expires_at` | `expired_signal` |
| RR floor | `rr_ratio < min_rr_ratio` | `rr_too_low` |
| Daily trade limit | `trades_today ≥ max_trades_per_day` | `daily_limit` |
| Daily loss limit | `daily_loss_pct ≥ max_daily_loss_pct` | `kill_switch` |
| Risk per trade cap | `allowed_risk = min(risk_percent, max_risk_per_trade_pct)` | (capped, not rejected) |
| Portfolio exposure | `open_risk + allowed_risk > max_portfolio_risk_pct` | `over_exposure` |
| Valid SL distance | `abs(entry - SL) == 0` | `invalid_sl_distance` |

### 5.3 Position Sizing (final)

- `risk_usd = balance × (allowed_risk / 100)`.  
- `max_size_by_risk = risk_usd / abs(entry - SL)`.  
- `final_size = min(position_size_hint, max_size_by_risk)` (if hint exists, else `max_size_by_risk`).  
- Rounded to 6 decimals.

### 5.4 Output (Approval)

```json
{
  "decision": "approve",
  "execution_id": "EX_a1b2c3d4e5f6",
  "final_position_size": 0.08,
  "risk_reason": "ok",
  "allowed_risk_pct": 0.5,
  "portfolio_state": {
    "total_risk": 1.8,
    "open_positions": 3
  }
}
```

---

## 6. Executor (ECS – not yet built)

The approved trade is sent to the **Execution Coordination System** (ECS) for order placement, monitoring, and fill confirmation.  

Future layers will include:
- Order routing (broker stubs).  
- Partial fill handling.  
- DynamoDB feedback loop for performance learning.

---

## Summary of Gates

| Layer | Reject Reasons |
|-------|----------------|
| BitNet | Zone sample <100, win rate ≤40%, drawdown ≥25%, stability fail, forward test RR degradation >40% |
| EngineRunner | Trap validator fail, missing engine, fusion score <0.50, regime gate reject |
| Execution Planner | Price invalid, UNKNOWN intent, SL/TP order invalid, RR <1.5 |
| Ultron | Expired signal, daily limits, exposure, invalid SL distance |

Only when **all gates pass** does the system produce an **approved, size-determined trade** ready for execution.

---

## Example: Happy Path Trace

```
Input: EURUSD M15, session=london, ATR=0.0012, body_ratio=0.8, disp_strength=2.2

Step 1 → FeaturePipeline → 32-dim vector ✅
Step 2 → BitNet ZoneGate → zone_score=0.72, zone passed ✅
Step 3 → EngineRunner → crt=0.7, gaussian=0.6, zone=0.72, rr=0.8 → fusion=0.705 ✅
         Regime=trend, breakout engine selected, direction=1 ✅
         DecisionEngine → decision="execute" ✅
Step 4 → Execution Planner → intent=BREAKOUT, entry=1.0850, SL=1.0820, TP1=1.0898
         RR = 0.0048/0.0030 = 1.6 ≥ 1.5 ✅
Step 5 → Ultron Risk Gate → TTL ok, RR ok, trades_today=2 ok, loss=0.3% ok,
         exposure=1.5% ok, SL_distance=0.003 ok → APPROVE ✅
         final_position_size = 0.083

FINAL OUTPUT: APPROVE — Trade ready for broker submission.