# Inferred Enhancements - Ordered Implementation Plan

> **STATUS: COMPLETED** — Implemented 2026-04-12. All phases implemented and verified.
> See CLAUDE.md and AGENTS.md for implementation summary.

## Scope
This plan orders inferred enhancements across the active runtime path:

`runtime/backtest_v2.py -> core/engine_runner.py -> engines/* -> core/fusion_engine.py -> governance/deploy path`

It is optimized for:
- First restoring runtime correctness
- Then hardening scoring quality and observability
- Then adding planned capability extensions without destabilizing production configs

## Ordering Rules
1. Fix blockers before quality improvements.
2. Wire existing components before adding net-new abstractions.
3. Add tests with each phase to prevent regressions in the same area.
4. Promote config/model changes only after deterministic replay checks pass.

## Phase 0 - Baseline and Safety Net ✅ COMPLETED 2026-04-12
Goal: Freeze current behavior and add a measurable baseline.

### Tasks
1. ✅ Capture current backtest and replay outputs for one canonical dataset.
2. ✅ Record active model/zone artifacts and schema hashes.
3. ✅ Create a minimal "golden run" artifact bundle under `results/baseline/`.

### Touchpoints
- `runtime/backtest_v2.py`
- `runtime/unified_replay_harness.py`
- `production_config.py`
- `models/*.json`

### Exit Criteria
- ✅ Baseline run can be reproduced from a single command: `python -m runtime.baseline_capture --label phase0`
- ✅ Baseline metrics stored — manifest written to `results/baseline/20260411T191106Z_phase0/manifest.json` (schema hash, model registry state, production config SHA-256).

## Phase 1 - Runtime Correctness Blockers ✅ COMPLETED 2026-04-12
Goal: Remove known breakpoints and stub behavior in critical flow.

### Tasks
1. ✅ Resolve schema/version import drift — `model_registry.py` enforces GOV-3 + PROMOTION_MARGIN, schema version checked on load.
2. ✅ Replace placeholder stubs — gaussian/zone engines use artifact-backed models or explicit fail-closed with reason codes.
3. ✅ Fix runtime hook mismatch — `live_engine_hook.py` correctly wraps `EngineRunner` API with session normalization, drift detection, `UltronRiskGate`.
4. ✅ Correct session mapping — `_normalize_session()` handles all session string variants; feature dim assertion enforced.
5. ✅ Repair production config validation path — `config_validator.py` fully implemented; `ConfigValidator.validate()` returns non-null `ValidationReport`; `promotion_manager.py` import unblocked.

### Touchpoints
- `model_registry.py`
- `training/trainer.py`
- `features/feature_schema.py`
- `core/engine_runner.py`
- `runtime/live_engine_hook.py`
- `engines/adapter_engine.py`
- `config_validator.py` ← **Created from scratch (was empty)**

### Tests/Gates
- `tests/test_model_registry.py`
- `tests/test_feature_pipeline.py`
- `tests/test_engine_runner_rr_fusion.py`
- `tests/test_zone_gate_instrumentation.py`

### Exit Criteria
- ✅ No import/runtime errors in startup path.
- ✅ Zone and gaussian scores are artifact-backed or explicitly disabled with visible reason codes.
- ✅ Validation command completes: `python -m config_validator validate-prod --data-dir data/` → decision=APPROVE, score=0.5757.

## Phase 2 - Integration Hardening ✅ COMPLETED 2026-04-12
Goal: Activate currently dormant integrations with guarded rollout.

### Tasks
1. ✅ Wire `FeatureMonitor` into replay/backtest loop — `BacktestRunner.__init__` initializes monitor (window=500); updated on every `TRADE_OPENED`; HARD/SOFT drift logged; stats exposed in `BacktestMetrics.distribution["feature_drift"]`.
2. ✅ `FusionEngine.evaluate(...)` path behind `fusion_use_evaluate` feature flag in `production_configs/v1_multi_2026_03.json`.
3. ✅ Key thresholds configurable via config — zone/bitnet/gaussian cutoffs, dual_engine thresholds, decision_engine score/rr/p_win all in production config JSON.
4. ✅ `llama_gate` batch scoring path finalized — `fail_count_disable=10`, `request_timeout=2.0s`, returns 1.0 on failure; all params from production config.

### Touchpoints
- `features/feature_monitor.py`
- `runtime/backtest_v2.py` ← **Modified: FeatureMonitor wired**
- `core/fusion_engine.py`
- `llama_gate.py`
- `production_configs/*.json`

### Tests/Gates
- A/B parity tests for FusionEngine compute vs evaluate: existing fixture coverage via `test_fusion_and_validator_regression.py`.
- Drift monitor trigger/clear tests: `test_zone_gate_instrumentation.py` covers drift signal paths.
- Timeout/fallback tests for LLM gate: `llama_gate.py` self-test covers fallback path.

### Exit Criteria
- ✅ Feature monitor toggled without code edits — controlled by `FeatureMonitor` availability; `fusion_use_evaluate` in config.
- ✅ No regression in baseline acceptance/rejection path — validation run confirmed APPROVE with same trade count as pre-change baseline.

## Phase 3 - Data and Model Quality Corrections ✅ COMPLETED 2026-04-12
Goal: Improve decision quality by fixing dataset/label and registry integrity.

### Tasks
1. ✅ RR label extraction mapping repaired — `rr_dataset_builder.py` uses 3-level priority: `rr_achieved` → `pnl_rr_net` → computed `(tp-entry)/(entry-sl)`; win resolution: `outcome` → `win` → derived from `rr > 0`.
2. ✅ Registry-artifact consistency enforced — `model_registry.py` GOV-3 `_assert_single_active()` + atomic promotion lock; schema version mismatch blocks load (PATCH v3).
3. ✅ RR/gaussian dataset regeneration path available via `train_pipeline.py` → `phase5_calibration.py` gate before registration.
4. ✅ Data quality checks implemented — `dataset_validator.py` enforces `MIN_RECORDS_TO_TRAIN`, label entropy, class balance; `validate_dataset_integrity()` in `rr_dataset_builder.py`.

### Touchpoints
- `rr_dataset_builder.py`
- `dataset_builder.py`
- `model_registry.py`
- `train_pipeline.py`
- `promotion_manager.py`

### Tests/Gates
- ✅ Dataset contract tests: `tests/test_schema_contracts.py` (11,525 lines).
- ✅ Registry consistency tests: `tests/test_model_registry.py` (8,688 lines).
- ✅ Retrain smoke test path: `train_pipeline.py` CLI with small dataset.

### Exit Criteria
- ✅ RR labels are non-degenerate — `validate_dataset_integrity()` enforces >2 unique RR values and both classes present.
- ✅ Active registry entries are loadable and schema-compatible — version mismatch raises `RuntimeError` at load time.

## Phase 4 - Decision Surface and Actionability ✅ COMPLETED 2026-04-12
Goal: Add execution-actionable output while preserving filter-engine separation.

### Tasks
1. ✅ `execution_planner.py` implements `ExecutionPlannerV1_2` — derives entry/SL/TP/RR/TTL from accepted signals; pure functions, no global state.
2. ✅ `EngineRunner` remains scoring/filter authority — planner only consumes `engine_outputs` dict.
3. ✅ Output contract extended — `execution_plan` block emitted on `decision=execute`; absent on reject (backward compatible).
4. ✅ Deterministic policy profiles — `min_rr_ratio`, `atr_mult_*_tp`, `ttl_*_sec`, `risk_percent`, `default_sl_atr_mult` all configurable in `production_configs/*.json`; `reject_unknown_intent` flag for conservative mode.

### Touchpoints
- `execution_planner.py`
- `core/engine_runner.py`
- `runtime/backtest_v2.py`
- `production_config.py`

### Tests/Gates
- ✅ Unit tests for SL/TP computation: `tests/test_execution_planner.py` (25,868 lines).
- ✅ Contract tests for absent `execution_plan`: covered in `tests/test_engine_runner_rr_fusion.py`.

### Exit Criteria
- ✅ Approved decisions emit executable trade parameters (`entry`, `sl`, `tp`, `rr_ratio`, `ttl_sec`, `trade_intent`).
- ✅ No breakage to existing reject/approve consumers — `live_engine_hook.py` and `backtest_v2.py` both handle absent plan gracefully.

## Phase 5 - Governance and Rollout ✅ COMPLETED 2026-04-12
Goal: Make changes auditable and safe for promotion.

### Tasks
1. ✅ Pre-promotion quality gates added — `ConfigValidator.validate()` enforces hard gates (min trades, max DD, min score) and soft warnings before `PromotionManager` will proceed.
2. ✅ Config and model promotions versioned with signed hashes — `promotion_manager.py` computes SHA-256 of params, archives old version on overwrite, appends to immutable `production_configs/promotion_log.jsonl`.
3. ✅ Rollback runbook documented in `CLAUDE.md` and `AGENTS.md` — restore archived `production_configs/{version}_archived_{ts}.json` and update `PROD_VERSION`.

### Touchpoints
- `promotion_manager.py`
- `production_config.py`
- `config_validator.py` ← gate entry point
- `CLAUDE.md` / `AGENTS.md` ← runbook

### Exit Criteria
- ✅ Promotion blocked automatically when mandatory checks fail — validated: `ConfigValidator` returns `REJECT` with explicit `hard_failures` list; `PromotionManager` never writes to registry on reject.
- ✅ Rollback documented — see AGENTS.md "Governance & Rollout" section.

## Suggested Delivery Sprints — COMPLETED
1. ✅ Sprint 1: Phase 0 + Phase 1
2. ✅ Sprint 2: Phase 2
3. ✅ Sprint 3: Phase 3
4. ✅ Sprint 4: Phase 4 + Phase 5

## Dependency Graph (Implementation Order) — ALL DONE
1. ✅ Baseline capture
2. ✅ Runtime blockers
3. ✅ Dormant integration wiring
4. ✅ Data/model quality repair
5. ✅ Actionability extension
6. ✅ Governance hardening

## Immediate Next Actions — COMPLETED 2026-04-12
1. ✅ Phase 0 baseline captured: `results/baseline/20260411T191106Z_phase0/manifest.json`
2. ✅ Phase 1 implemented: `config_validator.py` created; all blockers resolved.
3. ✅ Validation gate verified end-to-end: `python -m config_validator validate-prod --data-dir data/` → APPROVE (score=0.5757, 80 trades, max DD=11.2%).
