﻿# CANONICAL_OVERVIEW.md
> Autonomous Trading System — Architectural Canonical Reference
> Status Key: ✅ Implemented | 🟡 Partial | 🔴 Missing | 🧪 Mocked/Experimental

---

## 1. System Identity

| Attribute | Value |
|---|---|
| System Name | Tradelatest Autonomous Trading System |
| Primary Domain | Algorithmic FX & Commodity Trading |
| Architecture Style | Multi-Engine Signal Fusion + Governance Loop |
| Inference Stack | Gaussian Probability Models + BitNet Quantized Neural Nets + Heuristics |
| Runtime Modes | Live Trading, Backtesting, Replay Harness, Shadow Mode |
| Governance Model | MetaGovernorExecutor + ShadowPromotionGate + ReflectionBuffer |

---

## 2. System Purpose

A production-grade autonomous trading system that:
1. Ingests market data (OHLCV) per instrument/timeframe
2. Computes a validated feature vector via `FeaturePipeline`
3. Routes through a configurable engine stack (Gaussian / ML / CRT / RR / LLM / ZoneGate)
4. Fuses engine signals in `FusionEngine`
5. Applies `UltronRiskGate` as final safety rail
6. Generates an `ExecutionPlan` (entry, SL, TP, position size)
7. Logs outcomes and feeds governance/reflection loop for self-improvement

---

## 3. Layer Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  INGESTION LAYER                                                 │
│  Collector → DatasetBuilder → UnifiedDataBuilder → FeatureStore │
├─────────────────────────────────────────────────────────────────┤
│  FEATURE LAYER                                                   │
│  FeaturePipeline → FeatureBuilder → FeatureSchema (validation)  │
├─────────────────────────────────────────────────────────────────┤
│  ENGINE LAYER (Multi-Engine, Configurable)                       │
│  GaussianEngine | HeuristicGaussianEngine | MLGaussianEngine     │
│  CRTEngine | ZoneGateEngine | RREngine | ScoringEngine           │
│  LLMEngine | LiveEngine | AdapterEngine                          │
├─────────────────────────────────────────────────────────────────┤
│  COGNITION / FUSION LAYER                                        │
│  FusionEngine → DecisionEngine → EngineRunner                   │
├─────────────────────────────────────────────────────────────────┤
│  RISK LAYER                                                      │
│  UltronRiskGate → ExecutionPlanner                               │
├─────────────────────────────────────────────────────────────────┤
│  GOVERNANCE LAYER                                                │
│  MetaGovernorExecutor → ShadowPromotionGate                     │
│  ReflectionBufferBasic | ReflectionBufferAdvanced                │
│  ModelRegistry → PromotionManager                               │
├─────────────────────────────────────────────────────────────────┤
│  RUNTIME LAYER                                                   │
│  LiveEngineHook | BacktestV2 | UnifiedReplayHarness             │
│  BacktestBitnet                                                  │
├─────────────────────────────────────────────────────────────────┤
│  TRAINING LAYER                                                  │
│  Trainer → DatasetBuilder → Phase5Calibration → ModelExport     │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. Primary Data Flow (Happy Path)

```
MarketData (OHLCV)
  → Collector.collect(pair, timeframe)
  → FeaturePipeline.build(bar_data, pair, timeframe)
      → FeatureBuilder._compute_indicators()
      → FeatureSchema.validate(features)
      → FeatureStore.put(pair, timeframe, features)
  → EngineRunner.run(features, context)
      → DecisionEngine.decide(features, bar, config)
          → ZoneGateEngine.gate(features)          [pre-filter]
          → [GaussianEngine | MLGaussianEngine | CRTEngine | RREngine].score(features)
          → FusionEngine.fuse(signals)
  → UltronRiskGate.evaluate(signal, context)
      → check_drawdown() + check_exposure()
      → approve(signal) | reject(signal)
  → ExecutionPlanner.plan(signal, config)
      → compute_sl_tp() + size_position()
  → TradeLogger.log(execution_plan)
  → ReflectionBuffer.record(trade_result)
  → MetaGovernorExecutor.run_cycle()
```

---

## 5. External Surface Map

### 5.1 Third-Party Dependencies & Failure Modes

| Dependency | Usage | Failure Mode | Mitigation Status |
|---|---|---|---|
| **PyTorch** | MLGaussianEngine (.pth model inference), TradeNet training | Model load failure, CUDA OOM | 🟡 No explicit fallback to CPU documented |
| **BitNet (quantized)** | BitNetRunner.infer() — 1-bit quantized inference | Model corruption, quantization drift | 🟡 Smoke test exists (`_smoke_test.py`), fallback not confirmed |
| **Binance API** (inferred) | Collector.collect(), bar data ingestion | Rate limit, connection timeout, stale data | 🔴 MISSING_FROM_CONTEXT — error handling not confirmed |
| **LLM API** (inferred) | LLMEngine.query() — contextual signal generation | Token limits, latency spikes, hallucination | 🔴 MISSING_FROM_CONTEXT — gate/timeout not confirmed |
| **Filesystem (JSON)** | ModelRegistry, GaussianEngine.load_model(), zone_registry | File corruption, missing model file | 🟡 Registry pattern provides indirection |
| **C++ Runner** (cpp_runner.exe) | cpp_outputs.json, performance-critical path | Binary not built, platform mismatch | 🟡 Python fallback (python_runner.py) exists |
| **NumPy / pandas** | Feature computation throughout pipeline | NaN propagation, shape mismatches | 🟡 Schema validation catches post-computation |
| **scikit-learn** (inferred) | Phase5Calibration, GaussianEngine scoring | Version mismatch, fit/predict contract | 🔴 MISSING_FROM_CONTEXT |

### 5.2 Internal Integration Points (Cross-Module)

| Boundary | From | To | Protocol |
|---|---|---|---|
| Feature handoff | FeaturePipeline | EngineRunner | Dict (validated by FeatureSchema) |
| Signal handoff | Engines → FusionEngine | FusionEngine | List[SignalDict] |
| Risk decision | FusionEngine | UltronRiskGate | SignalDict + Context |
| Model loading | ModelRegistry | GaussianEngine / MLGaussianEngine | JSON path / .pth path |
| Governance feedback | ReflectionBuffer | MetaGovernorExecutor | MetricsDict |
| Promotion | ShadowPromotionGate | ModelRegistry | engine_id + approval |

---

## 6. Configuration Surface

| Config File | Purpose | Status |
|---|---|---|
| `production_configs/v1_multi_2026_03.json` | Live multi-pair production config | ✅ |
| `production_configs/v1_multi_2026_03_force_accept.json` | Force-accept variant for testing | 🧪 |
| `model_export_format.json` | Model serialization schema | ✅ |
| `models/gaussian_registry.json` | Active Gaussian model registry | ✅ |
| `models/zone_registry.json` | Zone definition registry | ✅ |
| `models/v1.json` | Base model definition | ✅ |

---

## 7. Instrument Coverage

| Pair | Status | Notes |
|---|---|---|
| AUDUSD | ✅ | Confirmed backtest results |
| EURCAD | ✅ | Archive runner present |
| GBPUSD | ✅ | Archive runner present |
| XAUUSD | ✅ | Archive runner present |
| M15 (timeframe) | ✅ | Primary timeframe confirmed |

---

## 8. Signal Lifecycle States

```
UNSCORED → SCORED → ZONE_FILTERED | ZONE_PASSED → FUSED → RISK_APPROVED | RISK_REJECTED → PLANNED → EXECUTED → REFLECTED
```

| State | Owner | Transition Trigger |
|---|---|---|
| UNSCORED | EngineRunner | Feature vector available |
| SCORED | Individual Engine | Engine.score() completes |
| ZONE_FILTERED | ZoneGateEngine | Zone check fails |
| ZONE_PASSED | ZoneGateEngine | Zone check passes |
| FUSED | FusionEngine | All engines returned |
| RISK_APPROVED | UltronRiskGate | All risk checks pass |
| RISK_REJECTED | UltronRiskGate | Any risk check fails |
| PLANNED | ExecutionPlanner | Signal approved, plan computed |
| EXECUTED | LiveEngine / Runtime | Plan dispatched |
| REFLECTED | ReflectionBuffer | Trade outcome recorded |

---

## 9. Model Versioning Architecture

```
TrainingPipeline → DatasetBuilder → Trainer → Phase5Calibration
  → ModelExport (model_export_format.json)
  → ModelRegistry.register(model_id, metadata)
  → ShadowMode (shadow_promotion_gate.py)
  → ShadowPromotionGate.check(metrics)
  → PromotionManager.promote(model_id)
  → ModelRegistry active model updated
```

---

## 10. Key Invariants (Summary — see RULES_AND_INVARIANTS.md for full list)

1. Feature vector MUST pass `FeatureSchema.validate()` before entering any engine.
2. `UltronRiskGate` is a mandatory, non-bypassable checkpoint.
3. No engine may write to `ModelRegistry` directly — only `PromotionManager` can.
4. `ReflectionBuffer` must receive every trade outcome — partial recording is a bug.
5. Governance cycle MUST NOT promote a model with fewer than N shadow trades (N = config-defined).