# CRT Trading Agent package
# Import modes to trigger tool registration into REGISTRY
from agent import modes  # noqa: F401
