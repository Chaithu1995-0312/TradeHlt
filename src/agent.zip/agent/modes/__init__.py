# Import all mode modules to trigger @register_tool registrations
from agent.modes import pipeline_mode  # noqa: F401
from agent.modes import copilot_mode   # noqa: F401
from agent.modes import governance_mode  # noqa: F401
