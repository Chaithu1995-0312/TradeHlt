// Top-level CRT dashboard — mission-control shell.
// TopBar (8 tabs) + SidebarNew (sectioned) + content-area.
// Each page receives activeSub + setActiveSub for internal sub-navigation.

function CrtDashboard() {
  const [activePage, setActivePage] = React.useState("Executive");
  const [activeSub,  setActiveSub]  = React.useState("Executive");

  // Expose setter for legacy sidebar onClick compatibility
  window.__crtNav = (page) => { setActivePage(page); setActiveSub(page); };

  const PAGES = [
    { id: "Executive",    Component: ExecutivePage    },
    { id: "Runtime",      Component: RuntimePage      },
    { id: "Research",     Component: ResearchPage     },
    { id: "Models",       Component: ModelsPage       },
    { id: "Trades",       Component: TradesPage       },
    { id: "Backtests",    Component: BacktestsPage    },
    { id: "System",       Component: SystemPage       },
    { id: "Intelligence", Component: IntelligencePage },
    { id: "Replay Lab",   Component: ReplayPage       },
  ];

  const active = PAGES.find(p => p.id === activePage) || PAGES[0];

  return (
    <div className="app-shell">
      <TopBar
        activePage={activePage}
        onNav={(p) => { setActivePage(p); setActiveSub(p); }}
      />
      <div className="app-body">
        <SidebarNew
          activePage={activePage}
          activeSub={activeSub}
          onNav={setActivePage}
          onSubNav={setActiveSub}
        />
        <div className="content-area">
          <active.Component activeSub={activeSub} setActiveSub={setActiveSub} />
        </div>
      </div>
    </div>
  );
}

// Expose for deferred mount by realData.js (which fetches live data first).
// If realData.js is not loaded, mount immediately as fallback.
window.CrtDashboard = CrtDashboard;
if (!window._REAL_DATA_LOADING) {
  ReactDOM.createRoot(document.getElementById("root")).render(<CrtDashboard />);
}
