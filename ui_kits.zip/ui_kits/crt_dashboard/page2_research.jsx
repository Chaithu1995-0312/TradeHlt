// Page 2 — Research / Opportunity Explorer (Pipeline B)

function ResearchPage() {
  const [selectedJob, setSelectedJob] = React.useState(null);
  const [liveOutcomes, setLiveOutcomes] = React.useState(null);

  const globalKpis     = window.RESEARCH_KPIS    || {};
  const globalOutcomes = window.OUTCOMES_SEGMENTS || [];

  const displayKpis     = selectedJob ? selectedJob.kpis     : globalKpis;
  const displayOutcomes = liveOutcomes || (selectedJob ? selectedJob.outcomes : globalOutcomes);

  const scanJobs = window.SCAN_JOBS || [];

  function handleJobClick(job) {
    if (selectedJob && selectedJob.id === job.id) {
      // toggle off — restore global view
      setSelectedJob(null);
      setLiveOutcomes(null);
      return;
    }
    setSelectedJob(job);
    setLiveOutcomes(null);
    // fail-open live fetch — overlays real data when API is available
    fetch(`/api/opportunity_stats?instrument=${job.inst}`)
      .then(r => r.json())
      .then(d => {
        const dist  = d.outcome_distribution || {};
        const total = d.total_sampled || 1;
        const tp    = dist.TP_HIT || dist.TP || 0;
        const sl    = dist.SL_HIT || dist.SL || 0;
        const tout  = dist.TIMEOUT || 0;
        setLiveOutcomes([
          { label:"TP Hit",  value:tp,   pct:((tp/total)*100).toFixed(1)+"%",   color:"#22c55e" },
          { label:"SL Hit",  value:sl,   pct:((sl/total)*100).toFixed(1)+"%",   color:"#ef4444" },
          { label:"Timeout", value:tout, pct:((tout/total)*100).toFixed(1)+"%", color:"#facc15" },
        ]);
      })
      .catch(() => {}); // silent — embedded mock already set via selectedJob.outcomes
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Research / Opportunity Explorer</div>
          <div className="page-sub">Unbiased Market Cartography · Opportunity Scanning · Feature Space</div>
        </div>
        <div style={{ display:"flex", gap:8, alignItems:"center" }}>
          {selectedJob && (
            <span
              onClick={() => { setSelectedJob(null); setLiveOutcomes(null); }}
              style={{
                fontSize:11, color:"var(--accent)", cursor:"pointer",
                padding:"3px 8px", border:"1px solid rgba(34,211,238,.3)",
                borderRadius:6, background:"rgba(34,211,238,.07)",
              }}
            >← All Jobs</span>
          )}
          <div style={{ fontSize:11, color:"var(--accent)" }}>● M15 · 8Y · Unbiased Mode</div>
        </div>
      </div>

      {/* KPI strip — switches to per-job data when a row is selected */}
      <div className="kpis" style={{ gridTemplateColumns:"1.4fr repeat(4,1fr)" }}>
        <Kpi label="Total Opportunities" tone="num"
             value={(displayKpis.totalOpps && displayKpis.totalOpps.value) || "—"}
             sub={(displayKpis.totalOpps && displayKpis.totalOpps.sub) || ""} />
        <Kpi label="Win Rate (TP)"   tone="pos" value={displayKpis.winRateTP} />
        <Kpi label="Avg RR"          tone="num" value={displayKpis.avgRR} />
        <Kpi label="Profit Factor"   tone="num" value={displayKpis.profitFactor} />
        <Kpi label="Timeout Rate"    tone="neg" value={displayKpis.timeoutRate} />
      </div>

      <div className="row" style={{ gridTemplateColumns:"1fr 1.3fr" }}>
        {/* Opportunity Outcomes donut — switches to per-job when selected */}
        <div className="card">
          <div className="card-title">
            Opportunity Outcomes
            {selectedJob
              ? <span className="right" style={{ color:"var(--accent)", fontSize:10 }}>
                  📋 {selectedJob.id} · {selectedJob.inst}
                </span>
              : <span className="right">All Instruments · All Sessions</span>
            }
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"150px 1fr", gap:14, alignItems:"center" }}>
            <DonutChart segments={displayOutcomes} />
            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {displayOutcomes.map(s => (
                <div key={s.label} style={{ display:"flex", justifyContent:"space-between", fontSize:12 }}>
                  <span style={{ color:"#b6c0d6" }}>
                    <span style={{ display:"inline-block", width:7, height:7, borderRadius:"50%", background:s.color, marginRight:7 }} />
                    {s.label}
                  </span>
                  <span className="mono">{s.value.toLocaleString()} <span className="muted">({s.pct})</span></span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Stacked bar — intentionally global (multi-year historical, not per-run) */}
        <div className="card">
          <div className="card-title">Outcomes Over Time
            <span className="legend-row">
              <span><span className="dot" style={{ background:"#22c55e" }} />TP</span>
              <span><span className="dot" style={{ background:"#ef4444" }} />SL</span>
              <span><span className="dot" style={{ background:"#facc15" }} />Timeout</span>
            </span>
          </div>
          <StackedBarChart
            data={window.STACKED_OUTCOMES || []}
            colors={{ tp:"#22c55e", sl:"#ef4444", to:"#facc15" }}
            height={180}
            xLabels={["Apr 21","Oct 21","Apr 22","Oct 22","Apr 23","Oct 23","Apr 24","Apr 25","May 25"]}
          />
        </div>
      </div>

      <div className="row" style={{ gridTemplateColumns:"1fr 1.2fr", marginTop:12 }}>
        {/* Scatter — intentionally global */}
        <div className="card">
          <div className="card-title">Feature Space (UMAP 2D Projection)</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 90px", gap:8, alignItems:"center" }}>
            <Scatter points={window.SCATTER_POINTS || []} />
            <div style={{ display:"flex", flexDirection:"column", gap:6, fontSize:11 }}>
              <span><span className="dot" style={{ background:"#22c55e" }} /> Profitable</span>
              <span><span className="dot" style={{ background:"#facc15" }} /> Breakeven</span>
              <span><span className="dot" style={{ background:"#ef4444" }} /> Losing</span>
            </div>
          </div>
        </div>

        {/* Recent Scan Jobs — clickable rows */}
        <div className="card">
          <div className="card-title">
            Recent Scan Jobs
            {selectedJob && (
              <span className="right muted" style={{ fontSize:10 }}>Click to deselect</span>
            )}
          </div>
          <table className="dt">
            <thead>
              <tr><th>Job ID</th><th>Instrument</th><th>Start Time</th><th>Records</th><th>Status</th></tr>
            </thead>
            <tbody>
              {scanJobs.map(j => {
                const isSelected = selectedJob && selectedJob.id === j.id;
                return (
                  <tr
                    key={j.id}
                    onClick={() => handleJobClick(j)}
                    style={{
                      cursor:"pointer",
                      borderLeft: isSelected ? "2px solid var(--accent)" : "2px solid transparent",
                      background: isSelected ? "rgba(34,211,238,.06)" : "transparent",
                    }}
                  >
                    <td className="mono" style={{ color: isSelected ? "var(--accent)" : "" }}>{j.id}</td>
                    <td>{j.inst}</td>
                    <td className="mono">{j.time}</td>
                    <td className="mono">{j.rec}</td>
                    <td><CheckIcon /> <span className="pos" style={{ marginLeft:4 }}>{j.status}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
window.ResearchPage = ResearchPage;
