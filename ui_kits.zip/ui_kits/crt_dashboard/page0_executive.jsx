// Page 0 — Executive Overview (default landing page)

function ExecutivePage() {
  const k = window.EXEC_KPIS || {};
  const alerts = window.ALERTS || [];
  const ss = window.STATUS_STRIP || {};
  const eq = window.EQ_TRADES || [];
  const sp = window.SESSION_PNL || [];

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Executive Overview</div>
          <div className="page-sub">Live System Pulse · Portfolio Performance · Alert Summary</div>
        </div>
        <div style={{ display:"flex", gap:8 }}>
          <button className="btn outline" style={{ fontSize:11, padding:"5px 12px" }}>Export PDF</button>
          <button className="btn" style={{ fontSize:11, padding:"5px 12px" }}>Refresh</button>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="kpis" style={{ gridTemplateColumns:"repeat(5,1fr)", marginBottom:16 }}>
        <div className="kpi">
          <div className="label">Total PnL (R)</div>
          <div className="v pos">{k.totalPnl || "+356.42"}</div>
          <div className="sub">{k.totalPnlDelta || "↑ 1.62%"}</div>
        </div>
        <div className="kpi">
          <div className="label">Win Rate</div>
          <div className="v num">{k.winRate || "54.37%"}</div>
          <div className="sub">{k.winRateDelta || "↑ 2.18%"}</div>
        </div>
        <div className="kpi">
          <div className="label">Profit Factor</div>
          <div className="v num">{k.profitFactor || "1.38"}</div>
          <div className="sub">{k.pfDelta || "↑ 0.11"}</div>
        </div>
        <div className="kpi">
          <div className="label">Avg RR (W/L)</div>
          <div className="v num" style={{ fontSize:14 }}>{k.avgRR || "1.62 / -1.03"}</div>
          <div className="sub">{k.avgRRDelta || "↑ 0.07"}</div>
        </div>
        <div className="kpi">
          <div className="label">Expectancy (R)</div>
          <div className="v pos">{k.expectancy || "0.42"}</div>
          <div className="sub">{k.expDelta || "↑ 0.04"}</div>
        </div>
      </div>

      {/* Row 1: 3 charts */}
      <div className="row" style={{ gridTemplateColumns:"1fr 1fr 1fr", marginBottom:14 }}>
        {/* PnL Over Time */}
        <div className="card">
          <div className="card-title">PnL Over Time (R) <span className="right">2020 → 2025</span></div>
          <LineChart values={eq} color="#22d3ee" height={120} />
        </div>

        {/* Session Equity */}
        <div className="card">
          <div className="card-title">
            Equity by Session
            <div className="legend-row">
              {[["Asian","#22d3ee"],["London","#a78bfa"],["NY","#22c55e"],["Overlap","#facc15"]].map(([l,c]) => (
                <span key={l}><span className="dot" style={{ background:c }} />{l}</span>
              ))}
            </div>
          </div>
          <SessionEquityChart height={120} />
        </div>

        {/* Win Rate by Session */}
        <div className="card">
          <div className="card-title">Win Rate by Session (%)</div>
          <VerticalBars
            data={sp.map(s => ({ label: s.label, value: s.value, color: s.color }))}
            height={120} maxVal={100}
          />
        </div>
      </div>

      {/* Row 2: Heatmap + Alerts */}
      <div className="row" style={{ gridTemplateColumns:"1.3fr 1fr", marginBottom:14 }}>
        <div className="card">
          <div className="card-title">Opportunity Density</div>
          <Heatmap
            rows={window.MONTHLY_RETURNS || []}
            colLabels={["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]}
          />
        </div>
        <div className="card">
          <div className="card-title">
            Alerts <span className="right" style={{ color:"var(--bad)" }}>{alerts.length} Active</span>
          </div>
          {alerts.length === 0
            ? <div className="muted" style={{ fontSize:12, padding:"12px 0" }}>No active alerts</div>
            : alerts.map((a, i) => (
              <div key={i} className="alert-item">
                <div className="alert-icon">{a.icon}</div>
                <div style={{ flex:1 }}>
                  <div className="alert-title">{a.title}</div>
                  <div className="alert-sub">{a.sub}</div>
                </div>
                <div className="alert-age">{a.age}</div>
              </div>
            ))
          }
        </div>
      </div>

      {/* Status Strip */}
      <div className="status-strip">
        <div className="ss-item">
          <div className="ss-label">Active Model</div>
          <div className="ss-value">
            {ss.activeModel || "CRT v5"}
            <span className="pill live" style={{ fontSize:9, padding:"1px 6px" }}>LIVE</span>
          </div>
        </div>
        <div className="ss-item">
          <div className="ss-label">Promotion Guard</div>
          <div className="ss-value">{ss.promotionGuard || "KMeans Clustering"}</div>
        </div>
        <div className="ss-item">
          <div className="ss-label">Schema</div>
          <div className="ss-value">{ss.schema || "35-dim Feature Space"}</div>
        </div>
        <div className="ss-item">
          <div className="ss-label">Data Integrity</div>
          <div className="ss-value" style={{ color:"var(--ok)" }}>{ss.dataIntegrity || "100%"}</div>
        </div>
      </div>
    </div>
  );
}

// ── SessionEquityChart — 4-series multi-line SVG ──────────────
function SessionEquityChart({ height = 120 }) {
  const se = window.SESSION_EQUITY || { asian:[], london:[], ny:[], overlap:[] };
  const W = 340, H = height;
  const SERIES = [
    { key:"asian",  color:"#22d3ee" },
    { key:"london", color:"#a78bfa" },
    { key:"ny",     color:"#22c55e" },
    { key:"overlap",color:"#facc15" },
  ];

  const allVals = Object.values(se).flat();
  const minV = Math.min(...allVals, 0);
  const maxV = Math.max(...allVals, 1);
  const pad = 8;

  function toPoints(arr) {
    if (!arr || arr.length === 0) return "";
    const xStep = (W - pad*2) / Math.max(arr.length - 1, 1);
    return arr.map((v, i) => {
      const x = pad + i * xStep;
      const y = pad + ((maxV - v) / (maxV - minV)) * (H - pad*2);
      return `${x},${y}`;
    }).join(" ");
  }

  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display:"block" }}>
      {SERIES.map(s => {
        const pts = toPoints(se[s.key] || []);
        if (!pts) return null;
        return (
          <polyline key={s.key}
            points={pts}
            fill="none"
            stroke={s.color}
            strokeWidth="1.5"
            strokeLinejoin="round"
            opacity="0.85"
          />
        );
      })}
    </svg>
  );
}

window.ExecutivePage = ExecutivePage;
